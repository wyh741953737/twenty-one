/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:44
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-26 09:38:25
 */
'use strict';

const path = require('path');
module.exports = appInfo => {
  return {
    mysql: {
      client: {
        host: '192.168.20.151',
        port: '3306',
        user: 'root',
        password: 'dMcKp7o1m$c4',
        database: 'fe_tools_db',
      },
    },
    logger: {
      dir: path.join(appInfo.baseDir, 'logs'),
      outputJSON: true,
      appLogName: `${'cms'}-web.log`,
      coreLogName: 'egg-web.log',
      agentLogName: 'egg-agent.log',
      errorLogName: 'cms-error.log',
    },
    logrotator: {
      // filesRotateByHour: [
      //   path.join(appInfo.root, 'logs', appInfo.name, 'common-error.log'),
      // ],
    },
    onerror: {
      json(err, ctx) {
        // json hander
        ctx.body = { message: 'error' };
        ctx.status = 500;
      },
    },
    middleware: [ 'auth', 'errorHandler', 'notfoundHandler', 'relativePath' ],
  };
};
