/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:44
 * @LastEditors: FCC
 * @LastEditTime: 2019-10-09 09:44:28
 */
/* eslint valid-jsdoc: "off" */

'use strict';

/**
 * @param {Egg.EggAppInfo} appInfo app info
 */
module.exports = appInfo => {
  /**
   * built-in config
   * @type {Egg.EggAppConfig}
   **/
  const config = {
    gitInfo: {
      userName: 'fe@uama.com.cn',
      password: 'diebian2019',
      personalAccessToken: 'xo19spcPS2QMWFBbo_t2'
    },
    gitDomain: 'http://git.uama.com.cn:8888/',
    gitMicroAppGroup: 'lmbusiness',
    gitDeploykeys: [159, 160, 164, 170, 172],
    omsProjectEnvInfo: {
      30: {
        name: '社享开发'
      },
      11: {
        name: '社享测试'
      },
      15: {
        name: '社享预发'
      },
      12: {
        name: '社享生产'
      }
    },
    dingTalkAccessToken: '46a9644486f04bc43aca444890613af5f75260a31de46abdae1fbd2d2e2851f0',
    cluster: {
      listen: {
        path: '',
        port: 9001,
        hostname: '',
      },
    },
    baseUrl: '/api/v1', // 全局url
    jwtSecret: 'qwertyuiopasdfghjklzxcvbnm.', // jwt加密盐值
    keys: `${appInfo.name}_1561344901255_592`, // use for cookie sign key, should change to your own and keep security
    pageSize: 20, // 默认页大小
    middleware: [ 'auth', 'errorHandler', 'relativePath' ], // 使用的中间页
    errorHandler: {
      match: '/api',
    }, // 只对 /api 前缀的 url 路径生效
    auth: {
      authUrlList: [ '/api/v1/spider', '/public/web', '/public/snapshot', '/swagger*', '/api/v1/captcha', '/api/v1/user/login', '/api/v1/upload', '/api/v1/snapshot', '/api/v1/web/*' ],
    }, // url拦截白名单
    mysql: {
      client: {
        host: '192.168.20.151',
        port: '3306',
        user: 'root',
        password: 'dMcKp7o1m$c4',
        database: 'fe_tools_db',
      },
    },
    security: {
      csrf: false,
      domainWhiteList: [ '*' ],
      xframe: false,
    },
    cors: {
      credentials: true,
    },
    io: {
      init: {},
      namespace: {
        '/apiExplorer': {
          connectionMiddleware: [ 'apiExplorerConnection' ],
          packetMiddleware: [ 'apiExplorerPacket' ]
        }
      }
    },
    redis: {
      client: {
        host: '192.168.20.162',
        port: 6379,
        password: '4a678b0f5f60',
        db: 0
      }
    },
    clusterClient: {
      maxWaitTime: 600000,
      responseTimeout: 600000
    },
    multipart: {
      fileSize: '50mb',
      mode: 'stream',
      // tslint:disable-next-line:array-bracket-spacing
      fileExtensions: [ '.xls', '.txt' ], // 扩展几种上传的文件格式
    },
    /**
     * egg-swagger-doc default config
    * @member Config#swagger-doc
    * @property {String} dirScanner - 插件扫描的文档路径
    * @property {String} basePath - api前置路由
    * @property {Object} apiInfo - 可参考Swagger文档中的Info
    * @property {Array[String]} apiInfo - 可参考Swagger文档中的Info
    * @property {Array[String]} schemes - 访问地址协议http或者https
    * @property {Array[String]} consumes - contentType的集合
    * @property {Array[String]} produces - contentType的集合
    * @property {Object} securityDefinitions - 安全验证，具体参考swagger官方文档
    * @property {Boolean} enableSecurity - 是否使用安全验证
    * @property {Boolean} routeMap - 是否自动生成route
    * @property {Boolean} enable - swagger-ui是否可以访问
    */
    swaggerdoc: {
      dirScanner: './app/controller',
      basePath: '/api/v1',
      apiInfo: {
        title: 'egg-swagger',
        description: 'swagger-ui for egg',
        version: '1.0.0',
      },
      schemes: [ 'http', 'https' ],
      consumes: [ 'application/json' ],
      produces: [ 'application/json' ],
      securityDefinitions: {
        // apikey: {
        //   type: 'apiKey',
        //   name: 'clientkey',
        //   in: 'header',
        // },
        // oauth2: {
        //   type: 'oauth2',
        //   tokenUrl: 'http://petstore.swagger.io/oauth/dialog',
        //   flow: 'password',
        //   scopes: {
        //     'write:access_token': 'write access_token',
        //     'read:access_token': 'read access_token',
        //   },
        // },
      },
      enableSecurity: true,
      // enableValidate: true,
      routerMap: false,
      enable: true,
    },

  };

  // add your user config here
  const userConfig = {
    // myAppName: 'egg',
  };

  return {
    ...config,
    ...userConfig,
  };
};
