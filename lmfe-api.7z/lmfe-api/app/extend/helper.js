/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: FCC
 * @LastEditTime: 2020-10-08 16:19:26
 */
'use strict';
// 引入邮件模块
const nodemailer = require('nodemailer');

const fs = require('fs');
const path = require('path');
// 故名思意 异步二进制 写入流
// tslint:disable-next-line:no-var-requires
const awaitWriteStream = require('await-stream-ready').write;
// 管道读入一个虫洞。
const sendToWormhole = require('stream-wormhole');
const dayjs = require('dayjs');
const { exec } = require('shelljs');
const chalk = require('chalk');
// const { default: random } = require('node-auth0/dist/random');

const getNetworkDiagramData = require('../tool/networkDiagram');
const buildMicroAppTemplate = require('../tool/microApp');

const log = msg => console.log(chalk.cyan(msg))

const publicAssets = path.join(__dirname, '../../LM_FE_Modules/')
const rootPath = '/data/web/cms_api'
const projectTemplate = '/data/web/cms_api/project_template'
const lmGitDomain = 'http://git.uama.com.cn:8888/'
const linuxSafeOpts = '--unsafe-perm'

module.exports = {
  isEmail: /^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g, // 判断邮箱的正则
  isMobile: /^1([38][0-9]|4[579]|5[0-3,5-9]|6[6]|7[0135678]|9[89])\d{8}$/, // 判断手机号码的正则
  /**
   * 发送邮件
   */
  sendEmail(name, email) {
    // 创建一个SMTP客户端配置
    const config = {
      host: 'smtp.exmail.qq.com',
      port: 25,
      auth: {
        user: 'fulin.liu@uama.com.cn', // 刚才注册的邮箱账号
        pass: '!@#QWE123qwe', // 新浪邮箱填邮箱密码，其他邮箱有授权码，请填写授权码
      },
    };

    // 创建一个SMTP客户端对象
    const transporter = nodemailer.createTransport(config);

    const options = {
      from: '"system" <fulin.liu@uama.com.cn>',
      to: `"${name}" <${email}>`, // 可一个或多个以,区分
      subject: '-账户激活（PS:请添加本邮箱到联系人）',
      text: '-您好，您在绿漫注册的账户已注册成功',
      html: '<h1>你好，这是一封来自绿漫科技的邮件！</h1><a href=http://www.uama.com.cn/ target=_blank>绿漫科技</a>',
      attachments: [{
        filename: '美景.jpg', // 改成你的附件名
        path: './app/public/uploads/user/2019/07/13/1562985234065635.jpg', // 改成你的附件路径
        cid: '00000001', // cid可被邮件使用
      }],
    };
    transporter.sendMail(options, (error, info) => {
      if (error) {
        return console.log(error);
      }
      console.log('mail sent:', info.response);
    });
  },
  /**
   * 上传文件的通用方法
   * @param {String} category 分类目录
   */
  async upload(category = '') {
    const stream = await this.ctx.getFileStream();
    // 基础的目录
    const uplaodBasePath = 'app/public/uploads';
    // 生成文件名
    const filename = `${Date.now()}${Number.parseInt(
      (Math.random() * 1000).toString()
    )}${path.extname(stream.filename).toLocaleLowerCase()}`;
    // 生成文件夹
    const dirname = dayjs(Date.now()).format('YYYY/MM/DD');
    // 递归创建文件夹
    function mkdirsSync(dirname) {
      if (!fs.existsSync(dirname)) {
        if (mkdirsSync(path.dirname(dirname))) {
          fs.mkdirSync(dirname);
          return true;
        }
      } else {
        return true;
      }
    }
    mkdirsSync(path.join(uplaodBasePath, category, dirname));
    // 生成写入路径
    const target = path.join(uplaodBasePath, category, dirname, filename);
    // 写入流
    const writeStream = fs.createWriteStream(target);
    try {
      // 异步把文件流 写入
      await awaitWriteStream(stream.pipe(writeStream));
    } catch (err) {
      // 如果出现错误，关闭管道
      await sendToWormhole(stream);
      return {
        code: 1,
        message: err,
      };
    }
    return {
      url: path.join('/public/uploads', category, dirname, filename),
      module: stream.fields.module,
    };
  },
  // 递归处理某个对象里头的所有时间类型字段
  formatTime(obj) {
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        const item = obj[key];
        if (item instanceof Date) {
          try {
            obj[key] = dayjs(item).format('YYYY-MM-DD HH:mm:ss');
          } catch (e) {
            throw e;
          }
        }
        if (item && typeof item === 'object' && Object.keys(item).length) {
          this.formatTime(item);
        }
      }
    }
  },
  // 切割静态资源的域名信息，存储相对路径
  getRelativeStaticAssetsPath(path) {
    let res = path;
    const ctx = this.ctx;
    const host = ctx.request.host;
    const origin = (host.indexOf('http') !== -1 || host.indexOf('https') !== -1) ? host : ctx.request.origin;
    if (path.includes(`${origin}/public/uploads`)) {
      const reg = new RegExp(origin, 'g');
      res = path.replace(reg, '');
    }
    return res;
  },
  // 拼接静态资源的域名信息，返回绝对路径给前端
  addOriginForStaticAssets(path) {
    let res = path;
    const ctx = this.ctx;
    if ((path.indexOf('http') === -1 && path.indexOf('https') === -1) && path.includes('/public/uploads')) {
      const host = ctx.request.host;
      const origin = (host.indexOf('http') !== -1 || host.indexOf('https') !== -1) ? host : ctx.request.origin;
      const reg = new RegExp('/public/uploads', 'g');
      res = path.replace(reg, `${origin}/public/uploads`);
    }
    return res;
  },
  async installPackage (model) {
    // 回到程序根目录
    process.chdir(path.join(__dirname, '../../'))
    console.log(999, process.cwd())
    const { repository, branch, executeShell } = model
    // 处理脚本
    let folder
    if (repository.indexOf(lmGitDomain) !== -1) {
      folder = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
    } else {
      return {
        code: -1,
        msg: '仓库地址不合法，请确认！'
      }
    }
    // 进入public目录
    process.chdir(publicAssets)
    // 判断文件夹是否存在
    if (!fs.existsSync(folder)) {
      exec(`git clone -b master ${repository} ${folder}`)
    }
    log(`\n进入目录：${folder}`)
    process.chdir(folder)
    try {
      // 切换到目标分支
      log(`\n切换到目标分支：${branch}`)
      exec(`git checkout ${branch}`)
      // pull最新代码
      log(`\n拉取最新代码：`)
      exec('git pull')
      log(`\n当前目录是：${process.cwd()}`)
      // 执行脚本
      log(`\n开始执行脚本：${executeShell}`)
      exec(`${executeShell} ${linuxSafeOpts}`)
      log(`\n脚本执行成功！`)
      const res = exec('git status')
      const statusLog = res.stdout || ''
      const { stdout } = exec('git diff')
      if (statusLog.indexOf('nothing to commit, working tree clean') === -1) {
        console.log(111, stdout);
        log('\nCommitting changes...')
        exec('git add -A')
        exec(`git commit -m "chore(安装依赖): ${executeShell}"`)
        exec('git push')
      } else {
        console.log('No changes to commit.')
      }
      return {
        code: 100,
        log: `${statusLog}${stdout}`
      };
    } catch (error) {
      return {
        code: -1,
        msg: '仓库地址不合法，请确认！'
      }
    }
  },
  // 获取指定仓库的分支列表
  async getBranchList (model) {
    // 回到程序根目录
    process.chdir(path.join(__dirname, '../../'))
    console.log(999, process.cwd())
    const { repository } = model
    if (repository) {
      let folder
      if (repository.indexOf(lmGitDomain) !== -1) {
        folder = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
      } else {
        return {
          code: -1,
          msg: '仓库不存在'
        }
      }
      // 进入public目录
      process.chdir(publicAssets)

      // 判断文件夹是否存在
      if (!fs.existsSync(folder)) {
        exec(`git clone -b master ${repository} ${folder}`)
      }
      log(`\n进入目录：${folder}`)
      process.chdir(folder)
      log(`\n拉取最新代码：`)
      exec('git pull')
      try {
        const { stdout } = exec('git branch -r')
        if (stdout) {
          let list = stdout.split('\n')
          list.shift()
          list.pop()
          const listNew = list.map(item => {
            return {
              lable: item.replace('origin/', '').trim(),
              value: item.replace('origin/', '').trim()
            }
          })
          return {
            code: 100,
            data: listNew
          };
        } else {
          return {
            code: -1,
            msg: '没有查询到分支信息'
          }
        }
      } catch (error) {
        return {
          code: -1,
          msg: '仓库地址不合法，请确认！'
        }
      }
    } else {
      return {
        code: -1,
        msg: '仓库地址不合法，请确认！'
      }
    }
  },
  releaseVersionForMicroApp (models) {
    const { repository, version } = models
    const folderName = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
    if (folderName) {
      process.chdir(publicAssets)
      if (!fs.existsSync(folderName)) {
        exec(`mkdir ${folderName}`)
        exec(`git clone -b master ${repository} ${folderName}`)
        process.chdir(folderName)
        exec(`npm install --dev --unsafe-perm`)
        exec('git checkout .')
      } else {
        process.chdir(folderName)
        exec('git checkout master -f') // 发布微应用时强行切换到master分支
        exec('git pull')
      }
      if (exec(`npm run release ${version}`).code === 0) {
        return true
      }
    }
    return false;
  },
  buildForProject (models) {
    const { repository, branch, dir } = models;
    const projectName = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0];
    if (projectName) {
      process.chdir(projectTemplate);
      if (!fs.existsSync(projectName)) {
        exec(`mkdir ${projectName}`);
        exec(`git clone -b ${branch} ${repository} ${projectName}`);
      } else {
        exec('git pull');
      }
      process.chdir(`${projectName}/${dir || ''}`);
      exec(`npm install --unsafe-perm`);
      exec('git checkout .');
      exec('npm run prod');
      exec('git add -A');
      exec(`git commit -m "chore${dir ? '(' + dir + ')' : ''}: build"`);
      exec('git push');
      return true;
    }
    return false;
  },
  releaseVersionForProject (models) {
    const { repository, branch, dir, version } = models
    const projectName = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
    if (projectName) {
      process.chdir(projectTemplate)
      if (!fs.existsSync(projectName)) {
        exec(`mkdir ${projectName}`)
      }
      process.chdir(projectName)
      if (!fs.existsSync(branch)) {
        exec(`mkdir ${branch}`)
        exec(`git clone -b ${branch} ${repository} ${branch}`)
        process.chdir(`${branch}/${dir || ''}`)
        exec(`npm install --dev --unsafe-perm`)
        exec('git checkout .')
      } else {
        process.chdir(`${branch}/${dir || ''}`)
        exec(`npm install --dev --unsafe-perm`)
        exec('git checkout .')
        exec('git pull')
      }
      if (exec(`npm run release ${version}`).code === 0) {
        return true
      }
    }
    return false;
  },
  getNetworkDiagramData (models) {
    const { repository, branch, dir, reg } = models;
    const projectName = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0];
    if (projectName) {
      process.chdir(projectTemplate);
      if (fs.existsSync(projectName)) {
        process.chdir(`${projectName}/${branch}/${dir || ''}`);
        const data = getNetworkDiagramData({ reg });
        return data;
      }
    }
  },
  // 创建新的分支
  createBranch (model) {
    // 回到程序根目录
    process.chdir(path.join(__dirname, '../../'))
    const { repository, commitId, name, source } = model
    if (repository) {
      let folder
      if (repository.indexOf(lmGitDomain) !== -1) {
        folder = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
      } else {
        return {
          code: -1,
          msg: '仓库不存在'
        }
      }
      // 进入public目录
      process.chdir(publicAssets)

      // 判断文件夹是否存在
      if (!fs.existsSync(folder)) {
        exec(`git clone -b master ${repository} ${folder}`)
      }
      log(`\n进入目录：${folder}`)
      process.chdir(folder)
      if (source === 1) {
        exec(`git checkout ${commitId}`)
        exec(`git pull origin ${commitId}`)
        exec(`git checkout -b ${name}`)
      } else {
        exec(`git checkout ${commitId} -b ${name}`)
      }
      exec(`git push origin ${name}`)
      let code = exec(`git checkout master`)
      log(`\n进入目录code：${code}`)
      return code
    } else {
      return {
        code: -1,
        msg: '仓库地址不合法，请确认！'
      }
    }
  },

  // 获取指定仓库的分支列表
  async getTagList (model) {
    // 回到程序根目录
    process.chdir(path.join(__dirname, '../../'))
    console.log(999, process.cwd())
    const { repository } = model
    if (repository) {
      let folder
      if (repository.indexOf(lmGitDomain) !== -1) {
        folder = repository.split(lmGitDomain)[1].split('/')[1].split('.git')[0]
      } else {
        return {
          code: -1,
          msg: '仓库不存在'
        }
      }
      // 进入public目录
      process.chdir(publicAssets)

      // 判断文件夹是否存在
      if (!fs.existsSync(folder)) {
        exec(`git clone -b master ${repository} ${folder}`)
      }
      log(`\n进入目录：${folder}`)
      process.chdir(folder)
      log(`\n拉取最新代码：`)
      exec('git pull')
      try {
        const { stdout } = exec('git tag')
        if (stdout) {
          console.log('git tag', stdout)
          let list = stdout.split('\n')
          list.shift()
          list.pop()
          const listNew = list.map(item => {
            return {
              lable: item.trim(),
              value: item.trim()
            }
          })
          return {
            code: 100,
            data: listNew
          };
        } else {
          return {
            code: -1,
            msg: '没有查询到分支信息'
          }
        }
      } catch (error) {
        return {
          code: -1,
          msg: '仓库地址不合法，请确认！'
        }
      }
    } else {
      return {
        code: -1,
        msg: '仓库地址不合法，请确认！'
      }
    }
  },

  setupProject ({ microAppName, title, description, repository, dependencies }) {
    process.chdir(publicAssets);
    if (fs.existsSync(microAppName)) {
      return false
    }
    exec(`mkdir ${microAppName}`);
    process.chdir(microAppName);
    buildMicroAppTemplate({
      microAppName,
      title,
      description,
      gitDomain: this.app.config.gitDomain,
      gitMicroAppGroup: this.app.config.gitMicroAppGroup
    });
    exec('npm install --dev --unsafe-perm');
    if (Array.isArray(dependencies) && dependencies.length > 0) {
      for (let i = 0; i < dependencies.length; i++) {
        exec(`npm install ${dependencies[i]} --save`);
      }
    }
    exec('git init');
    exec('git add -A');
    exec('git commit -m "feat: 初始化"');
    exec(`git push --set-upstream ${repository}.git master`);
    exec('git config branch.master.remote origin');
    exec(`git config remote.origin.url ${repository}.git`);
    exec('git config remote.origin.fetch +refs/heads/*:refs/remotes/origin/*');
    exec('git config pull.rebase false');
    exec('git pull');
    exec('git remote set-head origin -a');
    return true;
  },

  queryMicroAppConfig ({ repository, branch }) {
    process.chdir(rootPath);
    const folder = 'gitlab'
    if (!fs.existsSync(folder)) {
      exec(`mkdir ${folder}`);
    }
    process.chdir(folder);
    const projectName = 'config-services';
    if (!fs.existsSync(projectName)) {
      exec(`mkdir ${projectName}`);
    }
    process.chdir(projectName);
    if (!fs.existsSync(branch)) {
      exec(`mkdir ${branch}`);
      exec(`git clone -b ${branch} ${repository} ${branch}`);
      process.chdir(branch);
    } else {
      process.chdir(branch);
      if (!fs.existsSync('.git')) {
        exec(`git clone -b ${branch} ${repository} .`);
      } else {
        exec('git pull');
      }
    }
    exec('git checkout .');
    const dir = fs.readdirSync('./microApp');
    const result = {};
    if (Array.isArray(dir) && dir.length) {
      for (let i = 0; i < dir.length; i++) {
        const dirItem = dir[i];
        const fileContent = fs.readFileSync(`microApp/${dirItem}/config.json`, 'utf-8');
        result[dirItem] = JSON.parse(fileContent);
      }
    }
    return result;
  },

  updateMicroAppConfig ({ dir, projectEnv, list, userEmail }) {
    process.chdir(rootPath);
    const folder = 'gitlab';
    if (fs.existsSync(folder)) {
      process.chdir(folder);
      const projectName = 'config-services';
      if (fs.existsSync(projectName)) {
        process.chdir(projectName);
        if (fs.existsSync(projectEnv)) {
          process.chdir(projectEnv);
          const fileName = `microApp/${dir}/config.json`;
          const fileContent = fs.readFileSync(fileName, 'utf-8');
          const result = JSON.parse(fileContent);
          let commitMessage = `feat(microApp/${dir}): `;
          if (Array.isArray(list) && list.length) {
            list.forEach((item, index) => {
              result[item.microAppId] = item.microAppVersion;
              commitMessage += `${item.microAppId}#${item.microAppVersion}${index === list.length - 1 ? '' : ','}`;
            })
          }
          commitMessage += ` -- ${userEmail}`;
          exec('git checkout .');
          exec('git pull');
          fs.writeFileSync(fileName, JSON.stringify(result, null, '  '), { encoding: 'utf8' });
          exec(`git add ${fileName}`);
          exec(`git commit -m "${commitMessage}"`);
          exec('git push');
          return true;
        }
      }
    }
  },

  async configRepository ({ microAppName, title, description, gitLabUserIds }) {
    if (microAppName) {
      const searchRes = await this.ctx.curl(`${lmGitDomain}api/v4/search?scope=projects&search=${microAppName}`, {
        method: 'GET',
        headers: {
          'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
        },
        dataType: 'text'
      });
      const searchResData = JSON.parse(searchRes.data);
      if (Array.isArray(searchResData) && searchResData.length > 0) {
        const project = searchResData.find((item) => {
          return item.name === microAppName
        })
        if (project !== undefined) {
          const projectId = project.id;
          await this.ctx.curl(`${lmGitDomain}api/v4/projects/${projectId}`, {
            method: 'PUT',
            headers: {
              'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
            },
            data: {
              description: `${title} / ${description}`
            },
            dataType: 'text'
          });
          const keyIds = this.app.config.gitDeploykeys;
          for (let i = 0; i < keyIds.length; i++) {
            await this.ctx.curl(`${lmGitDomain}api/v4/projects/${projectId}/deploy_keys/${keyIds[i]}/enable`, {
              method: 'POST',
              headers: {
                'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
              },
              dataType: 'text'
            });
          }
          if (Array.isArray(gitLabUserIds) && gitLabUserIds.length > 0) {
            for (let i = 0; i < gitLabUserIds.length; i++) {
              const gitLabUserId = gitLabUserIds[i];
              if (gitLabUserId > 0) {
                // await this.ctx.curl(`${lmGitDomain}api/v4/projects/${projectId}/members/${gitLabUserId}?access_level=40`, {
                //   method: 'PUT',
                //   headers: {
                //     'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
                //   },
                //   dataType: 'text'
                // });
                await this.ctx.curl(`${lmGitDomain}api/v4/projects/${projectId}/members`, {
                  method: 'POST',
                  headers: {
                    'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
                  },
                  data: {
                    access_level: 40,
                    user_id: gitLabUserId
                  },
                  dataType: 'text'
                });
              }
            }
          }
        }
      }
    }
  },
  async noticeDingTalk ({ title, markdownText }) {
    await this.ctx.curl(`https://oapi.dingtalk.com/robot/send?access_token=${this.app.config.dingTalkAccessToken}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      dataType: 'text',
      data: {
        'msgtype': 'markdown',
        'markdown': {
          'title': title,
          'text': markdownText
        },
        'at': {
          'isAtAll': true
        }
      }
    });
  }
};
