'use strict';

module.exports = {
  addFeeDetailRequest: {
    houseId: { type: 'string', required: true, description: '房号id' },
    id: { type: 'int', required: false, description: '费用明细id' },
    status: { type: 'int', required: true, description: '0：未核销 1：已核销 2：已逾期' },
    subject: { type: 'string', required: true, description: '收费科目' },
    startFeeTime: { type: 'string', required: true, description: '计费开始时间' },
    endFeeTime: { type: 'number', required: true, example: 1, description: '计费结束时间' },
    startGetFeeTime: { type: 'string', required: true, description: '收费开始时间' },
    endGetFeeTime: { type: 'string', required: true, description: '收费结束时间' },
    money: { type: 'number', required: true, example: 1000, description: '应收金额' },
  },
  editFeeDetailRequest: {
    houseId: { type: 'string', required: true, description: '房号id' },
    id: { type: 'int', required: true, description: '费用明细id' },
    status: { type: 'int', required: false, description: '0：未核销 1：已核销 2：已逾期' },
    subject: { type: 'string', required: false, description: '收费科目' },
    startFeeTime: { type: 'string', required: false, description: '计费开始时间' },
    endFeeTime: { type: 'number', required: true, example: 1, description: '计费结束时间' },
    startGetFeeTime: { type: 'string', required: false, description: '收费开始时间' },
    endGetFeeTime: { type: 'string', required: false, description: '收费结束时间' },
    money: { type: 'number', required: true, example: 1, description: '应收金额' },
  },
};
