/*
 * @Description: 焦点图model
 * @Author: 木犀
 * @Date: 2019-08-06 10:37:20
 * @LastEditors: 小广
 * @LastEditTime: 2019-11-07 18:00:35
 */
'use strict';

module.exports = {
  addFocusRequest: {
    name: { type: 'string', required: true, description: '焦点图标题' },
    subName: { type: 'string', required: false, description: '焦点图子标题' },
    cover: { type: 'string', required: false, description: '封面图，type=2时必填有值' },
    type: { type: 'number', required: true, example: 1, description: '焦点图类型（1：视频，2：图片）' },
    outsideUrl: { type: 'string', required: false, description: '外链url' },
    videoUrl: { type: 'string', required: false, description: '视频url，type=1时必填有值' },
    showTitle: { type: 'number', required: false, example: 0, description: '是否显示焦点图标题' },
    status: { type: 'number', required: true, example: 1, description: '焦点图状图（1：正常，0：关闭）' },
    sort: { type: 'number', required: true, example: 1, description: '焦点图排序（数值越小越靠前）' },
    onlineTime: { type: 'string', required: false, description: '焦点图上线时间' },
    position: { type: 'number', required: true, example: 1, description: '焦点图发布位置（1首页，2融平台）' },
  },
  editFocusRequest: {
    name: { type: 'string', required: false, description: '焦点图标题' },
    subName: { type: 'string', required: false, description: '焦点图子标题' },
    cover: { type: 'string', required: false, description: '封面图，type=2时必填有值' },
    type: { type: 'number', required: false, example: 1, description: '焦点图类型（1：视频，2：图片）' },
    outsideUrl: { type: 'string', required: false, description: '外链url' },
    videoUrl: { type: 'string', required: false, description: '视频url，type=1时必填有值' },
    showTitle: { type: 'number', required: false, example: 0, description: '是否显示焦点图标题' },
    status: { type: 'number', required: false, example: 1, description: '焦点图状图（1：正常，0：关闭）' },
    sort: { type: 'number', required: false, example: 1, description: '焦点图排序（数值越小越靠前）' },
    onlineTime: { type: 'string', required: false, description: '焦点图上线时间' },
    position: { type: 'number', required: false, example: 1, description: '焦点图发布位置（1首页，2融平台）' },
  },
};
