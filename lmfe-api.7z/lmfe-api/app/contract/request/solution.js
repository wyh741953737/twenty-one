/*
 * @Description: 解决方案
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
<<<<<<< HEAD
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-10 16:42:57
=======
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-10 09:49:23
>>>>>>> # 解决方案修改
 */
'use strict';

module.exports = {
  addSolutionRequest: {
    title: { type: 'string', required: true, description: '解决方案标题' },
    iconName: { type: 'string', required: true, description: '图标名称' },
    typeName: { type: 'string', required: true, description: '解决方案类型名字' },
    typeEnName: { type: 'string', required: true, description: '类型英文名字' },
    cover: { type: 'string', required: true, description: '类型封面图' },
    smallCover: { type: 'string', required: true, description: '类型封面小图，融平台模块用到' },
    content: { type: 'string', required: true, description: '内容' },
    bigImg: { type: 'string', required: true, description: '底部大图' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    sort: { type: 'number', required: true, example: 1, description: '排序（数值越小越靠前）' },
  },
  editSolutionRequest: {
    title: { type: 'string', required: false, description: '解决方案标题' },
    iconName: { type: 'string', required: true, description: '图标名称' },
    typeName: { type: 'string', required: false, description: '解决方案类型名字' },
    typeEnName: { type: 'string', required: false, description: '类型英文名字' },
    cover: { type: 'string', required: false, description: '类型封面图' },
    smallCover: { type: 'string', required: false, description: '类型封面小图，融平台模块用到' },
    content: { type: 'string', required: false, description: '内容' },
    bigImg: { type: 'string', required: false, description: '底部大图' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
