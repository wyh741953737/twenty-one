/*
 * @Description: 联系我们
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-25 16:01:52
 */
'use strict';

module.exports = {
  addContactUsRequest: {
    name: { type: 'string', required: true, description: '申请人名字' },
    status: { type: 'number', required: true, description: '状态（1已接待，0未接待）' },
    companyName: { type: 'string', required: true, description: '申请人公司名字' },
    mobile: { type: 'string', required: true, description: '申请人电话' },
    email: { type: 'string', required: true, description: '申请人邮箱' },
    cityName: { type: 'string', required: true, description: '申请人所在城市' },
    remark: { type: 'string', required: false, description: '备注' },
  },
  editContactUsRequest: {
    name: { type: 'string', required: false, description: '申请人名字' },
    status: { type: 'number', required: false, description: '状态（1已接待，0未接待）' },
    companyName: { type: 'string', required: false, description: '申请人公司名字' },
    mobile: { type: 'string', required: false, description: '申请人电话' },
    email: { type: 'string', required: false, description: '申请人邮箱' },
    cityName: { type: 'string', required: false, description: '申请人所在城市' },
    remark: { type: 'string', required: false, description: '备注' },
  },
};
