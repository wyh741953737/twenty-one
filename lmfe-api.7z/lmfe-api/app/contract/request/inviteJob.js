/*
 * @Description: 招聘信息
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2020-04-07 12:05:43
 */
'use strict';

module.exports = {
  addInviteJobRequest: {
    jobName: { type: 'string', required: true, description: '岗位名字' },
    status: { type: 'number', required: true, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: true, example: 1, description: '工作性质（1全职，2兼职）' },
    address: { type: 'string', required: true, description: '工作地址' },
    url: { type: 'string', required: false, description: '第三方招聘url' },
    sort: { type: 'number', required: true, example: 1, description: '排序（数值越小越靠前）' },
    description: { type: 'string', required: false, description: '岗位描述' },
  },
  editInviteJobRequest: {
    jobName: { type: 'string', required: false, description: '岗位名字' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: false, example: 1, description: '工作性质（1全职，2兼职）' },
    address: { type: 'string', required: false, description: '工作地址' },
    url: { type: 'string', required: false, description: '第三方招聘url' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
    description: { type: 'string', required: false, description: '岗位描述' },
  },
};
