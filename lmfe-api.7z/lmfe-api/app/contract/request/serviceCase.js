/*
 * @Description: 服务案例
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-27 10:45:21
 */
'use strict';

module.exports = {
  addServiceCaseRequest: {
    name: { type: 'string', required: true, description: '案例名字' },
    enName: { type: 'string', required: false, description: '案例英文名字' },
    summary: { type: 'string', required: true, description: '案例摘要' },
    cover: { type: 'string', required: true, description: '案例封面图' },
    content: { type: 'string', required: false, description: '案例详情，jumpType=3，必填' },
    outsideUrl: { type: 'string', required: true, description: '案例外链，jumpType=2，必填' },
    status: { type: 'number', required: true, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: true, example: 1, description: '类型（1智慧园区，2智慧社区，3智慧楼宇，4智慧校园）' },
    jumpType: { type: 'number', required: true, example: 1, description: '跳转类型（1不跳转，2外链，3详情）' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
  editServiceCaseRequest: {
    name: { type: 'string', required: false, description: '案例名字' },
    enName: { type: 'string', required: false, description: '案例英文名字' },
    summary: { type: 'string', required: false, description: '案例摘要' },
    cover: { type: 'string', required: false, description: '案例封面图' },
    content: { type: 'string', required: false, description: '案例详情，jumpType=3，必填' },
    outsideUrl: { type: 'string', required: false, description: '案例外链，jumpType=2，必填' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: false, example: 1, description: '类型（1智慧园区，2智慧社区，3智慧楼宇，4智慧校园）' },
    jumpType: { type: 'number', required: false, example: 1, description: '跳转类型（1不跳转，2外链，3详情）' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
