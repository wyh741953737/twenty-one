'use strict';

module.exports = {
  addHouseRequest: {
    enterpriseName: { type: 'string', required: true, description: '企业名称' },
    contacts: { type: 'string', required: false, description: '联系人' },
    contactNumber: { type: 'string', required: false, description: '联系电话' },
    businessLicenseId: { type: 'string', required: false, description: '营业执照证号' },
    enterpriseType: { type: 'number', required: true, example: 1, description: '公司类型' },
    Industry: { type: 'string', required: false, description: '所属行业' },
    Integrity: { type: 'string', required: false, description: '信息完整度' },
    logo: { type: 'number', required: true, example: 1, description: '公司logo' },
    vitalityType: { type: 'number', required: true, example: 1, description: '企业活力' },
    safeProductionType: { type: 'number', required: true, example: 1, description: '安全生产' },
    technologicalInnovationType: { type: 'string', required: false, description: '科技创新' },
    creditRatingType: { type: 'number', required: true, example: 1, description: '信用评级' },
    enterpriseCooperationType: { type: 'number', required: true, example: 1, description: '园企配合' },
  },
  editHouseRequest: {
    enterpriseName: { type: 'string', required: true, description: '企业名称' },
    contacts: { type: 'string', required: false, description: '联系人' },
    contactNumber: { type: 'string', required: false, description: '联系电话' },
    businessLicenseId: { type: 'string', required: false, description: '营业执照证号' },
    enterpriseType: { type: 'number', required: true, example: 1, description: '公司类型' },
    Industry: { type: 'string', required: false, description: '所属行业' },
    Integrity: { type: 'string', required: false, description: '信息完整度' },
    logo: { type: 'number', required: true, example: 1, description: '公司logo' },
    vitalityType: { type: 'number', required: true, example: 1, description: '企业活力' },
    safeProductionType: { type: 'number', required: true, example: 1, description: '安全生产' },
    technologicalInnovationType: { type: 'string', required: false, description: '科技创新' },
    creditRatingType: { type: 'number', required: true, example: 1, description: '信用评级' },
    enterpriseCooperationType: { type: 'number', required: true, example: 1, description: '园企配合' },
  },
};
