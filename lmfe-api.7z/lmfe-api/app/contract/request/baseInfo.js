/*
 * @Description: 基础信息model
 * @Author: 木犀
 * @Date: 2019-08-06 10:37:20
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 10:53:22
 */
'use strict';

module.exports = {
  editBaseInfoRequest: {
    companyName: { type: 'string', required: false, description: '公司中文名称' },
    companyNameEN: { type: 'string', required: false, description: '公司英文名称' },
    logo: { type: 'string', required: false, description: '公司logo' },
    phone: { type: 'string', required: false, description: '联系电话' },
    address: { type: 'string', required: false, description: '公司详细地址' },
    email: { type: 'string', required: false, description: '邮箱' },
    postcode: { type: 'string', required: false, description: '邮编' },
    invitePhone: { type: 'string', required: false, description: '招聘电话' },
    inviteEmail: { type: 'string', required: false, description: '招聘邮箱' },
    latitude: { type: 'string', required: false, description: '纬度' },
    longitude: { type: 'string', required: false, description: '经度' },
    qrCodeUrl: { type: 'string', required: false, description: '公众号二维码url' },
    copyright: { type: 'string', required: false, description: '版权信息' },
    websiteICP: { type: 'string', required: false, description: '网站备案号' },
    companyIntro: { type: 'string', required: false, description: '公司简介（富文本）' },
    companyImg: { type: 'string', required: false, description: '公司环境图片' },
    welfareList: {
      type: 'string',
      required: false,
      example: '"[{"title":"五险一金","icon":"string"},{"title":"节日福利","icon":"string"}]"',
      description: '公司福利【字符串数组】' },
  },
};
