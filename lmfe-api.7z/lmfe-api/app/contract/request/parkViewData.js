'use strict';

module.exports = {
  editParkViewDataRequest: {
    money: { type: 'string', required: false, description: '金额' },
  },
};
