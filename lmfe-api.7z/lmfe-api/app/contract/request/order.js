/*
 * @Description: 工单model
 * @Author: 木犀
 * @Date: 2020-08-03 10:37:20
 * @LastEditors: 木犀
 * @LastEditTime : 2020-08-03 10:37:20
 */
'use strict';

module.exports = {
  addOrderRequest: {
    title: { type: 'string', required: true, description: '工单标题' },
    content: { type: 'string', required: true, description: '工单内容' },
    microAppId: { type: 'number', required: true, description: '微应用id' },
    branch: { type: 'string', required: true, description: 'git分支' },
    executeShell: { type: 'string', required: true, description: '执行脚本' },
  },
  editOrderRequest: {
    title: { type: 'string', required: false, description: '工单标题' },
    content: { type: 'string', required: false, description: '工单内容' },
    microAppId: { type: 'number', required: false, description: '微应用id' },
    branch: { type: 'string', required: false, description: 'git分支' },
    executeShell: { type: 'string', required: false, description: '执行脚本' },
  },
};
