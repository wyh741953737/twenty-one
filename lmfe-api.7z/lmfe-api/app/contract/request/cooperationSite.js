/*
 * @Description: 合作站点
 * @Author: FCC
 * @Date: 2019-09-04 11:05:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-27 10:45:56
 */
'use strict';

module.exports = {
  addCooperationSiteRequest: {
    title: { type: 'string', required: true, description: '标题' },
    content: { type: 'string', required: true, description: '内容,type=2，非必填' },
    status: { type: 'number', required: true, example: 1, description: '状态（1：正常，0关闭）' },
    type: { type: 'number', required: true, example: 1, description: '类型（1:领域分类，2:icon集合图，3:生态服务）' },
    typeIcon: { type: 'string', required: false, description: '类型图标，type=3，必填' },
    bigImg: { type: 'string', required: false, description: '合作公司icon集合图，type=2，必填' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
  editCooperationSiteRequest: {
    title: { type: 'string', required: false, description: '标题' },
    content: { type: 'string', required: false, description: '内容,type=2，非必填' },
    status: { type: 'number', required: false, example: 1, description: '状态（1：正常，0关闭）' },
    type: { type: 'number', required: false, example: 1, description: '类型（1:领域分类，2:icon集合图，3:生态服务）' },
    typeIcon: { type: 'string', required: false, description: '类型图标，type=3，必填' },
    bigImg: { type: 'string', required: false, description: '合作公司icon集合图，type=2，必填' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
