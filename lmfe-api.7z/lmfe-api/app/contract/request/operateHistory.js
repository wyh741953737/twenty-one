'use strict';

module.exports = {
  addOperateHistoryRequest: {
    content: { type: 'int', required: true, description: '操作内容' },
    operateUser: { type: 'string', required: true, description: '操作人' },
    operateTime: { type: 'string', required: true, description: '操作时间' },
  },
  editOperateHistoryRequest: {
    content: { type: 'int', required: false, description: '操作内容' },
    operateUser: { type: 'string', required: false, description: '操作人' },
    operateTime: { type: 'string', required: false, description: '操作时间' },
  },
};
