/*
 * @Description: 发展历程
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-26 15:19:39
 */
'use strict';

module.exports = {
  addDevelopHistoryRequest: {
    title: { type: 'string', required: true, description: '发展历程标题' },
    status: { type: 'number', required: true, example: 1, description: '状态（1正常，0关闭）' },
    developTime: { type: 'string', required: true, description: '发展历程时间' },
    // sort: { type: 'number', required: true, example: 1, description: '排序（数值越小越靠前）' },
  },
  editDevelopHistoryRequest: {
    title: { type: 'string', required: false, description: '发展历程标题' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    developTime: { type: 'string', required: false, description: '发展历程时间' },
    // sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
