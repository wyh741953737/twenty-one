/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-07 15:34:30
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-07 15:34:30
 */
'use strict';

module.exports = {
  loginRequest: {
    userName: { type: 'string', required: true, description: '用户名' },
    password: { type: 'string', required: true, description: '用户密码' },
  },
};
