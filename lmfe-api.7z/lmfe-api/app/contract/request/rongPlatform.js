/*
 * @Description: 融平台
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-14 16:09:58
 */
'use strict';

module.exports = {
  addRongPlatformRequest: {
    title: { type: 'string', required: true, description: '标题' },
    type: { type: 'number', required: false, example: 1, description: '类型（1.服务平台，2：服务体系）' },
    iconName: { type: 'string', required: false, description: '字体图标，type=2，必填' },
    cover: { type: 'string', required: false, description: '封面图，type=2，必填' },
    summary: { type: 'string', required: false, description: '摘要，type=2，必填' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    sort: { type: 'number', required: true, example: 1, description: '排序（数值越小越靠前）' },
  },
  editRongPlatformRequest: {
    title: { type: 'string', required: false, description: '标题' },
    type: { type: 'number', required: false, example: 1, description: '类型（1.服务平台，2：服务体系）' },
    iconName: { type: 'string', required: false, description: '字体图标，type=2，必填' },
    cover: { type: 'string', required: false, description: '封面图，type=2，必填' },
    summary: { type: 'string', required: false, description: '摘要，type=2，必填' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
