/*
 * @Description: 荣誉资质
 * @Author: 小广
 * @Date: 2019-09-25 15:44:57
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 17:40:51
 */
'use strict';

module.exports = {
  addCertificateRequest: {
    name: { type: 'string', required: false, description: '荣誉资质证书名字' },
    url: { type: 'string', required: true, description: '证书图片的url' },
    status: { type: 'number', required: true, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: true, example: 1, description: '证书图片类型（1横版，2竖版）' },
    sort: { type: 'number', required: true, example: 1, description: '排序（数值越小越靠前）' },
  },
  editCertificateRequest: {
    name: { type: 'string', required: false, description: '荣誉资质证书名字' },
    url: { type: 'string', required: false, description: '证书图片的url' },
    status: { type: 'number', required: false, example: 1, description: '状态（1正常，0关闭）' },
    type: { type: 'number', required: false, example: 1, description: '证书图片类型（1横版，2竖版）' },
    sort: { type: 'number', required: false, example: 1, description: '排序（数值越小越靠前）' },
  },
};
