/*
 * @Description: 微应用model
 * @Author: 木犀
 * @Date: 2019-08-06 10:37:20
 * @LastEditors: 小广
 * @LastEditTime: 2019-11-07 18:00:35
 */
'use strict';

module.exports = {
  addMicroAppRequest: {
    appName: { type: 'string', required: true, description: '微应用名称' },
    description: { type: 'string', required: true, description: '微应用描述' },
    endType: { type: 'number', required: true, description: '端类型（1：业主端；2：物管端：3：商家端：4：管理后台）' },
    unitType: { type: 'number', required: true, description: '所属单元（1：楼宇单元；2：社区单元；3：物联网单元）' },
    status: { type: 'number', required: true, description: '开发进度（1：未开始；2：开发中；3：待提测；4：测试中；5：待上线；6：已上线）' },
    ownerA: { type: 'number', required: true, description: '微应用负责人A' },
    ownerB: { type: 'number', required: true, description: '微应用负责人B' },
    repository: { type: 'string', required: true, description: 'git仓库' },
    remark: { type: 'string', required: true, description: '备注' },
    intime: { type: 'string', required: true, description: '微应用创建时间' },
    lastEditTime: { type: 'string', required: true, description: '微应用最后一次更新时间' },
  },
  editMicroAppRequest: {
    appName: { type: 'string', required: false, description: '微应用名称' },
    description: { type: 'string', required: false, description: '微应用描述' },
    endType: { type: 'number', required: false, description: '端类型（1：业主端；2：物管端：3：商家端：4：管理后台）' },
    unitType: { type: 'number', required: false, description: '所属单元（1：楼宇单元；2：社区单元；3：物联网单元）' },
    status: { type: 'number', required: false, description: '开发进度（1：未开始；2：开发中；3：待提测；4：测试中；5：待上线；6：已上线）' },
    ownerA: { type: 'number', required: false, description: '微应用负责人A' },
    ownerB: { type: 'number', required: false, description: '微应用负责人B' },
    repository: { type: 'string', required: false, description: 'git仓库' },
    remark: { type: 'string', required: false, description: '备注' },
    intime: { type: 'string', required: false, description: '微应用创建时间' },
    lastEditTime: { type: 'string', required: false, description: '微应用最后一次更新时间' },
  },
};
