'use strict';

module.exports = {
  addBranchRequest: {
    name: { type: 'string', required: false, description: '分支名称' },
    projectId: { type: 'number', required: true, example: 12, description: '项目id' },
    source: { type: 'number', required: true, example: 1, description: '基线来源(1 分支 2 tag 3 提交SHA)' },
    sourceBranch: { type: 'string', required: true, example: 'test', description: '来源分支' },
    sourceTag: { type: 'string', required: true, example: '', description: '来源tag' },
    sourceCommit: { type: 'string', required: true, example: '', description: '来源commit' },
    remark: { type: 'string', required: true, example: '21212121', description: '备注' },
  }
};