/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:37:20
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-24 14:28:46
 */
'use strict';

module.exports = {
  createUserRequest: {
    headPic: { type: 'string', required: false, description: '用户头像' },
    userName: { type: 'string', required: true, description: '用户名' },
    password: { type: 'string', required: true, description: '用户密码' },
    realName: { type: 'string', required: true, description: '真实姓名' },
    nickName: { type: 'string', required: false, description: '昵称' },
    gender: { type: 'number', required: true, example: 1, description: '用户性别（1男2女0未知）' },
    email: { type: 'string', required: false, example: '952766532@qq.com', format: /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, description: '邮箱' },
    mobile: { type: 'string', required: false, example: '18801731528', format: /^1[34578]\d{9}$/, description: '电话' },
    userType: { type: 'number', required: false, example: 2, description: '角色类型（1超管，2管理员）' },
  },

  updateUserRequest: {
    headPic: { type: 'string', required: false, description: '用户头像' },
    nickName: { type: 'string', required: false, description: '用户昵称' },
    realName: { type: 'string', required: false, description: '用户真实姓名' },
    gender: { type: 'string', required: false, example: '1', description: '用户性别' },
    email: { type: 'string', required: false, example: '952766532@qq.com', format: /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, description: '邮箱' },
    mobile: { type: 'string', required: false, example: '18801731528', format: /^1[34578]\d{9}$/, description: '电话' },
    // role_id: { type: 'number', required: true, description: '角色Id' },
  },

  updatePasswordRequest: {
    oldPassword: { type: 'string', required: true, description: '用户原密码' },
    newPassword: { type: 'string', required: true, description: '用户新密码' },
  },
};
