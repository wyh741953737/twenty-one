'use strict';

module.exports = {
  addHouseRequest: {
    houseId: { type: 'string', required: true, description: '房号' },
    area: { type: 'string', required: false, description: '面积' },
    status: { type: 'string', required: false, description: '状态' },
    rentalPrice: { type: 'string', required: false, description: '租金单价' },
    startDate: { type: 'number', required: true, example: 1, description: '合同开始日期' },
    endDate: { type: 'string', required: false, description: '合同结束日期' },
    settledEnterprise: { type: 'string', required: false, description: '入驻企业' },
    contacts: { type: 'number', required: true, example: 1, description: '联系人' },
    phone: { type: 'number', required: true, example: 1, description: '联系电话' },
    businessLicense: { type: 'number', required: true, example: 1, description: '营业执照' },
    businessId: { type: 'string', required: false, description: '营业执照证号' },
    enterpriseType: { type: 'number', required: true, example: 1, description: '企业类型' },
  },
  editHouseRequest: {
    houseId: { type: 'string', required: true, description: '房号' },
    area: { type: 'string', required: false, description: '面积' },
    status: { type: 'string', required: false, description: '状态' },
    rentalPrice: { type: 'string', required: false, description: '租金单价' },
    startDate: { type: 'number', required: true, example: 1, description: '合同开始日期' },
    endDate: { type: 'string', required: false, description: '合同结束日期' },
    settledEnterprise: { type: 'string', required: false, description: '入驻企业' },
    contacts: { type: 'number', required: true, example: 1, description: '联系人' },
    phone: { type: 'number', required: true, example: 1, description: '联系电话' },
    businessLicense: { type: 'number', required: true, example: 1, description: '营业执照' },
    businessId: { type: 'string', required: false, description: '营业执照证号' },
    enterpriseType: { type: 'number', required: true, example: 1, description: '企业类型' },
  },
};
