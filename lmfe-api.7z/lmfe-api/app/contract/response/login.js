/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-07 15:35:25
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-10 17:21:41
 */
'use strict';

module.exports = {
  loginResponse: {
    id: { type: 'number', description: '用户userId' },
    token: { type: 'string', description: '用户令牌token' },
  },
};
