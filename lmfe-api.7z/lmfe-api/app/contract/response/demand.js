/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:39:05
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-16 13:40:07
 */
'use strict';

module.exports = {
  vitalObj: {
    name: { type: 'string', description: '标签名称' },
    count: { type: 'int', description: '标签个数（统计维度：所有重要标签）', example: '8' },
  },
  unsolvedVitalObj: {
    name: { type: 'string', description: '标签名称' },
    count: { type: 'int', description: '标签个数（统计维度：未解决的重要标签）', example: '10' },
  },
  solvedObj: {
    month: { type: 'string', description: '月份' },
    value: { type: 'float', description: '解决率', example: '0.7' },
  },
  goodAppraiseObj: {
    month: { type: 'string', description: '月份' },
    value: { type: 'float', description: '好评率', example: '0.98' },
  },
  enterpriseDemandOverview: {
    commonCount: { type: 'int', description: '一般诉求数' },
    vitalCount: { type: 'int', description: '重要诉求数' },
    vitalStatistics: { type: 'array', itemType: 'vitalObj', description: '重要诉求分布' },
    unsolvedVitalStatistics: { type: 'array', itemType: 'unsolvedVitalObj', description: '重要诉求标签集合' },
    solvedCount: { type: 'int', description: '累计解决数' },
    solvedRate: { type: 'float', description: '诉求解决率' },
    goodAppraiseRate: { type: 'float', description: '综合好评率' },
    solvedStatics: { type: 'array', itemType: 'solvedObj', description: '诉求解决数据集合' },
    goodAppraiseStatics: { type: 'array', itemType: 'goodAppraiseObj', description: '综合好评率数据集合' },
  },
};
