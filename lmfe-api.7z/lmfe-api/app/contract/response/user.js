/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:39:05
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-14 16:16:13
 */
'use strict';

module.exports = {
  createUserResponse: {
    user: {
      type: 'user',
      description: '用户信息',
    },
  },
  personalInfoResponse: {
    userInfo: {
      type: 'user',
      description: '用户个人信息',
    },
    roleInfo: {
      type: 'role',
      description: '用户角色信息',
    },
    resourceInfo: {
      type: 'resource',
      description: '用户资源信息',
    },
  },
  updatePasswordResponse: '',
  deleteUserResponse: '',
};
