/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:39:05
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-16 16:24:04
 */
'use strict';

module.exports = {
  unsolvedVitalObj: {
    name: { type: 'string', description: '标签名称' },
    count: { type: 'int', description: '标签个数（统计维度：未解决的重要标签）', example: '10' },
  },
  enterpriseResponse: {
    enterpriseBase: {
      type: 'enterprise',
      description: '企业基础信息',
    },
    commonCount: {
      type: 'int',
      description: '一般诉求数',
    },
    vitalCount: {
      type: 'int',
      description: '重要诉求数',
    },
    solveRate: {
      type: 'float',
      description: '诉求解决率',
    },
    goodAppraiseRate: {
      type: 'float',
      description: '综合好评率',
    },
    unsolvedVitalStatistics: { type: 'array', itemType: 'unsolvedVitalObj', description: '重要诉求标签集合' },
  },
  enterpriseOverview: {
    infoRate: {
      type: 'float',
      description: '企业基础信息完善度',
    },
    visitorRate: {
      type: 'float',
      description: '企业走访完善度',
    },
    operateRate: {
      type: 'float',
      description: '企业经营信息完善度',
    },

  },
};
