module.exports = {
  item: {
    name: { type: 'string', description: '项目名称' },
    code: { type: 'string', description: '项目code' },
    endType: { type: 'number', description: '端类型' },
    unitType: { type: 'number', description: '所属单元' },
    repository: { type: 'string', description: 'git仓库地址' },
    ownerA: { type: 'string', description: '负责人A' },
    ownerAName: { type: 'string', description: '负责人A的真实姓名' },
    ownerB: { type: 'string', description: '负责人B' },
    ownerBName: { type: 'string', description: '负责人B的真实姓名' },
    intime: { type: 'string', description: '创建时间' },
    updateTime: { type: 'string', description: '最后更新时间' }
  },
  list: {
    data: { type: 'array', itemType: 'item', description: '项目列表' }
  },
  id: {
    data: { type: 'number', description: '项目id' }
  }
};
