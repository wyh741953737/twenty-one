/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:39:05
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 10:17:42
 */
'use strict';

module.exports = {
  CompanyIntroduceResponse: {
    baseInfo: {
      type: 'baseInfo',
      description: '公司基础信息',
    },
    horizontalImgList: {
      type: 'certificate',
      description: '资质证书横版图片',
    },
    verticalImgList: {
      type: 'certificate',
      description: '资质证书竖版图片',
    },
    developHistoryList: {
      type: 'developHistory',
      description: '发展历程',
    },
  },
};
