/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-07 15:35:25
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-22 14:56:37
 */
'use strict';

module.exports = {
  uploadResponse: {
    module: { type: 'string', description: '上传到服务器的文件夹模块' },
    url: { type: 'string', description: '上传到服务器的路径' },
  },
  uploadUEditorResponse: {
    msg: { type: 'string', description: '上传到服务器的url地址' },
    state: { type: 'string', description: '上传状态，成功为SUCCESS' },
    err: { type: 'string', description: '出错才有此字段，上传出错原因' },
  },
};
