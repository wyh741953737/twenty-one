/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-06 10:39:05
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-20 20:55:58
 */
'use strict';

module.exports = {
  roleListResponse: {
    role: {
      type: 'role',
      description: '角色信息',
    },
  },
};
