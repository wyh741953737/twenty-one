module.exports = {
  item: {
    id: { type: 'number', description: 'id' },
    name: { type: 'string', description: '名称' },
    remark: { type: 'string', description: '备注' },
    inuser: { type: 'number', description: '创建人id' },
    inuserName: { type: 'string', description: '创建人' },
    intime: { type: 'string', description: '创建时间' },
    updateUser: { type: 'number', description: '最后更新人id' },
    updateUserName: { type: 'string', description: '最后更新人' },
    updateTime: { type: 'string', description: '最后更新时间' }
  },
  list: {
    data: { type: 'array', itemType: 'item', description: '页面设计列表' }
  },
  id: {
    data: { type: 'number', description: '页面设计id' }
  }
};
