'use strict';

const Controller = require('egg').Controller;

class ApiExplorerController extends Controller {
  async invoke () {
    const { ctx, app } = this;
    const { roomId, params } = ctx.args[0];
    const nsp = app.io.of('/apiExplorer');
    await nsp.to(roomId).emit('execute', params);

  }
}

module.exports = ApiExplorerController
