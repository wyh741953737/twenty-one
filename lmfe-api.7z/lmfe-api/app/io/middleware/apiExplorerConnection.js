module.exports = () => {
  return async (ctx, next) => {
    const { app, socket } = ctx;

    const { action, roomId } = socket.handshake.query;
    const roomIds = [roomId];
    const namespace = '/apiExplorer';
    const nsp = app.io.of(namespace);
    const hasRoomId = await app.redis.get(`roomId_${roomId}`);

    console.log(`${socket.id} ${action} ${roomId} connection`);

    if (action === 'init') {
      if (hasRoomId) {
        socket.disconnect();
        return;
      } else {
        socket.join(roomId);
        await app.redis.set(`roomId_${roomId}`, 1);
      }
    } else if (action === 'join') {
      if (hasRoomId) {
        socket.join(roomId);
        nsp.adapter.clients(roomIds, (err, clientIds) => {
          nsp.to(roomId).emit('online', {
            number: clientIds.length,
            message: 'user joined.',
          });
        });
      } else {
        socket.disconnect();
        return;
      }
    }

    await next();

    console.log(`${socket.id} ${action} ${roomId} disconnection`);

    if (action === 'init') {
      nsp.adapter.clients(roomIds, async (err, clientIds) => {
        clientIds.forEach(clientId => {

        });
      });
      await app.redis.del(`roomId_${roomId}`);
    } else if (action === 'join') {
      socket.leave(roomId);
      nsp.adapter.clients(roomIds, async (err, clientIds) => {
        nsp.to(roomId).emit('online', {
          number: clientIds.length - 1,
          message: 'user leaved.',
        });
      });
    }
  };
};
