/* eslint-disable strict */
const { Service } = require('egg');

class CoreService extends Service {}
module.exports = CoreService;
