/*
 * @Description: 核心的控制层
 * @Author: 木犀
 * @Github: https://github.com/mx
 * @Email: 2374542140@qq.com
 * @Company: 绿漫科技有限公司
 * @Date: 2019-06-24 10:56:37
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-21 20:58:48
 */
'use strict';
const {
  Controller,
} = require('egg');

class CoreController extends Controller {
  success(data = {}) {
    if (Object.keys(data).length) {
      this.ctx.helper.formatTime(data);
    }
    this.ctx.body = {
      status: 100,
      msg: 'success',
      data,
    };
  }
  error(info) {
    this.ctx.body = {
      status: 106,
      msg: info,
      data: null,
    };
  }
}
module.exports = CoreController;
