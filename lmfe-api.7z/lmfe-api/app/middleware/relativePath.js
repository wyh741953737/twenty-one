'use strict';
// app/middleware/relativePath.js

// 递归处理某个对象里头的所有资源路径字段
const recuriveGetRelativePath = (ctx, obj) => {
  const host = ctx.request.host;
  const origin = (host.indexOf('http') !== -1 || host.indexOf('https') !== -1) ? host : ctx.request.origin;
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const item = obj[key];
      if (typeof item === 'string' && item.includes(`${origin}/public/uploads`)) {
        try {
          obj[key] = ctx.helper.getRelativeStaticAssetsPath(item);
        } catch (e) {
          throw e;
        }
      }
      if (item && typeof item === 'object' && Object.keys(item).length) {
        recuriveGetRelativePath(ctx, item);
      }
    }
  }
};

// 递归处理某个对象里头的所有资源类型字段
const recuriveAddOrigin = (ctx, obj) => {
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const item = obj[key];
      if (typeof item === 'string' && item.includes('/public/uploads')) {
        try {
          obj[key] = ctx.helper.addOriginForStaticAssets(item);
        } catch (e) {
          throw e;
        }
      }
      if (item && typeof item === 'object' && Object.keys(item).length) {
        recuriveAddOrigin(ctx, item);
      }
    }
  }
};

module.exports = () => {
  return async (ctx, next) => {
    if (ctx.request.method === 'POST' || ctx.request.method === 'PUT') {
      const model = ctx.request.body;
      recuriveGetRelativePath(ctx, model);
    }
    await next();
    const status = ctx.response.status;
    const data = ctx.response.body && ctx.response.body.data;
    if (status === 200 && data && ctx.request.method === 'GET') {
      recuriveAddOrigin(ctx, ctx.response.body);
    }
  };
};
