const fs = require('fs');
const { exec } = require('shelljs');
const { langcnTemplate, langenTemplate, homeTemplate, routerTemplate, storeTemplate, indexTemplate, packageTemplate, gitignoreTemplate, eslintTmplate, readmeTemplate } = require('./template');

const mkdir = (path) => {
  return fs.mkdirSync(path);
};
const appendFile = (path, content) => {
  return fs.appendFileSync(path, content);
};

module.exports = ({ microAppName, title, description, gitDomain, gitMicroAppGroup }) => {
  mkdir(`./package`);
  mkdir(`./package/lang`);
  appendFile(`./package/lang/cn.js`, langcnTemplate(microAppName));
  appendFile(`./package/lang/en.js`, langenTemplate(microAppName));
  mkdir(`./package/pages`);
  mkdir(`./package/pages/home`);
  appendFile(`./package/pages/home/index.vue`, homeTemplate());
  mkdir(`./package/router`);
  appendFile(`./package/router/index.js`, routerTemplate(microAppName));
  mkdir(`./package/store`);
  appendFile(`./package/store/index.js`, storeTemplate(microAppName));
  appendFile(`./package/index.js`, indexTemplate(microAppName));
  appendFile(`./package.json`, packageTemplate(microAppName, title, description, gitDomain, gitMicroAppGroup));
  appendFile(`./.gitignore`, gitignoreTemplate());
  appendFile(`./.eslintrc.js`, eslintTmplate());
  appendFile(`./README.md`, readmeTemplate(microAppName, title, description));
};
