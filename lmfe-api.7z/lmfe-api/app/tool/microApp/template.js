module.exports = {
  langcnTemplate (name) {
    return `const ${name} = {
  ${name}: {
    title: '标题'
  }
}

export default ${name}
`
  },
  langenTemplate (name) {
    return `const ${name} = {
  ${name}: {
    title: '标题'
  }
}

export default ${name}
`
  },
  homeTemplate () {
    return `<template>
  <div>
    666
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  methods: {}
}
</script>

<style lang="scss" scoped>
</style>
`
  },
  routerTemplate (name) {
    return `const routes = [
  {
    path: '/${name}/home',
    name: '/${name}/home',
    component: () => import(/* webpackChunkName: "microApp${name.split('_')[3]}Home" */ '../pages/home'),
    meta: {
      title: '${name}.title'
    }
  }
]

export default routes
`
  },
  storeTemplate (name) {
    return `const ${name} = {
  namespaced: true,
  state: {},
  mutations: {}
}

export default { ${name} }
`
  },
  indexTemplate () {
    return `import router from './router'
import store from './store'
import cn from './lang/cn'
import en from './lang/en'

const lang = { cn, en }

export { router, store, lang }
export default { router, store, lang }
`
  },
  packageTemplate (name, title, description, gitDomain, gitMicroAppGroup) {
    return `{
  "author": {
    "name": "author"
  },
  "keywords": [
    "${name}",
    "app"
  ],
  "title": "${title}",
  "description": "${description}",
  "license": "MIT",
  "main": "package/index.js",
  "name": "${name}",
  "repository": {
    "type": "git",
    "url": "${gitDomain}${gitMicroAppGroup}/${name}.git"
  },
  "scripts": {
    "changelog": "conventional-changelog -p angular -i CHANGELOG.md -s",
    "release": "node node_modules/lm_version_release_plugin/scripts/release.js"
  },
  "version": "0.0.1",
  "gitHooks": {
    "pre-commit": "eslint",
    "commit-msg": "node node_modules/lm_version_release_plugin/scripts/verifyCommit.js"
  },
  "bizDependencies": {},
  "dependencies": {
  },
  "devDependencies": {
    "eslint": "^7.6.0",
    "eslint-plugin-vue": "^6.2.2",
    "lm_version_release_plugin": "git+ssh://git@git.uama.com.cn:lmbusiness/lm_version_release_plugin.git#v1.1.3",
    "yorkie": "2.0.0"
  }

}
`
  },
  gitignoreTemplate () {
    return `.DS_Store
node_modules

# local env files
.env.local
.env.*.local

# Log files
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Editor directories and files
.idea
.vscode
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw*
`
  },
  eslintTmplate () {
    return `module.exports = {
  "env": {
      "browser": true,
      "es2020": true
  },
  "extends": [
      "eslint:recommended",
      "plugin:vue/essential"
  ],
  "parserOptions": {
      "ecmaVersion": 11,
      "sourceType": "module"
  },
  "plugins": [
      "vue"
  ],
  "rules": {
  }
};
  
`
  },
  readmeTemplate (name, title, description) {
    return `# ${name}

${title}

${description}
`
  }
}
