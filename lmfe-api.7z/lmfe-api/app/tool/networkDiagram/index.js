const fs = require('fs');
const path = require('path');
const CryptoJS = require('crypto-js/crypto-js');
const { exec } = require('shelljs');

const config = {
  rootColor: '#FF7F50',
  libs: {
    'remain-ui': {
      color: '#48D1CC'
    },
    'hybrid': {
      color: '#F08080'
    }
  }
};
const libsKey = Object.keys(config.libs);

const encrypt = (word) => {
  if (typeof(word) == 'object') {
    word = JSON.stringify(word);
  }
  const key = CryptoJS.enc.Utf8.parse('0360b05dd94211e5');
  const srcs = CryptoJS.enc.Utf8.parse(word);
  const encrypted = CryptoJS.AES.encrypt(srcs, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  return encrypted.toString();
};

const getPackageJson = (pathname = '') => {
  let packageJson = null
  const packageFilePath = path.resolve(`${pathname}package.json`);
  const hasPackageFile = fs.existsSync(packageFilePath);
  if (hasPackageFile) {
    packageJson = require(packageFilePath);
  }
  return packageJson;
};

const getDependencies = function ({ moduleMaps, visNodes, visEdges }, parentKey, dependencies) {
  if (dependencies) {
    Object.keys(dependencies).forEach(key => {
      if (libsKey.indexOf(key) !== -1) {
        const name = key + '\n\n' + dependencies[key].version;
        const isExist = visNodes.find(item => {
          return item.label === name
        });
        if (!isExist) {
          moduleMaps[name] = visNodes.length;
          visNodes.push({
            id: visNodes.length,
            label: name,
            color: config.libs[key].color
          });
        }
        visEdges.push({
          from: moduleMaps[parentKey],
          to: moduleMaps[name],
          arrows: 'to'
        });
      }
      getDependencies({ moduleMaps, visNodes, visEdges }, key, dependencies[key].dependencies);
    });
  }
};

module.exports = ({ reg }) => {
  const moduleMaps = {};
  const visNodes = []; // 节点
  const visEdges = []; // 连接线

  const packageJson = getPackageJson();
  if (packageJson) {
    const { name, title, version, dependencies } = packageJson;
    if (dependencies) {
      const rootId = 0;
      moduleMaps[name] = rootId;
      visNodes.push({
        id: rootId,
        label: `${title}\n\n${version}`,
        color: config.rootColor
      });
      const moduleNames = Object.keys(dependencies).filter((key) => { return reg.test(key) });
      if (moduleNames && moduleNames.length) {
        // 设置业务模块的节点和连接线
        moduleNames.forEach((moduleItem, moduleIndex) => {
          const modulePackageJson = getPackageJson(`node_modules/${moduleItem}/`);
          const id = moduleIndex + 1;
          moduleMaps[moduleItem] = id;
          visNodes.push({
            id,
            label: `${modulePackageJson.title}\n\n${modulePackageJson.version}`,
            title: `${modulePackageJson.description}`
          });
          visEdges.push({
            from: rootId,
            to: id,
            arrows: 'to'
          });
        });
        moduleNames.forEach(moduleItem => {
          const modulePackageJson = getPackageJson(`node_modules/${moduleItem}/`);
          const bizDependencies = modulePackageJson.bizDependencies;
          if (bizDependencies) {
            Object.keys(bizDependencies).forEach(key => {
              visEdges.push({
                from: moduleMaps[moduleItem],
                to: moduleMaps[key],
                arrows: 'to'
              });
            });
          }
        });
      }
      const targetModules = libsKey.join(' ');
      const { stdout } = exec(`npm ls ${targetModules} --json `, {
        silent: true
      });
      const result = JSON.parse(`${stdout}`);
      getDependencies({ moduleMaps, visNodes, visEdges }, result.name, result.dependencies);
      const query = encrypt({
        visNodes,
        visEdges
      });
      return query;
    }
  }
};
