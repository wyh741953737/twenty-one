/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-12 08:34:57
 */
'use strict';
const BaseService = require('./base');

class IconService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'iconfont';
  }

  // 获取字体图标列表
  async getIconList(model) {
    try {
      const { app } = this;
      const { type } = model;
      let sql = 'select * from iconfont where 1 = 1';
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      const res = this.customList(sql);
      return res;
    } catch (e) {
      throw e;
    }
  }
}

module.exports = IconService;
