/*
 * @Description: 获取费用明细列表
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-06 00:51:40
 */
'use strict';
const BaseService = require('./base');

class FeeDetailService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'feeDetail';
  }


  // web获取费用明细列表（官网使用）
  async getWebFeeDetailList() {
    try {
      const sql = 'select * from fee_detail';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
}

module.exports = FeeDetailService;
