/*
 * @Description: 主要功能
 * @Author: fcc
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-21 11:02:36
 */
'use strict';
const BaseService = require('./base');

class EnterpriseService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'enterprise';
  }


  // web获取企业列表（官网使用）
  async getWebEnterpriseList(model) {
    try {
      const { app } = this;
      const { buildNum, floorNum, vitalityType, safeProductionType, technologicalInnovationType, creditRatingType, enterpriseCooperationType } = model;
      let sql = 'select * from enterprise where 1 = 1';
      if (floorNum) {
        sql += ' and floorNum = ' + app.mysql.escape(floorNum);
      } else if (buildNum) {
        sql += ' and buildNum = ' + app.mysql.escape(buildNum);
      }
      if (vitalityType) {
        sql += ' and vitalityType = ' + app.mysql.escape(vitalityType);
      }
      if (safeProductionType) {
        sql += ' and safeProductionType = ' + app.mysql.escape(safeProductionType);
      }
      if (technologicalInnovationType) {
        sql += ' and technologicalInnovationType = ' + app.mysql.escape(technologicalInnovationType);
      }
      if (creditRatingType) {
        sql += ' and creditRatingType = ' + app.mysql.escape(creditRatingType);
      }
      if (enterpriseCooperationType) {
        sql += ' and enterpriseCooperationType = ' + app.mysql.escape(enterpriseCooperationType);
      }
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
  async getWebEnterpriseById(id) {
    try {
      const { app } = this;
      const enterpriseBase = await app.mysql.get(this.entry, {
        id,
      });
      const sql = 'select * from enterprise_demand where enterpriseId = ?';
      const demandList = await app.mysql.query(sql, id);
      const demandCount = demandList.length;
      const commonDemands = demandList.filter(demand => {
        return demand.type === 2;
      });
      const commonCount = commonDemands.length;
      const vitalDemands = demandList.filter(demand => {
        return demand.type === 1;
      });
      const vitalCount = vitalDemands.length;
      // 已解决需求数据
      const solvedDemands = demandList.filter(demand => {
        return demand.status === 2;
      });
      const solvedCount = solvedDemands.length;
      const solvedRate = demandCount ? parseFloat(solvedCount / demandCount).toFixed(2) : 0.00;
      // 评价数据
      const appraiseDemands = demandList.filter(demand => {
        return demand.appraise !== null;
      });
      const appraiseCount = appraiseDemands.length;
      const goodAppraiseDemands = demandList.filter(demand => {
        return demand.appraise >= 4;
      });
      const goodAppraiseCount = goodAppraiseDemands.length;
      const goodAppraiseRate = appraiseCount ? parseFloat(goodAppraiseCount / appraiseCount).toFixed(2) : 0.00;

      // 未解决重要诉求（按标签统计）
      const unsolvedVitalStatistics = [];
      const unsolvedTagObj = {};
      vitalDemands.forEach(demand => {
        if (demand.status !== 2) {
          if (unsolvedTagObj[demand.tagName]) {
            unsolvedTagObj[demand.tagName].count++;
          } else {
            unsolvedTagObj[demand.tagName] = {
              count: 1,
            };
          }
        }
      });

      const unsolvedTagObjKeys = Object.keys(unsolvedTagObj);
      Array.isArray(unsolvedTagObjKeys) && unsolvedTagObjKeys.forEach(tag => {
        unsolvedVitalStatistics.push({
          name: tag,
          count: unsolvedTagObj[tag].count,
        });
      });
      return {
        enterpriseBase,
        commonCount,
        vitalCount,
        solvedRate,
        goodAppraiseRate,
        unsolvedVitalStatistics,
      };
    } catch (error) {
      throw error;
    }

  }

  async getCountByType(model) {
    try {
      const { app } = this;
      // consol
      const { floorNum } = model;
      const data = {
        vitalityType: {},
        safeProductionType: {},
        enterpriseCooperationType: {},
        technologicalInnovationType: {},
        creditRatingType: {},
      };
      const type = [ 'A', 'B', 'C', 'D' ];
      const keyArr = Object.keys(data);
      for (let j = 0; j < keyArr.length; j++) {
        for (let i = 1; i <= 4; i++) {
          const query = {};
          query[keyArr[j]] = i;
          if (floorNum) {
            query.floorNum = floorNum;
          }
          const total = await app.mysql.count(this.entry, query);
          data[keyArr[j]][type[i - 1]] = total;
        }
      }
      return data;
    } catch (error) {
      throw error;
    }

  }
}

module.exports = EnterpriseService;
