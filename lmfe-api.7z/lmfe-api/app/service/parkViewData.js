/*
 * @Description: 主要功能
 * @Author: fcc
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: FCC
 * @LastEditTime: 2019-12-02 15:10:15
 */
'use strict';
const BaseService = require('./base');

class ParkViewDataService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'park_view_data';
  }
  async getParkViewDataListForWeb(id) {
    try {
      const { app } = this;
      const sql = 'select * from park_view_data where 1 = 1 and parkId = ' + app.mysql.escape(id);
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  async editParkViewDataForWeb(parkId, body) {
    try {
      const paramsArr = Object.keys(body);
      for (let i = 0; i < paramsArr.length; i++) {
        const params = {};
        params.parkId = parkId;
        params.attributeName = paramsArr[i];
        const selectData = await this.app.mysql.get(this.entry, params);
        if (selectData) {
          const { id } = selectData;
          const updateParams = {
            id,
            attributeValue: body[paramsArr[i]],
          };
          await this.app.mysql.update(this.entry, updateParams);
        }
      }
      return 'success';
    } catch (error) {
      throw error;
    }
  }
}

module.exports = ParkViewDataService;
