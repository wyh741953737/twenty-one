'use strict';
const BaseService = require('./base');

class NetworkDiagramService extends BaseService {
  constructor (ctx) {
    super(ctx);
    this.entry = 'network_diagram';
  }

  // 查询网络图列表
  async list (models) {
    try {
      const { app } = this;
      const { name, type, inuser, intimeBegin, intimeEnd, updateUser, updateTimeBegin, updateTimeEnd } = models;
      let sql = `
        select nd.id, nd.name, nd.type, nd.remark, nd.data, nd.inuser, nd.intime, nd.update_user updateUser, nd.update_time updateTime, 
        (select realName from user u where u.id = nd.inuser) as inuserName, 
        (select realName from user u where u.id = nd.update_user) as updateUserName 
        from network_diagram nd 
        where 1 = 1
      `;
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      if (inuser) {
        sql += ' and inuser = ' + app.mysql.escape(inuser);
      }
      if (intimeBegin) {
        sql += ' and intime >= ' + app.mysql.escape(intimeBegin);
      }
      if (intimeEnd) {
        sql += ' and intime <= ' + app.mysql.escape(intimeEnd);
      }
      if (updateUser) {
        sql += ' and update_user = ' + app.mysql.escape(updateUser);
      }
      if (updateTimeBegin) {
        sql += ' and update_time >= ' + app.mysql.escape(updateTimeBegin);
      }
      if (updateTimeEnd) {
        sql += ' and update_time <= ' + app.mysql.escape(updateTimeEnd);
      }
      sql += ' order by intime desc ';
      return await this.customListPage(sql);
    } catch (error) {
      throw error;
    }
  }

  // 新增网络图
  async add (models) {
    try {
      const res = await this.create(models);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 编辑网络图
  async edit (models) {
    const res = await this.update(models);
    return res;
  }
}

module.exports = NetworkDiagramService;
