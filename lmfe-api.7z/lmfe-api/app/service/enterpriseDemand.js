/*
 * @Description: 获取设备详情
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-21 14:26:19
 */
'use strict';
const BaseService = require('./base');

const getLastSixMonth = function() {
  // 获取最近6个月
  const date = new Date();
  let month = date.getMonth() + 1;
  const duringMonth = [];
  let tmpMonth;
  let tmpIndex = 0;
  for (let i = 0; i < 6; i++) {
    tmpMonth = month - tmpIndex;
    if (tmpMonth === 0) {
      tmpMonth = 12;
      month = 12;
      tmpIndex = 0;
    }
    tmpIndex++;
    duringMonth.push(tmpMonth);
  }
  return duringMonth;
};

class EnterpriseDemandService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'enterprise_demand';
  }

  // web获取企业诉求列表（官网使用）
  async getEnterpriseDemandList(model) {
    try {
      const { app } = this;
      const { type } = model;
      let sql;
      let res;
      if (type) {
        sql = 'select demand.*,enterprise.floorNum, enterprise.buildNum from enterprise_demand demand inner join enterprise enterprise on demand.enterpriseId = enterprise.id where demand.type = ?';
        res = await app.mysql.query(sql, type);
      } else {
        sql = 'select demand.*,enterprise.floorNum, enterprise.buildNum from enterprise_demand demand inner join enterprise enterprise on demand.enterpriseId = enterprise.id';
        res = await app.mysql.query(sql);
      }
      return res;
    } catch (error) {
      throw error;
    }
  }
  // web获取诉求概览数据（统计使用）
  async getEnterpriseDemandOverview(model) {
    try {
      const { app } = this;
      const buildNum = model.buildNum;
      const floorNum = model.floorNum;
      let enterpriseList;
      let enterpriseSql;
      if (floorNum) {
        enterpriseSql = 'select id from enterprise where floorNum = ' + app.mysql.escape(floorNum);
      } else if (buildNum) {
        enterpriseSql = 'select id from enterprise where buildNum = ' + app.mysql.escape(buildNum);
      } else {
        enterpriseSql = 'select id from enterprise';
      }
      enterpriseList = await app.mysql.query(enterpriseSql);
      if (!enterpriseList || !enterpriseList.length) {
        return [];
      }
      enterpriseList = enterpriseList.map(enterprise => {
        return `'${enterprise.id}'`;
      });
      const enterpriseListStr = enterpriseList.join(',');
      const sql = 'select * from enterprise_demand where enterpriseId in (' + enterpriseListStr + ')';
      const demandList = await app.mysql.query(sql);
      const demandCount = demandList.length;
      const commonDemands = demandList.filter(demand => {
        return demand.type === 2;
      });
      const commonCount = commonDemands.length;
      const vitalDemands = demandList.filter(demand => {
        return demand.type === 1;
      });
      const vitalCount = vitalDemands.length;
      // 已解决需求数据
      const solvedDemands = demandList.filter(demand => {
        return demand.status === 2;
      });
      const solvedCount = solvedDemands.length;
      const solvedRate = demandCount ? parseFloat(solvedCount / demandCount).toFixed(4) : 0.00;
      // 评价数据
      const appraiseDemands = demandList.filter(demand => {
        return demand.appraise !== null;
      });
      const appraiseCount = appraiseDemands.length;
      const goodAppraiseDemands = demandList.filter(demand => {
        return demand.appraise >= 4;
      });
      const goodAppraiseCount = goodAppraiseDemands.length;
      const goodAppraiseRate = appraiseCount ? parseFloat(goodAppraiseCount / appraiseCount).toFixed(4) : 0.00;

      // 重要诉求（按标签统计）
      const vitalStatistics = [];
      // 未解决重要诉求（按标签统计）
      const unsolvedVitalStatistics = [];
      const tagObj = {};
      const unsolvedTagObj = {};
      vitalDemands.forEach(demand => {
        if (tagObj[demand.tagName]) {
          tagObj[demand.tagName].count++;
        } else {
          tagObj[demand.tagName] = {
            count: 1,
          };
        }
        if (demand.status !== 2) {
          if (unsolvedTagObj[demand.tagName]) {
            unsolvedTagObj[demand.tagName].count++;
          } else {
            unsolvedTagObj[demand.tagName] = {
              count: 1,
            };
          }
        }
      });
      const tagObjKeys = Object.keys(tagObj);
      Array.isArray(tagObjKeys) && tagObjKeys.forEach(tag => {
        vitalStatistics.push({
          name: tag,
          value: tagObj[tag].count,
        });
      });

      const unsolvedTagObjKeys = Object.keys(unsolvedTagObj);
      Array.isArray(unsolvedTagObjKeys) && unsolvedTagObjKeys.forEach(tag => {
        unsolvedVitalStatistics.push({
          name: tag,
          value: unsolvedTagObj[tag].count,
        });
      });

      const duringMonth = getLastSixMonth();
      // 统计最近6个月的处理率
      const solvedStatics = [];
      duringMonth.forEach(month => {
        const currentMonthSolved = solvedDemands.filter(demand => {
          const solveMonth = (new Date(demand.dealTimeEnd)).getMonth() + 1;
          return solveMonth === month;
        });
        const currentMonthSolvedCount = currentMonthSolved.length;
        const currentMonthSolvedRate = solvedCount ? parseFloat(currentMonthSolvedCount / solvedCount).toFixed(4) : 0.00;
        solvedStatics.push({
          month,
          value: currentMonthSolvedRate,
        });
      });
      // 统计最近6个月的好评率
      const goodAppraiseStatics = [];
      duringMonth.forEach(month => {
        const currentMonthAppraised = appraiseDemands.filter(demand => {
          const appraiseMonth = (new Date(demand.appraiseTime)).getMonth() + 1;
          return appraiseMonth === month;
        });
        const currentMonthAppraisedCount = currentMonthAppraised.length;
        const currentMonthAppraisedRate = appraiseCount ? parseFloat(currentMonthAppraisedCount / appraiseCount).toFixed(4) : 0.00;
        goodAppraiseStatics.push({
          month,
          value: currentMonthAppraisedRate,
        });
      });
      return {
        commonCount,
        vitalCount,
        vitalStatistics,
        unsolvedVitalStatistics,
        solvedCount,
        solvedRate,
        goodAppraiseRate,
        solvedStatics: solvedStatics.reverse(),
        goodAppraiseStatics: goodAppraiseStatics.reverse(),
      };
    } catch (error) {
      throw error;
    }
  }
}

module.exports = EnterpriseDemandService;
