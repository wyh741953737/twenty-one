/*
 * @Description:用户的服务类
 * @Author: 木犀
 * @Github: https://github.com/mx
 * @Email: 2374542140@qq.com
 * @Company: 绿漫科技有限公司
 * @Date: 2019-06-24 11:55:34
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-24 14:55:40
 */
'use strict';
const BaseService = require('./base');
const NodeAuth = require('node-auth0');

class UserService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'user';
    this.nodeAuth = new NodeAuth.default(8, 10, true);
  }

  // 用户登录
  async login(body) {
    try {
      const {
        app,
      } = this;
      const {
        name,
        password,
        email,
        mobile,
      } = body;
      let sql = 'select * from user where status = 1 ';
      let _name = '';
      if (name) {
        sql += ' and userName= ? limit 1';
        _name = name;
      } else if (email) {
        sql += ' and email = ? limit 1';
        _name = email;
      } else if (mobile) {
        sql += ' and mobile = ? limit 1';
        _name = mobile;
      }
      // tslint:disable-next-line:array-bracket-spacing
      const user = await app.mysql.query(sql, [ _name ]);
      if (
        user &&
        user.length &&
        this.nodeAuth.checkPassword(password, user[0].password)
      ) {
        delete user[0].password;
        return user[0];
      }
      throw '用户名或者密码错误';
    } catch (e) {
      throw e;
    }
  }

  async getUserList(model) {
    try {
      const { app } = this;
      const { id, realName, status, userName, startTime, endTime } = model;
      let sql = 'select user.*,role_user.role_id as userType from user left join role_user on user.id = role_user.user_id where 1 = 1 ';
      if (id) {
        sql += ' and user.id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and user.status = ' + app.mysql.escape(status);
      }
      if (userName) {
        sql += ' and user.userName = ' + app.mysql.escape(userName);
      }
      if (realName) {
        sql += ' and user.realName like ' + app.mysql.escape(`%${realName}%`);
      }
      if (startTime) {
        sql += ' and user.create_at >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and user.create_at <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by user.create_at desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }
  // 新增用户
  async createUser(model) {
    try {
      const {
        app,
      } = this;
      const result = await app.mysql.beginTransactionScope(async () => {
        // don't commit or rollback by yourself

        if (model.email) {
          const searchRes = await this.ctx.curl(`${app.config.gitDomain}api/v4/users?search=${model.email}`, {
            method: 'GET',
            headers: {
              'PRIVATE-TOKEN': this.app.config.gitInfo.personalAccessToken
            },
            dataType: 'text'
          });
          const searchResData = JSON.parse(searchRes.data);
          if (Array.isArray(searchResData) && searchResData.length > 0) {
            model.gitLabUserId = searchResData[0].id;
          }
        }

        const userModel = Object.assign({}, model);
        const user = await this.create(userModel);
        const userInfo = user;
        await this.service.roleUser.create({
          role_id: model.userType,
          user_id: userInfo.id,
        });
        const role = await this.service.role.show(model.userType);
        return {
          ...user,
          ...{
            roleName: role.name,
          },
        };
      }, this.ctx); // ctx 是当前请求的上下文，如果是在 service 文件中，可以从 `this.ctx` 获取到
      return result;
    } catch (e) {
      throw e;
    }
  }

  // 根据用户名、邮箱、手机号查找用户
  async getUserByUniqueKey(key) {
    try {
      const {
        app,
      } = this;
      const {
        userName,
        email,
        mobile,
      } = key;
      let sql = 'select * from user where';
      let _name = '';
      if (userName) {
        sql += ' userName= ? limit 1';
        _name = userName;
      } else if (email) {
        sql += ' email = ? limit 1';
        _name = email;
      } else if (mobile) {
        sql += ' mobile = ? limit 1';
        _name = mobile;
      }
      // tslint:disable-next-line:array-bracket-spacing
      const user = await app.mysql.query(sql, [ _name ]);
      if (
        user &&
        user.length
      ) {
        delete user[0].password;
        return user[0];
      }
    } catch (e) {
      throw e;
    }
  }

  // 编辑用户
  async updateUser(model) {
    const { app } = this;
    try {
      const role_id = model.userType;
      if (!role_id) {
        // 只需要修改用户表
        const user = await this.update(model);
        const roleId = await this.service.roleUser.getRoleIdByUserId(model.id);
        const role = await this.service.role.show(roleId);
        return {
          ...user,
          ...{
            roleId: role.id,
            roleName: role.name,
          },
        };
      }
      const result = await app.mysql.beginTransactionScope(async () => {
        // don't commit or rollback by yourself
        const user = await this.update(model);
        await this.service.roleUser.updateRoleIdByUserId(role_id, model.id);
        const role = await this.service.role.show(role_id);
        return {
          ...user,
          ...{
            roleId: role.id,
            roleName: role.name,
          },
        };

      }, this.ctx); // ctx 是当前请求的上下文，如果是在 service 文件中，可以从 `this.ctx` 获取到
      return result;
    } catch (e) {
      throw e;
    }
  }
  // 删除用户（修改status为2）
  async deleteUser(id) {
    const { app } = this;
    const res = await app.mysql.beginTransactionScope(async () => {
      // don't commit or rollback by yourself
      await this.update({
        id,
        status: 2
      });
      // await this.delete(id);
      // await this.service.roleUser.deleteUserByUserId(id);
      return true;
    }, this.ctx); // ctx 是当前请求的上下文，如果是在 service 文件中，可以从 `this.ctx` 获取到
    return res;
  }
}

module.exports = UserService;
