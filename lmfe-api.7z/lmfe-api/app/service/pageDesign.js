'use strict';
const BaseService = require('./base');

class PageDesignService extends BaseService {
  constructor (ctx) {
    super(ctx);
    this.entry = 'page_design';
  }

  // 查询页面设计列表
  async list (models) {
    try {
      const { app } = this;
      const { name, inuser, intimeBegin, intimeEnd, updateUser, updateTimeBegin, updateTimeEnd } = models;
      let sql = `
        select pd.id, pd.name, pd.remark, pd.data, pd.inuser, pd.intime, pd.update_user updateUser, pd.update_time updateTime, 
        (select realName from user u where u.id = pd.inuser) as inuserName, 
        (select realName from user u where u.id = pd.update_user) as updateUserName 
        from page_design pd 
        where 1 = 1
      `;
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (inuser) {
        sql += ' and inuser = ' + app.mysql.escape(inuser);
      }
      if (intimeBegin) {
        sql += ' and intime >= ' + app.mysql.escape(intimeBegin);
      }
      if (intimeEnd) {
        sql += ' and intime <= ' + app.mysql.escape(intimeEnd);
      }
      if (updateUser) {
        sql += ' and update_user = ' + app.mysql.escape(updateUser);
      }
      if (updateTimeBegin) {
        sql += ' and update_time >= ' + app.mysql.escape(updateTimeBegin);
      }
      if (updateTimeEnd) {
        sql += ' and update_time <= ' + app.mysql.escape(updateTimeEnd);
      }
      sql += ' order by intime desc ';
      return await this.customListPage(sql);
    } catch (error) {
      throw error;
    }
  }

  // 新增页面设计
  async add (models) {
    try {
      const res = await this.create(models);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 编辑页面设计
  async edit (models) {
    const res = await this.update(models);
    return res;
  }
}

module.exports = PageDesignService;
