/*
 * @Description: 获取设备详情
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-15 18:39:07
 */
'use strict';
const BaseService = require('./base');

class DeviceService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'device';
  }

  // web获取设备列表（官网使用）
  async getWebDeviceList(model) {
    try {
      const { app } = this;
      const { deviceType } = model;
      let sql;
      let res;
      if (deviceType) {
        sql = 'select * from device where deviceType = ?';
        res = await app.mysql.query(sql, deviceType);
      } else {
        sql = 'select * from device';
        res = await app.mysql.query(sql);
      }
      if (res && res.length) {
        for (let j = 0; j < res.length; j++) {
          const device = res[j];
          const alarmSql = 'select * from device_alarm where deviceNum = ? ORDER BY levelType DESC,intime DESC';
          const alarmRes = await app.mysql.query(alarmSql, device.deviceNum);
          if (alarmRes && alarmRes.length) {
          // 有告警
            device.warnStatus = 1;
            device.levelType = alarmRes[0].levelType;
            for (let i = 0; i < alarmRes.length; i++) {
              const alarm = alarmRes[i];
              if (alarm.warnType === 1) {
              // 火警
                device.warnType = 1;
                device.levelType = alarm.levelType;
                break;
              }
            }
            if (device.warnType !== 1) {
              device.warnType = 0;
            }
          } else {
          // 没有告警
            device.warnStatus = 0;
            device.levelType = null;
          }
        }
      }
      return res;
    } catch (error) {
      throw error;
    }
  }
  // web获取设备详情（官网使用）
  async getDeviceByDeviceNum(param) {
    try {
      const { app } = this;
      const deviceNum = param.deviceNum;
      const deviceSql = 'select * from device where deviceNum = ?';
      const res = await app.mysql.query(deviceSql, deviceNum);
      const device = res[0];
      const alarmSql = 'select * from device_alarm where deviceNum = ? ORDER BY levelType DESC,intime DESC';
      const orderSql = 'select * from device_order where deviceNum = ? ORDER BY intime DESC';
      const alarmRes = await app.mysql.query(alarmSql, device.deviceNum);
      const orderRes = await app.mysql.query(orderSql, device.deviceNum);
      if (orderRes && orderRes.length) {
        device.orderData = orderRes[0];
      }
      if (alarmRes && alarmRes.length) {
        // 有告警
        device.warnStatus = 1;
        device.alarmData = alarmRes[0];
        for (let i = 0; i < alarmRes.length; i++) {
          const alarm = alarmRes[i];
          if (alarm.warnType === 1) {
            // 火警
            device.warnType = 1;
            device.alarmData = alarm;
            break;
          }
        }
        if (device.warnType !== 1) {
          device.warnType = 0;
        }
      } else {
        // 没有告警
        device.warnStatus = 0;
      }
      return device;
    } catch (error) {
      throw error;
    }
  }
}

module.exports = DeviceService;
