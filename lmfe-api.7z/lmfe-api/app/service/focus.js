/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 小广
 * @LastEditTime: 2020-02-18 09:36:20
 */
'use strict';
const BaseService = require('./base');

class FocusService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'focus';
  }

  // 获取焦点图列表
  async getFocusList(model) {
    try {
      const { app } = this;
      const { id, name, status, position, type, startTime, endTime } = model;
      let sql = 'select * from focus where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (position) {
        sql += ' and position = ' + app.mysql.escape(position);
      }
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // web获取焦点图（官网使用）
  async getWebFocusList(model) {
    try {
      const { app } = this;
      const { position, status, mobile } = model;

      let sql0 = 'select * from focus where 1 = 1';
      // let sql1 = 'select * from focus where type = 1';
      let sql2 = 'select * from focus where type = 2';

      if (position) {
        sql0 += ' and position =  ' + app.mysql.escape(position);
        // sql1 += ' and position =  ' + app.mysql.escape(position);
        sql2 += ' and position =  ' + app.mysql.escape(position);
      }
      if (status) {
        sql0 += ' and status =  ' + app.mysql.escape(status);
        // sql1 += ' and status =  ' + app.mysql.escape(status);
        sql2 += ' and status =  ' + app.mysql.escape(status);
      }

      // sql1 += ' order by status desc, sort asc, intime desc limit 1 ';

      if (mobile === '1') {
        // 移动端 不要视频
        sql2 += ' order by status desc, sort asc, intime desc limit 3 ';
      } else {
        // PC端，最新修改，瑶瑶要求排序用起来，视频个数不再限制
        sql0 += ' order by status desc, sort asc, intime desc, id asc limit 3 ';
        // sql2 += ' order by status desc, sort asc, intime desc limit 2 ';
      }

      const sql = mobile === '1' ? sql2 : sql0;// `(${sql1}) union all (${sql2}) limit 3`;

      console.log('sqlsqlsqlsql', sql);

      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
  // 新增焦点图
  async addFocus(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑焦点图
  async editFocus(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = FocusService;
