/*
 * @Description: 合作站点service模块
 * @Author: FCC
 * @Date: 2019-09-04 10:48:41
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-26 13:54:55
 */
'use strict';
const BaseService = require('./base');

class CooperationSiteService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'cooperationsite';
  }
  // 获取合作站点（不分页，官网用的）
  async getCooperationSiteListForWeb() {
    try {
      let sql1 = 'select * from cooperationsite where type = 1 and status = 1';
      let sql2 = 'select * from cooperationsite where type = 2 and status = 1';
      let sql3 = 'select * from cooperationsite where type = 3 and status = 1';
      // type=1 最多9个
      sql1 += ' order by status desc, sort asc, intime desc limit 9 ';
      // type=2 最多1个
      sql2 += ' order by status desc, sort asc, intime desc limit 1 ';
      // type=3 最多3个
      sql3 += ' order by status desc, sort asc, intime desc limit 3 ';
      const sql = `(${sql1}) union all (${sql2}) union all (${sql3})`;
      const res = this.customList(sql);
      return res;
    } catch (e) {
      throw e;
    }
  }
  // 获取合作站点
  async getCooperationSiteList(model) {
    try {
      const { app } = this;
      const { id, title, status, type, startTime, endTime } = model;
      let sql = 'select * from cooperationsite where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }

      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }

      if (title) {
        sql += ' and title like ' + app.mysql.escape(`%${title}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }
  // 新增合作站点
  async addCooperationSite(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑招商政策
  async editCooperationSite(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = CooperationSiteService;
