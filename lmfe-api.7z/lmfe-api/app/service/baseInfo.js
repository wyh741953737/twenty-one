/*
 * @Description: 公司基础信息的service
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 10:30:36
 */
'use strict';
const BaseService = require('./base');

class BaseInfoService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'baseinfo';
  }

  // 获取公司基础信息
  async getBaseInfo() {
    try {
      const { app } = this;
      let sql = 'select * from baseinfo ';
      sql += ' order by updateTime desc limit 1';
      const result = await app.mysql.query(sql);
      return result[0];
    } catch (e) {
      throw e;
    }
  }

  // 编辑
  async editBaseInfo(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = BaseInfoService;
