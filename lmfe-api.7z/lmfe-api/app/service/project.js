'use strict';
const BaseService = require('./base');

class ProjectService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'project_info';
  }

  // 查询项目列表
  async list (models) {
    try {
      const { app } = this;
      const { name, ownerA, ownerB, intimeBegin, intimeEnd, updateTimeBegin, updateTimeEnd } = models;
      let sql = `
        select pi.id, pi.name, pi.code, pi.end_type endType, pi.unit_type unitType, pi.repository, pi.branch, pi.dir, pi.prefix, pi.ownerA, pi.ownerB, pi.intime, pi.inuser, pi.update_time updateTime, pi.update_user updateUser, 
        (select realName from user u where u.id = pi.ownerA) as ownerAName, 
        (select realName from user u where u.id = pi.ownerB) as ownerBName, 
        (select realName from user u where u.id = pi.inuser) as inuserName, 
        (select realName from user u where u.id = pi.update_user) as updateUserName 
        from project_info pi 
        where 1 = 1
      `;
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (ownerA) {
        sql += ' and ownerA = ' + app.mysql.escape(ownerA);
      }
      if (ownerB) {
        sql += ' and ownerB = ' + app.mysql.escape(ownerB);
      }
      if (intimeBegin) {
        sql += ' and intime >= ' + app.mysql.escape(intimeBegin);
      }
      if (intimeEnd) {
        sql += ' and intime <= ' + app.mysql.escape(intimeEnd);
      }
      if (updateTimeBegin) {
        sql += ' and updateTime >= ' + app.mysql.escape(updateTimeBegin);
      }
      if (updateTimeEnd) {
        sql += ' and updateTime <= ' + app.mysql.escape(updateTimeEnd);
      }
      sql += ' order by intime desc ';
      const res = await this.customListPage(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 查询项目详情
  async detail (id) {
    try {
      const { app } = this;
      const sql = `
        select pi.id, pi.name, pi.code, pi.end_type endType, pi.unit_type unitType, pi.repository, pi.branch, pi.dir, pi.prefix, pi.ownerA, pi.ownerB 
        from project_info pi 
        where id = ?
      `;
      const res = await app.mysql.query(sql, id);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 新增项目
  async add (models) {
    try {
      const res = await this.create(models);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 编辑项目
  async edit (models) {
    const res = await this.update(models);
    return res;
  }

  // 构建项目
  async build (models) {
    try {
      const { ctx } = this;
      const { id } = models;
      const project = await this.show(id);
      if (!project) {
        throw '构建项目失败，请联系管理员处理，errCode：101';
      }
      const { repository, branch, dir } = project;
      const result = await ctx.helper.buildForProject({ repository, branch, dir });
      if (!result) {
        throw '构建项目失败，请联系管理员处理，errCode：102';
      }
      return id;
    } catch (e) {
      throw e;
    }
  }

  // 发布项目
  async releaseVersion (models, recordModels) {
    try {
      const { app, ctx } = this;
      const { id, version } = models;
      const project = await this.show(id);
      if (!project) {
        throw '项目不存在'
      }
      const { name, repository, branch, dir, prefix } = project;
      const result = await ctx.helper.releaseVersionForProject({ repository, branch, dir, version });
      if (!result) {
        throw '发布失败'
      }
      const user = ctx.session.user;
      const reg = new RegExp(`^${prefix}`);
      const data = ctx.helper.getNetworkDiagramData({
        repository,
        branch,
        dir,
        reg
      });
      const networkDiagramModels = {
        name: `${name} v${version}`,
        type: 1,
        data,
        remark: `${name} v${version}`,
        inuser: user.id,
        update_user: user.id
      };
      const networkDiagramRes = await app.mysql.insert('network_diagram', networkDiagramModels);
      const res = await app.mysql.insert('release_record', recordModels);
      if (res.insertId !== undefined) {
        const detailModels = await app.mysql.query(`
          select rr.id, rr.inuser, DATE_FORMAT(rr.intime,'%Y-%m-%d %H:%i:%s') as intime, u.realName as inuserName, m.unit_type as unitType from release_record rr 
          join user u 
          on (u.id = rr.inuser) 
          join project_info m 
          on (m.id = rr.unit_id) 
          where rr.type = 2 
          and rr.id = ?
        `, res.insertId);
        if (Array.isArray(detailModels) && detailModels.length) {
          const { unitType, intime, inuserName } = detailModels[0];
          const link = repository.replace('.git', '') + '/blob/' + branch + (dir ? '/' + dir : '') + '/CHANGELOG.md'
          const unitTypeMap = {
            1: '楼宇单元',
            2: '社区单元',
            3: '物联网单元'
          }
          const unitTypeName = unitTypeMap[unitType];
          let markdownText = '**发布类型：** 主项目\n\n' +
                             '**发布单元：** ' + unitTypeName + '\n\n' +
                             '**发布名称：** ' + name + '\n\n' +
                             '**发布版本：** v' + version + '\n\n' +
                             '**发布时间：** ' + intime + '\n\n' +
                             '**发布人员：** ' + inuserName + '\n\n' +
                             '**发布内容：** [查看详情](' + link + ')';

          if (networkDiagramRes.insertId !== undefined) {
            const docURL = `http://wiki.uama.cc:8082/remain_module_dependency/index.html?id=${networkDiagramRes.insertId}`;
            markdownText += '\n\n**微应用依赖关系图：** [' + docURL + '](' + docURL + ')';
          }

          await ctx.curl(`https://oapi.dingtalk.com/robot/send?access_token=${app.config.dingTalkAccessToken}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            dataType: 'text',
            data: {
              'msgtype': 'markdown',
              'markdown': {
                'title': `【${unitTypeName}】【${name}】发布新版本`,
                'text': markdownText
              },
              'at': {
                'isAtAll': true
              }
            }
          });
        }
      }
      return id;
    } catch (e) {
      throw e;
    }
  }

  // 查询项目发布记录
  async releaseRecord (id) {
    try {
      const { app } = this;
      const sql = `
        select rr.id, rr.version, rr.inuser, rr.intime, 
        (select realName from user u where u.id = rr.inuser) as inuserName 
        from release_record rr 
        where type = 2 
        and unit_id = ? 
        order by intime desc
      `;
      const res = await app.mysql.query(sql, id);
      return res;
    } catch (e) {
      throw e;
    }
  }
}

module.exports = ProjectService;
