/*
 * @Description: 新闻的service模块
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 小广
 * @LastEditTime: 2020-04-08 14:18:31
 */
'use strict';
const BaseService = require('./base');
const await = require('await-stream-ready/lib/await');

class OrderService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'order';
  }

  // 获取工单列表
  async getOrderList(model) {
    try {
      const { app, ctx } = this;
      const user = ctx.session.user;
      console.log(111, user)
      const { id, title, status, microAppId, intimeBegin, intimeEnd, auditTimeBegin, auditTimeEnd } = model;
      let sql = 'select o.*, m.appName from `order` o left join micro_app m on o.microAppId = m.id where 1 = 1';
      if (id) {
        sql += ' and o.id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      // 普通管理员只能看到自己提交的工单
      // if (user.userType === 2) {
      //   sql += ' and o.createUserEmail = ' + app.mysql.escape(user.email);
      // }
      if (title) {
        sql += ' and o.title like ' + app.mysql.escape(`%${title}%`);
      }
      if (status) {
        sql += ' and o.status = ' + app.mysql.escape(status);
      }
      if (microAppId) {
        sql += ' and o.microAppId = ' + app.mysql.escape(microAppId);
      }
      if (intimeBegin) {
        sql += ' and o.intime >= ' + app.mysql.escape(intimeBegin);
      }
      if (intimeEnd) {
        sql += ' and o.intime <= ' + app.mysql.escape(intimeEnd);
      }
      if (auditTimeBegin) {
        sql += ' and o.auditTime >= ' + app.mysql.escape(auditTimeBegin);
      }
      if (auditTimeEnd) {
        sql += ' and o.auditTime <= ' + app.mysql.escape(auditTimeEnd);
      }
      // sql += ' order by status desc, sort asc, intime desc ';
      sql += ' order by o.intime desc, o.id desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 新增工单
  async addOrder(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑工单
  async editOrder(model) {
    const res = await this.update(model);
    return res;
  }
  // 复制工单
  async copyOrder(model) {
    const order = await this.service.order.show(model.id)
    let res = {}
    if (order && order.id) {
      // 删除部分字段
      delete order.id
      delete order.intime
      delete order.updateTime
      delete order.auditTime
      delete order.auditUserName
      delete order.auditUserEmail
      delete order.refuseReason
      delete order.executeLog
      const { ctx } = this;
      const user = ctx.session.user;
      // 更新部分字段
      order.status = 0
      order.createUserName = user.userName
      order.createUserEmail = user.email
      res = await this.create(order);
    }
    return res;
  }
  // 审核工单
  async updateOrderStatus(model) {
    const { app, ctx } = this;
    try {
      const { status, id } = model;
      if (status === 2) {
        const res = await this.update(model);
        return res;
      } else {
        // 执行事务
        const result = await app.mysql.beginTransactionScope(async () => {
          // don't commit or rollback by yourself
          const order = await this.service.order.show(id);
          const microApp = await this.service.microApp.show(order.microAppId);
          order.repository = microApp.repository;
          // 执行脚本逻辑
          const { code, log} = await ctx.helper.installPackage(order)
          if (code === 100) {
            model.executeLog = log;
            const res = await this.update(model);
            return res;
          } else {
            throw '出错啦'
          }
        }, this.ctx); // ctx 是当前请求的上下文，如果是在 service 文件中，可以从 `this.ctx` 获取到
        return result;
      }
    } catch (e) {
      throw e;
    }
  }
}

module.exports = OrderService;
