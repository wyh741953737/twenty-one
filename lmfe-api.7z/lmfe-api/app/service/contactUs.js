/*
 * @Description: 联系我们的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-26 13:55:37
 */
'use strict';
const BaseService = require('./base');

class ContactUsService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'contactus';
  }

  // 获取联系我们列表
  async getContactUsList(model) {
    try {
      const { app } = this;
      const { id, name, status, companyName, mobile, startTime, endTime } = model;
      let sql = 'select * from contactus where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (companyName) {
        sql += ' and companyName like ' + app.mysql.escape(`%${companyName}%`);
      }
      if (mobile) {
        sql += ' and mobile like ' + app.mysql.escape(`%${mobile}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 新增
  async addContactUs(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editContactUs(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = ContactUsService;

