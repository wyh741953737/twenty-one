/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-20 21:10:16
 */
'use strict';
const BaseService = require('./base');

class RoleResourceService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'role_resource';
  }
  // 根据角色获取资源列表
  async getResourceListById(roleId) {
    try {
      const { app } = this;
      const sql = `SELECT resource.* from role_resource left join resource on resource.id = 
        role_resource.resource_id where role_resource.role_id = ? `;
      const result = await app.mysql.query(sql, [ roleId ]);
      return result;
    } catch (e) {
      throw e;
    }
  }
  // 递归处理资源信息
  recursiveDealResourceList(list, pId) {
    const tree = [];
    let temp;
    for (let i = 0; i < list.length; i++) {
      if (list[i].parent_id === pId && list[i].visible === 1) {
        const obj = list[i];
        temp = this.recursiveDealResourceList(list, list[i].id);
        if (temp.length > 0) {
          obj.subResourceInfo = temp;
        } else {
          obj.subResourceInfo = [];
        }
        tree.push(obj);
      }
    }
    return tree;
  }
  // 根据角色获取角色所拥有的资源信息
  async recursiveGetResourceByRoleId(roleId) {
    const res = await this.getResourceListById(roleId);
    const tmpResourceList = res;
    const resourceList = this.recursiveDealResourceList(tmpResourceList, 0);
    return resourceList;
  }
}
module.exports = RoleResourceService;
