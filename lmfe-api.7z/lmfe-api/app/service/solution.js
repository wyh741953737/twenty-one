/*
 * @Description: 解决方案的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-27 11:06:22
 */
'use strict';
const BaseService = require('./base');

class SolutionService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'solution';
  }


  // web获取列表数据（官网使用）
  async getSolutionListForWeb(model) {
    try {
      const { app } = this;
      const { status } = model;
      let sql = 'select * from solution where 1 = 1';
      if (status) {
        sql += ' and status =  ' + app.mysql.escape(status);
      }
      sql += ' order by status desc, sort asc, intime desc limit 5 ';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 获取列表数据
  async getSolutionList(model) {
    try {
      const { app } = this;
      const { id, title, typeName, status, startTime, endTime } = model;
      let sql = 'select * from solution where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (title) {
        sql += ' and title like ' + app.mysql.escape(`%${title}%`);
      }
      if (typeName) {
        sql += ' and typeName like ' + app.mysql.escape(`%${typeName}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }


  // 新增
  async addSolution(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editSolution(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = SolutionService;

