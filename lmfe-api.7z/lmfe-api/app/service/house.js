/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: FCC
 * @LastEditTime: 2019-12-10 14:51:57
 */
'use strict';
const BaseService = require('./base');

class HouseService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'house';
  }


  // web获取焦点图（官网使用）
  async getWebHouseList() {
    try {
      const sql = 'select * from house';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
  async getWebHouseById(houseId) {
    const { app } = this;
    const result = await app.mysql.get(this.entry, {
      houseId,
    });
    return result;
  }
  // web模糊搜索
  async getWebHouseListBySearch(model) {
    try {
      const { app } = this;
      const { maxArea, minArea, maxRentalPrice, minRentalPrice, vacantStatus, name } = model;
      let sql = 'select * from house where 1 = 1';
      if (name) {
        sql += ' and (houseId LIKE ' + app.mysql.escape(`%${name}%`) + ' OR settledEnterprise LIKE ' + app.mysql.escape(`%${name}%`) + ')';
      }
      if (minRentalPrice) {
        sql += ' and area * rentalPrice * 30 > ' + app.mysql.escape(minRentalPrice);
      }
      if (maxRentalPrice) {
        sql += ' and area * rentalPrice * 30 < ' + app.mysql.escape(maxRentalPrice);
      }
      if (minArea) {
        sql += ' and area > ' + app.mysql.escape(Number(minArea));
      }
      if (maxArea) {
        sql += ' and area < ' + app.mysql.escape(Number(maxArea));
      }
      if (vacantStatus) {
        if (Number(vacantStatus) === 0) {
          sql += ' and status = 0';
        } else if (Number(vacantStatus) === 1) {
          sql += ' and endDate < date_sub(curdate(),interval -3 month)';
        } else if (Number(vacantStatus) === 2) {
          sql += ' and endDate < date_sub(curdate(),interval -6 month)';
        }
      }
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }

  }
}

module.exports = HouseService;
