/*
 * @Description: 服务案例的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-12-03 09:41:54
 */
'use strict';
const BaseService = require('./base');

class ServiceCaseService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'servicecase';
  }

  // web获取列表数据（官网使用）
  async getServiceCaseListForWeb(model) {
    try {
      const { app } = this;
      const { status, type } = model;
      let sql = 'select * from servicecase where 1 = 1';
      if (status) {
        sql += ' and status =  ' + app.mysql.escape(status);
      }
      if (type) {
        // 传了类型，就有个数限制
        sql += ' and type =  ' + app.mysql.escape(type);
        sql += ' order by status desc, sort asc, intime desc limit 10 ';
      } else {
        // 不传类型，查询全部，无个数限制
        sql += ' order by status desc, sort asc, intime desc ';
      }
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 获取列表数据
  async getServiceCaseList(model) {
    try {
      const { app } = this;
      const { id, name, status, type, jumpType, startTime, endTime } = model;
      let sql = 'select * from servicecase where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      if (jumpType) {
        sql += ' and jumpType = ' + app.mysql.escape(jumpType);
      }
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 新增
  async addServiceCase(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editServiceCase(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = ServiceCaseService;

