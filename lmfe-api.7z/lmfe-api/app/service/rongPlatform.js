/*
 * @Description: 融平台模块的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-10 17:20:53
 */
'use strict';
const BaseService = require('./base');

class RongPlatformService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'rong_platform';
  }

  // 获取列表数据
  async getRongPlatformList(model) {
    try {
      const { app } = this;
      const { id, title, status, type, startTime, endTime } = model;
      let sql = 'select * from rong_platform where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (title) {
        sql += ' and title like ' + app.mysql.escape(`%${title}%`);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // web获取列表数据（官网使用）
  async getRongPlatformListForWeb(model) {
    try {
      const { app } = this;
      const { status, limit, type } = model;
      let sql = 'select * from rong_platform where 1 = 1';
      if (status) {
        sql += ' and status =  ' + app.mysql.escape(status);
      }
      if (type) {
        sql += ' and type =  ' + app.mysql.escape(type);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      if (limit) {
        sql += ' limit ' + app.mysql.escape(limit);
      }
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 新增
  async addRongPlatform(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editRongPlatform(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = RongPlatformService;

