/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-23 11:28:04
 */
'use strict';
const BaseService = require('./base');

class RoleService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'role';
  }

  async getRoleList(model) {
    const { app } = this;
    const { id, name, startTime, endTime } = model;
    let sql = 'select * from role where 1 = 1';
    if (id) {
      sql += ' and id = ? ';
      return this.customListPage(sql, [ id ]);
    }
    if (name) {
      sql += ' and name like ' + app.mysql.escape(`%${name}%`);
    }
    if (startTime) {
      sql += ' and create_at >= ' + app.mysql.escape(startTime);
    }
    if (endTime) {
      sql += ' and create_at <= ' + app.mysql.escape(endTime);
    }
    return this.customListPage(sql);

  }
}

module.exports = RoleService;
