'use strict';
const BaseService = require('./base');

class branchService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'branch_info';
  }

  // 查询项目分支列表
  async selectBranch (id, name) {
    try {
      const { ctx, app } = this;
      const sql = `select repository from project_info where id = ?`;
      const res = await app.mysql.query(sql, id);
      const result = res[0];
      let { code, data} = await ctx.helper.getBranchList(result)
      if (code === 100) {
        if (name) {
          data = data.filter(item => {
            return item.lable.indexOf(name) > -1
          })
        }
        return data;
      } else {
        return []
      }
    } catch (e) {
      throw e;
    }
  }
  // 查询项目tag列表
  async selectTag (id, name) {
    try {
      const { ctx, app } = this;
      const sql = `select repository from project_info where id = ?`;
      const res = await app.mysql.query(sql, id);
      const result = res[0];
      let { code, data} = await ctx.helper.getTagList(result)
      if (code === 100) {
        if (name) {
          data = data.filter(item => {
            return item.lable.indexOf(name) > -1
          })
        }
        return data;
      } else {
        return []
      }
    } catch (e) {
      throw e;
    }
  }

  // 新建分支
  async add (models) {
    const { ctx, app } = this;
    try {
      let { projectId, name, source, sourceBranch, sourceTag, sourceCommit, remark } = models
      const projectSql = `select repository from project_info where id = ?`;
      const projectRes = await app.mysql.query(projectSql, projectId);
      let commitId
      if (source === 1) {
        commitId = sourceBranch
      } else if (source === 2) {
        commitId = sourceTag
      } else if (source === 3) {
        commitId = sourceCommit
      }
      const createBranchParams = {
        repository: projectRes[0].repository,
        commitId,
        name,
        source
      }
      await ctx.helper.createBranch(createBranchParams)
      let result = await app.mysql.insert('branch_info', models);
      console.log(result)
      return { id: result.insertId};
    } catch (error) {
      throw error;
    }
  }

  // 编辑分支
  async edit (models) {
    const res = await this.update(models);
    return res;
  }

  // 分支列表
  async list (models) {
    try {
      const { app } = this;
      const { name, projectId, source, sourceBranch, sourceTag, sourceCommit, remark, inuser, startTime, endTime } = models;
      let sql = `select  b.*,p.name as projet_name from branch_info b left join project_info p on b.projectId = p.id where isDelete = 0`;
      if (name) {
        sql += ' and b.name like ' + app.mysql.escape(`%${name}%`);
      }
      if (projectId) {
        sql += ' and b.projectId = ' + app.mysql.escape(projectId);
      }
      if (source) {
        sql += ' and b.source = ' + app.mysql.escape(source);
      }
      if (sourceBranch) {
        sql += ' and b.sourceBranch = ' + app.mysql.escape(sourceBranch);
      }
      if (sourceTag) {
        sql += ' and b.sourceTag = ' + app.mysql.escape(sourceTag);
      }
      if (sourceCommit) {
        sql += ' and b.sourceCommit = ' + app.mysql.escape(sourceCommit);
      }
      if (remark) {
        sql += ' and b.remark like ' + app.mysql.escape(`%${remark}%`);
      }
      if (inuser) {
        sql += ' and b.inuser = ' + app.mysql.escape(inuser);
      }
      if (startTime) {
        sql += ' and b.inTime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and b.inTime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by b.intime desc ';
      const res = await this.customListPage(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 分支详情
  async detail (id) {
    try {
      const { app } = this;
      const sql = `select b.*, p.name as projectName from branch_info b left join project_info p on b.projectId = p.id where b.id = ?`;
      const res = await app.mysql.query(sql, id);
      return res[0];
    } catch (error) {
      throw error;
    }
  }

  // 删除分支
  async deleteBranch (id) {
    try {
      const { ctx, app } = this;
      const sql = `update branch_info set isDelete = 1 where id = ?`;
      const res = await app.mysql.query(sql, id);
      if (res.affectedRows === 1) {
        return true
      } else {
        return false
      }
    } catch (e) {
      throw e;
    }
  }

  // 项目列表select2
  async projectSelect2 (models) {
    try {
      const { ctx, app } = this;
      let { name, id } = models
      let sql = `select name, id from project_info where 1 = 1`
      if (name) {
        sql += ' and name like ' + app.mysql.escape(`%${name.trim()}%`);
      }
      if (id) {
        sql += ' and id = ' + app.mysql.escape(id);
      }
      const res = await app.mysql.query(sql)
      return res;
    } catch (e) {
      throw e;
    }
  }
}

module.exports = branchService;
