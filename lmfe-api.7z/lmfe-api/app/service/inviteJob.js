/*
 * @Description: 招聘信息的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: FCC
 * @LastEditTime: 2019-11-03 01:03:06
 */
'use strict';
const BaseService = require('./base');

class InviteJobService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'invitejob';
  }

  // 获取列表数据
  async getInviteJobList(model) {
    try {
      const { app } = this;
      const { id, jobName, status, type, startTime, endTime } = model;
      let sql = 'select * from invitejob where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (type) {
        sql += ' and type = ' + app.mysql.escape(type);
      }
      if (jobName) {
        sql += ' and jobName like ' + app.mysql.escape(`%${jobName}%`);
      }
      if (startTime) {
        sql += ' and intime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and intime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, sort asc, intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 新增
  async addInviteJob(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editInviteJob(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = InviteJobService;

