/*
 * @Description: 封装基础的服务层
 * @Author: 木犀
 * @Github: https://github.com/mx
 * @Email: 2374542140@qq.com
 * @Company: 绿漫科技有限公司
 * @Date: 2019-06-24 11:08:22
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-23 11:26:52
 */
'use strict';
const CoreService = require('../core/coreService');

class BaseService extends CoreService {
  async list(pageNum, pageSize, where) {
    const { app } = this;
    const data = await app.mysql.select(this.entry, {
      where,
      order: [[ 'update_at', 'desc' ], [ 'create_at', 'desc' ]],
      offset: (pageNum - 1) * pageSize,
      limit: pageSize,
    });
    const total = await app.mysql.count(this.entry, where);
    const maxPage = Math.ceil(total / pageSize);
    const nextPage = (pageNum + 1) < maxPage ? (pageNum + 1) : maxPage;
    const previousPage = (pageNum - 1) < 1 ? 1 : (pageNum - 1);
    return {
      resultList: data,
      previousPage,
      curPage: pageNum,
      nextPage,
      maxPage,
      maxRow: total,
      row: pageSize,
      starRow: 0,
    };
  }
  // 自定义sql的列表(分页)查询通用方法
  async customListPage(sql, where) {
    const { app } = this;
    let res = await app.mysql.query(sql, where);
    const total = res.length;
    sql = this.setListPageParam(sql);
    res = await app.mysql.query(sql, where);
    return this.setListResponse(res, total);
  }

  // 自定义sql的列表(不需分页)查询通用方法
  async customList(sql, where) {
    const { app } = this;
    const res = await app.mysql.query(sql, where);
    return res;
  }

  // 拼接分页语句
  setListPageParam(sql) {
    const { ctx } = this;
    let { curPage, pageSize } = ctx.query;
    curPage = isNaN(curPage) ? 1 : parseInt(curPage);
    pageSize = isNaN(pageSize) ? this.config.pageSize : parseInt(pageSize);
    const start = (curPage - 1) * pageSize;
    return `${sql} limit ${start},${pageSize}`;
  }

  // 通用设置列表页接口的返回值
  setListResponse(data, total) {
    const { ctx } = this;
    let { curPage, pageSize } = ctx.query;
    curPage = isNaN(curPage) ? 1 : parseInt(curPage);
    pageSize = isNaN(pageSize) ? this.config.pageSize : parseInt(pageSize);
    const maxPage = Math.ceil(total / pageSize);
    const nextPage = (curPage + 1) < maxPage ? (curPage + 1) : maxPage;
    const previousPage = (curPage - 1) < 1 ? 1 : (curPage - 1);
    return {
      resultList: data,
      previousPage,
      curPage,
      nextPage,
      maxPage,
      maxRow: total,
      row: pageSize,
      starRow: 0,
    };
  }

  async show(id) {
    const { app } = this;
    const result = await app.mysql.get(this.entry, {
      id,
    });
    return result;
  }

  async create(model) {
    try {
      const { app } = this;
      const { affectedRows, insertId } = await app.mysql.insert(
        this.entry,
        model
      );
      if (affectedRows) {
        if (insertId) {
          const result = await this.show(insertId);
          delete result.password;
          return result;
        }
        return {};
      }
      throw '插入数据失败';
    } catch (e) {
      throw e;
    }
  }

  async update(model) {
    try {
      const { app } = this;
      const { affectedRows } = await app.mysql.update(this.entry, model);
      if (affectedRows) {
        return await this.show(model.id);
      }
      throw '修改数据失败';
    } catch (e) {
      throw '修改数据失败';
    }
  }

  async delete(id) {
    const { app } = this;
    const { affectedRows } = await app.mysql.delete(this.entry, {
      id,
    });
    if (affectedRows) {
      return true;
    }
    throw '删除失败';
  }
}

module.exports = BaseService;
