/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 小广
 * @LastEditTime: 2020-02-18 09:36:20
 */
'use strict';
const BaseService = require('./base');

class MicroAppService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'micro_app';
  }

  // 获取微应用列表
  async getMicroAppList(model) {
    try {
      const { app, ctx } = this;
      const user = ctx.session.user;
      const { id, appName, code, endType, unitType, status, ownerA, ownerB, intimeBegin, intimeEnd, lastEditTimeBegin, lastEditTimeEnd } = model;
      let sql = 'select m.*,(SELECT realName FROM user u WHERE u.id = m.ownerA) as ownerAName, (SELECT realName FROM user u WHERE u.id = m.ownerB)  as ownerBName  from micro_app m where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (endType) {
        sql += ' and endType = ' + app.mysql.escape(endType);
      }
      if (unitType) {
        sql += ' and unitType = ' + app.mysql.escape(unitType);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (appName) {
        sql += ' and appName like ' + app.mysql.escape(`%${appName}%`);
      }
      if (code) {
        sql += ' and code = ' + app.mysql.escape(code);
      }
      if (ownerA) {
        sql += ' and ownerA = ' + app.mysql.escape(ownerA);
      }
      if (ownerB) {
        sql += ' and ownerB = ' + app.mysql.escape(ownerB);
      }
      if (intimeBegin) {
        sql += ' and intime >= ' + app.mysql.escape(intimeBegin);
      }
      if (intimeEnd) {
        sql += ' and intime <= ' + app.mysql.escape(intimeEnd);
      }
      if (lastEditTimeBegin) {
        sql += ' and lastEditTime >= ' + app.mysql.escape(lastEditTimeBegin);
      }
      if (lastEditTimeEnd) {
        sql += ' and lastEditTime <= ' + app.mysql.escape(lastEditTimeEnd);
      }
      sql += ' order by intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 模糊搜索微应用
  async getMicroAppSelect2(model) {
    try {
      const { app, ctx } = this;
      const user = ctx.session.user;
      const { id, code, appName } = model;
      let sql = 'select m.id, m.code, m.appName, m.featureBranches from micro_app m where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (code) {
        sql += ' and code = ? ';
        return this.customListPage(sql, [ code ]);
      }
      // 普通管理员只能看到自己负责的微应用
      if (user.userType === 2) {
        sql += ` and (m.ownerA = ${app.mysql.escape(user.id)} or m.ownerB = ${app.mysql.escape(user.id)})`;
      }
      if (appName) {
        sql += ' and appName like ' + app.mysql.escape(`%${appName}%`);
      }
      sql += ' order by intime desc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // 获取微应用分支列表
  async getBranchListById(model) {
    const { app, ctx } = this;
    const { id } = model
    const microApp = await this.show(id);
    if (microApp) {
      const { repository } = microApp
      const { code, data} = await ctx.helper.getBranchList({ repository })
      if (code === 100) {
        return data;
      } else {
        return []
      }
    } else {
      throw '找不到对应的微应用'
    }
  }

  // 新增微应用
  async addMicroApp(model) {
    const { app, ctx } = this;
    let microAppName = '';
    if ([1, 2, 3].includes(model.endType)) {
      microAppName = `LM_FE_H5_${model.repository}`;
    } else if ([4].includes(model.endType)) {
      microAppName = `LM_FE_Manager_${model.repository}`;
    }
    if (microAppName !== '') {
      const dependencies = [];
      const dependenciesKeys = JSON.parse(model.dependencies);
      if (Array.isArray(dependenciesKeys) && dependenciesKeys.length > 0) {
        for (let i = 0; i < dependenciesKeys.length; i++) {
          const dependenciesKey = dependenciesKeys[i];
          const microAppRes = await app.mysql.query(`
            select rr.version, 
            (select ma.repository2 
              from micro_app ma 
              where appName = '${dependenciesKey}' ) as repository2
            from release_record rr 
            where type = 1 
            and unit_id = (select ma.id 
            from micro_app ma 
            where appName = '${dependenciesKey}' )
            order by intime desc
          `);
          if (Array.isArray(microAppRes) && microAppRes.length > 0) {
            dependencies.push(`${microAppRes[0].repository2}#v${microAppRes[0].version}`);
          }
        }
      }
      delete model.dependencies;
      model.code = microAppName;
      model.repository = `${app.config.gitDomain}${app.config.gitMicroAppGroup}/${microAppName}`;
      const res = await this.create(model);
      const detailModels = await app.mysql.query(`
        select ua.gitLabUserId as gitLabUserIdA, ub.gitLabUserId as gitLabUserIdB, u.realName as inuserName, DATE_FORMAT(ma.intime,'%Y-%m-%d %H:%i:%s') as intime from micro_app ma 
        join user u 
        on (u.id = ma.inuser) 
        join user ua 
        on (ua.id = ma.ownerA) 
        join user ub 
        on (ub.id = ma.ownerB) 
        and ma.id = ?
      `, res.id);
      if (Array.isArray(detailModels) && detailModels.length) {
        const { gitLabUserIdA, gitLabUserIdB, intime, inuserName } = detailModels[0];
        const title = res.appName;
        const description = res.description;
        const repository = res.repository;
        const setupProjectResult = await ctx.helper.setupProject({ microAppName, title, description, repository, dependencies });
        if (setupProjectResult) {
          await ctx.helper.configRepository({ microAppName, title, description, gitLabUserIds: [gitLabUserIdA, gitLabUserIdB] });
          const markdownText = '**创建类型：** 微应用\n\n' +
                              '**创建名称：** ' + title + '\n\n' +
                              '**创建时间：** ' + intime + '\n\n' +
                              '**创建人员：** ' + inuserName + '\n\n' +
                              '**仓库地址：** [' + repository + '](' + repository + ')';
          await ctx.helper.noticeDingTalk({
            title: `【创建微应用】【${title}】`,
            markdownText
          });
        } else {
          await this.delete(res.id);
          throw '微应用仓库已存在'
        }
      }
      return res;
    } else {
      throw '创建微应用失败'
    }
  }
  // 编辑微应用
  async editMicroApp(model) {
    const res = await this.update(model);
    return res;
  }

  // 发布微应用
  async releaseVersion (models, recordModels) {
    try {
      const { app, ctx } = this;
      const { id, version } = models;
      const jenkinsAction = async ({ submitURL, fetchDetailURL, fetchResultURL, success, fail, complete }) => {
        await ctx.curl(submitURL);
        const jenkinsResult = await ctx.curl(fetchDetailURL, {
          dataType: 'text'
        });
        if (jenkinsResult && jenkinsResult.data) {
          let jenkinsResultData = null;
          try {
            jenkinsResultData = JSON.parse(jenkinsResult.data);
          } catch {}
          if (jenkinsResultData !== null) {
            const lastBuildNumber = jenkinsResultData.lastBuild.number;
            const checkResult = async ({ times }) => {
              console.log('查询剩余次数：', times);
              const jenkinsBuildResult = await ctx.curl(fetchResultURL.replace('${id}', lastBuildNumber), {
                dataType: 'text'
              });
              if (jenkinsBuildResult && jenkinsBuildResult.data) {
                let jenkinsBuildResultData = null;
                try {
                  jenkinsBuildResultData = JSON.parse(jenkinsBuildResult.data);
                } catch {}
                if (jenkinsBuildResultData !== null) {
                  console.log('查询结果：', jenkinsBuildResultData.result);
                  if (jenkinsBuildResultData.result === null && times > 0) {
                    setTimeout(() => {
                      times -= 1;
                      checkResult({ times });
                    }, 10000);
                  } else if (jenkinsBuildResultData.result === 'SUCCESS') {
                    success && success();
                    complete && complete();
                  } else {
                    fail && fail();
                    complete && complete();
                  }
                } else {
                  fail && fail();
                  complete && complete();
                }
              } else {
                fail && fail();
                complete && complete();
              }
            }
            checkResult({
              times: 30
            })
          }
        }
      };
      const noticeDingTalk = async ({ typeName, name, markdownText }) => {
        await ctx.curl(`https://oapi.dingtalk.com/robot/send?access_token=${app.config.dingTalkAccessToken}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          dataType: 'text',
          data: {
            'msgtype': 'markdown',
            'markdown': {
              'title': `【${typeName}】【${name}】发布新版本`,
              'text': markdownText
            },
            'at': {
              'isAtAll': true
            }
          }
        });
      };
      const microApp = await this.show(id);
      if (microApp) {
        let res = {};
        const { repository } = microApp;
        const result = await ctx.helper.releaseVersionForMicroApp({ repository, version });
        if (result) {
          res = await app.mysql.insert('release_record', recordModels);
          if (res.insertId !== undefined) {
            const detailModels = await app.mysql.query(`
              select rr.id, rr.version, rr.inuser, DATE_FORMAT(rr.intime,'%Y-%m-%d %H:%i:%s') as intime, u.realName as inuserName, m.appName as name, m.type, m.featureBranches from release_record rr 
              join user u 
              on (u.id = rr.inuser) 
              join micro_app m 
              on (m.id = rr.unit_id) 
              where rr.type = 1 
              and rr.id = ?
            `, res.insertId);
            const link = repository.replace('.git', '') + '/blob/master/CHANGELOG.md'
            if (Array.isArray(detailModels) && detailModels.length) {
              const { name, type, version, intime, inuserName, featureBranches } = detailModels[0];
              const typeMap = {
                0: '微应用',
                1: '组件库',
                2: '工具库'
              }
              const typeName = typeMap[type];
              let markdownText = '**发布类型：** ' + (typeName === undefined ? '-' : typeName) + '\n\n' +
                                 '**发布名称：** ' + name + '\n\n' +
                                 '**发布版本：** v' + version + '\n\n' +
                                 '**发布时间：** ' + intime + '\n\n' +
                                 '**发布人员：** ' + inuserName + '\n\n' +
                                 '**发布内容：** [查看详情](' + link + ')';
              if (type == 1) {
                const docURL = 'http://wiki.uama.cc:8082/remainui/guide/introduction.html';
                markdownText += '\n\n**文档地址：** [' + docURL + '](' + docURL + ')';
                jenkinsAction({
                  submitURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-ui/build?delay=0sec',
                  fetchDetailURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-ui/api/json?pretty=true',
                  fetchResultURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-ui/${id}/api/json?pretty=true',
                  success () {},
                  fail () {},
                  complete () {
                    noticeDingTalk({
                      typeName,
                      name,
                      markdownText
                    });
                  }
                });
              } else if (type == 2) {
                const docURL = `https://lmfe-docs.uama.cc/remain-js-sdk/docs/${version}/index.html`;
                markdownText += '\n\n**文档地址：** [' + docURL + '](' + docURL + ')';
                jenkinsAction({
                  submitURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-js-sdk/build?delay=0sec',
                  fetchDetailURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-js-sdk/api/json?pretty=true',
                  fetchResultURL: 'http://jenkins.uama.cc:8080/view/%E5%89%8D%E7%AB%AF%E6%96%87%E6%A1%A3%E7%94%9F%E6%88%90/job/remain-js-sdk/${id}/api/json?pretty=true',
                  success () {},
                  fail () {},
                  complete () {
                    noticeDingTalk({
                      typeName,
                      name,
                      markdownText
                    });
                  }
                });
              } else {
                noticeDingTalk({
                  typeName,
                  name,
                  markdownText
                });
                const releaseRecordRes = await this.releaseRecord({ id });
                let jenkinsInfoVersion = "['master'";
                if (featureBranches) {
                  featureBranches.split(',').forEach(featureBranch => {
                    jenkinsInfoVersion += `,'${featureBranch}'`
                  })
                }
                if (Array.isArray(releaseRecordRes) && releaseRecordRes.length > 0) {
                  const tempReleaseRecordRes = releaseRecordRes.splice(0, 3);
                  tempReleaseRecordRes.forEach(tempReleaseRecordResItem => {
                    jenkinsInfoVersion += `,'v${tempReleaseRecordResItem.version}'`;
                  });
                }
                jenkinsInfoVersion += ']';
                await app.mysql.query('update Jenkins_info set version = ? where unit_id = ?', [jenkinsInfoVersion, id]);
                await this.syncOms();
              }
            }
          }
        } else {
          throw '发布失败'
        }
        return res;
      } else {
        throw '找不到对应的微应用';
      }
    } catch (e) {
      throw e;
    }
  }

  // 查询发布记录
  async releaseRecord (models) {
    try {
      const { app } = this;
      const { id } = models;
      const sql = `
        select rr.id, rr.version, rr.inuser, rr.intime, 
        (select realName from user u where u.id = rr.inuser) as inuserName 
        from release_record rr 
        where type = 1 
        and unit_id = ? 
        order by intime desc
      `;
      const res = await app.mysql.query(sql, id);
      return res;
    } catch (e) {
      throw e;
    }
  }

  // 同步OMS
  async syncOms () {
    try {
      const { app, ctx } = this;
      const omsProjectEnvInfo = app.config.omsProjectEnvInfo;
      const omsProjectEnvIds = Object.keys(omsProjectEnvInfo);
      if (omsProjectEnvIds.length > 0) {
        const configRes = await app.mysql.query(`
          select c.fkey, c.fvalue 
          from config c 
          where fkey = "oms_username" 
          or fkey = "oms_password"
        `);
        const config = {};
        configRes.forEach(configResItem => {
          config[configResItem.fkey] = configResItem.fvalue;
        });
        const omsLoginResult = await ctx.curl('https://oms.uama.cc/api/user/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          dataType: 'text',
          data: {
            'username': config.oms_username,
            'password': config.oms_password
          }
        });
        if (omsLoginResult.status === 200) {
          const omsLoginResultData = JSON.parse(omsLoginResult.data);
          if (omsLoginResultData && omsLoginResultData.data && omsLoginResultData.data.token) {
            const token = omsLoginResultData.data.token;
            for (let i = 0; i < omsProjectEnvIds.length; i++) {
              const projectEnvId = omsProjectEnvIds[i];
              const omsSyncResult = await ctx.curl(`https://oms.uama.cc/api/project/${projectEnvId}/rsync-project/`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': `Bearer ${token}`
                }
              });
              if (omsSyncResult.status === 200) {
                console.log('oms success: ', omsProjectEnvInfo[projectEnvId].name);
              }
            }
          }
        }
        console.log('oms complete');
      }
      return true
    } catch (e) {
      throw e;
    }
  }

  // 查询项目环境列表
  async queryProjectEnvList () {
    try {
      const { app } = this;
      const fkey = 'microApp_project_env'
      const configRes = await app.mysql.query(`
        select c.fkey, c.fvalue 
        from config c 
        where fkey = "${fkey}"
      `);
      const config = {};
      configRes.forEach(configResItem => {
        config[configResItem.fkey] = configResItem.fvalue;
      });
      const fvalue = config[fkey];
      let result = [];
      if (fvalue !== undefined) {
        result = fvalue.split(',')
      }
      return result;
    } catch (e) {
      throw e;
    }
  }

  // 查询配置版本列表
  async queryConfigVersionList ({ branch }) {
    try {
      const { app, ctx } = this;
      const fkey = 'config_services_repository'
      const configRes = await app.mysql.query(`
        select c.fkey, c.fvalue 
        from config c 
        where fkey = "${fkey}"
      `);
      const config = {};
      configRes.forEach(configResItem => {
        config[configResItem.fkey] = configResItem.fvalue;
      });
      const repository = config[fkey];
      const result = await ctx.helper.queryMicroAppConfig({ repository, branch });
      return result;
    } catch (e) {
      throw e;
    }
  }

  // 编辑配置版本
  async updateConfigVersion ({ dir, projectEnv, list, userEmail, inuser }) {
    try {
      const { ctx, app } = this;
      let num = 0;
      for (let i = 0; i < list.length; i++) {
        const item = list[i]
        const jenkinsInfoRes = await app.mysql.query('select * from jenkins_info where name = ?', item.microAppId);
        if (Array.isArray(jenkinsInfoRes) && jenkinsInfoRes.length === 0) {
          const microAppRes = await app.mysql.query('select * from micro_app where code = ?', item.microAppId);
          if (Array.isArray(microAppRes) && microAppRes.length > 0) {
            const microAppData = microAppRes[0]
            const releaseRecordRes = await this.releaseRecord({ id: microAppData.id });
            let jenkinsInfoVersion = "['master'";
            if (microAppData.featureBranches) {
              microAppData.featureBranches.split(',').forEach(featureBranch => {
                jenkinsInfoVersion += `,'${featureBranch}'`
              })
            }
            if (Array.isArray(releaseRecordRes) && releaseRecordRes.length > 0) {
              const tempReleaseRecordRes = releaseRecordRes.splice(0, 3);
              tempReleaseRecordRes.forEach(tempReleaseRecordResItem => {
                jenkinsInfoVersion += `,'v${tempReleaseRecordResItem.version}'`;
              });
            }
            jenkinsInfoVersion += ']';
            await app.mysql.insert('jenkins_info', {
              unit_id: microAppData.id,
              name: microAppData.code,
              version: jenkinsInfoVersion,
              inuser
            });
            num++;
          }
        }
      }
      if (num > 0) {
        await this.syncOms();
      }
      const result = await ctx.helper.updateMicroAppConfig({ dir, projectEnv, list, userEmail });
      return result;
    } catch (e) {
      throw e;
    }
  }
}

module.exports = MicroAppService;
