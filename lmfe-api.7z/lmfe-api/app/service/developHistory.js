/*
 * @Description: 发展历程的service
 * @Author: 小广
 * @Date: 2019-09-25 15:04:54
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-30 09:26:44
 */
'use strict';
const BaseService = require('./base');

class DevelopHistoryService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'develophistory';
  }

  // 获取列表数据
  async getDevelopHistoryList(model) {
    try {
      const { app } = this;
      const { id, title, status, startTime, endTime } = model;
      let sql = 'select * from develophistory where 1 = 1';
      if (id) {
        sql += ' and id = ? ';
        return this.customListPage(sql, [ id ]);
      }
      if (status) {
        sql += ' and status = ' + app.mysql.escape(status);
      }
      if (title) {
        sql += ' and title like ' + app.mysql.escape(`%${title}%`);
      }
      if (startTime) {
        sql += ' and developTime >= ' + app.mysql.escape(startTime);
      }
      if (endTime) {
        sql += ' and developTime <= ' + app.mysql.escape(endTime);
      }
      sql += ' order by status desc, developTime asc ';
      return this.customListPage(sql);
    } catch (e) {
      throw e;
    }
  }

  // web获取列表数据（官网使用）
  async getDevelopHistoryListForWeb(model) {
    try {
      const { app } = this;
      const { status } = model;
      let sql = 'select * from develophistory where 1 = 1';
      if (status) {
        sql += ' and status =  ' + app.mysql.escape(status);
      }
      sql += ' order by status desc, developTime asc ';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }

  // 新增
  async addDevelopHistory(model) {
    const res = await this.create(model);
    return res;
  }
  // 编辑
  async editDevelopHistory(model) {
    const res = await this.update(model);
    return res;
  }
}

module.exports = DevelopHistoryService;

