/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: 木犀
 * @LastEditTime: 2019-08-13 16:17:20
 */
'use strict';
const BaseService = require('./base');

class RoleUserService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'role_user';
  }
  async getRoleIdByUserId(userId) {
    try {
      const { app } = this;
      const sql = 'select role_id from role_user where user_id = ?';
      const result = await app.mysql.query(sql, [ userId ]);
      return Array.isArray(result) ? result[0].role_id : undefined;
    } catch (e) {
      throw e;
    }
  }

  // 根据userId修改角色
  async updateRoleIdByUserId(roleId, userId) {
    try {
      const { app } = this;
      const sql = 'update role_user set role_id = ? where user_id = ?';
      const { affectedRows } = await app.mysql.query(sql, [ roleId, userId ]);
      return affectedRows.length === 1;
    } catch (e) {
      throw e;
    }
  }
  async deleteUserByUserId(userId) {
    try {
      const { app } = this;
      const sql = 'delete from role_user where user_id = ?';
      const { affectedRows } = await app.mysql.query(sql, [ userId ]);
      return affectedRows.length === 1;
    } catch (e) {
      throw e;
    }
  }
}

module.exports = RoleUserService;
