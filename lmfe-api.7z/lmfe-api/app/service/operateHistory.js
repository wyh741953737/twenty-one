/*
 * @Description: 获取操作历史列表
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-06 01:01:45
 */
'use strict';
const BaseService = require('./base');

class OperateHistoryService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'house';
  }


  // web获取操作历史列表（官网使用）
  async getWebOperateHistoryList() {
    try {
      const sql = 'select * from operate_history';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
}

module.exports = OperateHistoryService;
