/*
 * @Description: 获取费用明细列表
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:16
 * @LastEditors: 木犀
 * @LastEditTime: 2019-11-13 01:48:40
 */
'use strict';
const BaseService = require('./base');

class DeviceOrderService extends BaseService {
  constructor(ctx) {
    super(ctx);
    this.entry = 'device_order';
  }


  // web获取设备告警列表（官网使用）
  async getDeviceOrderList(param) {
    try {
      const { app } = this;
      const buildName = param.buildName;
      const floorName = param.floorName;
      const deviceType = param.deviceType;
      const deviceNum = param.deviceNum;
      let deviceNumList;
      let deviceSql;
      if (deviceNum) {
        deviceNumList[0] = deviceNum;
      } else if (floorName) {
        deviceSql = 'select deviceNum from device where floorName = ' + app.mysql.escape(floorName);
        if (deviceType) {
          deviceSql = ` ${deviceSql} and deviceType in (${deviceType})`;
        }
      } else if (buildName) {
        deviceSql = 'select deviceNum from device where buildName = ' + app.mysql.escape(buildName);
        if (deviceType) {
          deviceSql = ` ${deviceSql} and deviceType in (${deviceType})`;
        }
      } else if (deviceType) {
        deviceSql = `select deviceNum from device where deviceType in (${deviceType})`;
      } else {
        return [];
      }
      deviceNumList = await app.mysql.query(deviceSql);
      if (!deviceNumList || !deviceNumList.length) {
        return [];
      }
      deviceNumList = deviceNumList.map(device => {
        return `'${device.deviceNum}'`;
      });
      const deviceNumListStr = deviceNumList.join(',');
      const sql = 'select * from device_order where deviceNum in (' + deviceNumListStr + ')';
      const res = this.customList(sql);
      return res;
    } catch (error) {
      throw error;
    }
  }
}

module.exports = DeviceOrderService;
