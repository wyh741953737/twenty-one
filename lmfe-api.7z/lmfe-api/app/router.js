/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: FCC
 * @LastEditTime: 2020-10-08 16:17:38
 */
'use strict';

module.exports = app => {
  const { router, controller, io } = app;
  const baseUrl = app.config.baseUrl;
  // 蜘蛛爬虫接口 begin
  router.get('/lmseo', controller.snapshot.main);
  router.get('/lmseo/:path', controller.snapshot.main);
  // 蜘蛛爬虫接口 end
  // 获取快照接口
  router.post(`${baseUrl}/snapshot`, controller.snapshot.createSnapshotByUrl);
  // 上传接口
  router.post(`${baseUrl}/upload`, controller.upload.upload);
  // 富文本上传接口(POST)
  router.post(`${baseUrl}/uploadUEditor`, controller.upload.uploadUEditor);
  // 富文本上传接口(GET)
  router.get(`${baseUrl}/uploadUEditor`, app.jsonp(), controller.upload.uploadUEditor);

  // 获取企业介绍(官网使用)
  router.get('baseInfo', `${baseUrl}/web/companyIntroduce`, controller.baseInfo.getCompanyIntroduceForWeb);
  // 获取公司基础信息详情(官网使用)
  router.get('baseInfo', `${baseUrl}/web/baseInfo`, controller.baseInfo.getBaseInfoForWeb);
  // 获取公司基础信息详情
  router.get('baseInfo', `${baseUrl}/baseInfo`, controller.baseInfo.getBaseInfo);
  // 编辑公司基础信息
  router.put('baseInfo', `${baseUrl}/baseInfo/:id`, controller.baseInfo.editBaseInfo);

  // 获取用户列表接口
  router.get('user', `${baseUrl}/user`, controller.user.getUserList);
  // 根据ID用户的接口
  router.get('user', `${baseUrl}/user/:id`, controller.user.findOne);
  // 新增用户的接口
  router.post(`${baseUrl}/user/add`, controller.user.create);
  // 更新用户的接口
  router.put(`${baseUrl}/user/:id`, controller.user.update);
  // 删除用户的接口
  router.delete(`${baseUrl}/user/:id`, controller.user.deleteUser);
  // 修改用户密码接口
  router.put(`${baseUrl}/user/:id/updatePassword`, controller.user.updatePassword);

  // 重置用户密码接口
  router.put(`${baseUrl}/user/:id/resetPassword`, controller.user.resetPassword);

  // 用户登录(如果需要配置用户注册,请重新写方法,本项目是后台cms系统,只允许创建用户,上面接口里面有)
  router.post(`${baseUrl}/user/login`, controller.user.login);

  // 获取当前登录用户的个人信息
  router.get(`${baseUrl}/getPersonalInfo`, controller.user.getCurrentUserInfo);

  // 配置登录的验证码
  router.get(`${baseUrl}/captcha`, controller.user.captcha);

  // 获取角色列表的接口
  router.get(`${baseUrl}/role`, controller.role.getRoleList);

  // 获取焦点图列表的接口(官网)
  router.get(`${baseUrl}/web/focus`, controller.focus.getFocusListForWeb);
  // 获取焦点图列表的接口
  router.get(`${baseUrl}/focus`, controller.focus.getFocusList);
  // 新增焦点图接口
  router.post(`${baseUrl}/focus`, controller.focus.addFocus);
  // 获取焦点图详情
  router.get(`${baseUrl}/focus/:id`, controller.focus.getFocusById);
  // 编辑焦点图
  router.put(`${baseUrl}/focus/:id`, controller.focus.editFocus);

  // 获取工单列表的接口
  router.get(`${baseUrl}/order`, controller.order.getOrderList);
  // 新增工单接口
  router.post(`${baseUrl}/order`, controller.order.addOrder);
  // 获取工单详情
  router.get(`${baseUrl}/order/:id`, controller.order.getOrderById);
  // 编辑工单
  router.put(`${baseUrl}/order/:id`, controller.order.editOrder);
  // 复制工单
  router.post(`${baseUrl}/order/:id/copy`, controller.order.copyOrder);
  // 审核工单
  router.put(`${baseUrl}/order/:id/changeStatus`, controller.order.updateOrderStatus);

  // 查询项目环境列表
  router.get(`${baseUrl}/microApp/queryProjectEnvList`, controller.microApp.queryProjectEnvList);
  // 查询配置版本列表
  router.get(`${baseUrl}/microApp/queryConfigVersionList`, controller.microApp.queryConfigVersionList);
  // 编辑配置版本
  router.post(`${baseUrl}/microApp/updateConfigVersion`, controller.microApp.updateConfigVersion);

  // 获取微应用列表的接口[免登]
  router.get(`${baseUrl}/web/microApp`, controller.microApp.getMicroAppListForWeb);
  // 获取微应用列表的接口
  router.get(`${baseUrl}/microApp`, controller.microApp.getMicroAppList);
  // 模糊搜索微应用的接口
  router.get(`${baseUrl}/microAppSelect2`, controller.microApp.getMicroAppSelect2);
  // 获取微应用分支列表的接口
  router.get(`${baseUrl}/microApp/:id/branchList`, controller.microApp.getBranchListById);
  // 新增微应用接口
  router.post(`${baseUrl}/microApp`, controller.microApp.addMicroApp);
  // 获取微应用详情
  router.get(`${baseUrl}/microApp/:id`, controller.microApp.getMicroAppById);
  // 编辑微应用
  router.put(`${baseUrl}/microApp/:id`, controller.microApp.editMicroApp);
  // 发布微应用
  router.post(`${baseUrl}/microApp/releaseVersion/:id`, controller.microApp.releaseVersion);
  // 查询发布记录
  router.get(`${baseUrl}/microApp/releaseRecord/:id`, controller.microApp.releaseRecord);
  // 同步OMS
  router.post(`${baseUrl}/microApp/syncOms`, controller.microApp.syncOms);

  // 查询项目列表
  router.get(`${baseUrl}/project/list`, controller.project.list);
  // 查询项目详情
  router.get(`${baseUrl}/project/detail/:id`, controller.project.detail);
  // 新增项目
  router.post(`${baseUrl}/project/add`, controller.project.add);
  // 编辑项目
  router.put(`${baseUrl}/project/edit`, controller.project.edit);
  // 构建项目
  router.post(`${baseUrl}/project/build`, controller.project.build);
  // 发布项目
  router.post(`${baseUrl}/project/releaseVersion`, controller.project.releaseVersion);
  // 查询项目发布记录
  router.get(`${baseUrl}/project/releaseRecord`, controller.project.releaseRecord);

  // 查询网络图列表
  router.get(`${baseUrl}/networkDiagram/list`, controller.networkDiagram.list);
  // 查询网络图详情
  router.get(`${baseUrl}/networkDiagram/detail/:id`, controller.networkDiagram.detail);
  // 查询网络图详情【免登】
  router.get(`${baseUrl}/web/networkDiagram/detail/:id`, controller.networkDiagram.detailForWeb);
  // 新增网络图
  router.post(`${baseUrl}/networkDiagram/add`, controller.networkDiagram.add);
  // 编辑网络图 - 基础
  router.put(`${baseUrl}/networkDiagram/edit`, controller.networkDiagram.edit);
  // 编辑网络图 - 设计
  router.put(`${baseUrl}/networkDiagram/saveDesign`, controller.networkDiagram.saveDesign);

  // 查询页面设计列表
  router.get(`${baseUrl}/pageDesign/list`, controller.pageDesign.list);
  // 查询页面设计详情
  router.get(`${baseUrl}/pageDesign/detail/:id`, controller.pageDesign.detail);
  // 新增页面设计
  router.post(`${baseUrl}/pageDesign/add`, controller.pageDesign.add);
  // 编辑页面设计 - 基础
  router.put(`${baseUrl}/pageDesign/edit`, controller.pageDesign.edit);
  // 编辑页面设计 - 设计
  router.put(`${baseUrl}/pageDesign/saveDesign`, controller.pageDesign.saveDesign);

  // 获取联系我们列表的接口
  router.get(`${baseUrl}/contactUs`, controller.contactUs.getContactUsList);
  // 新增联系我们接口
  router.post(`${baseUrl}/web/contactUs`, controller.contactUs.addContactUsForWeb);
  // 获取联系我们详情
  router.get(`${baseUrl}/contactUs/:id`, controller.contactUs.getContactUsById);
  // 编辑联系我们
  router.put(`${baseUrl}/contactUs/:id`, controller.contactUs.editContactUs);


  // 获取字体图标
  router.get(`${baseUrl}/icon`, controller.icon.getIconList);

  // 获取合作站点列表的接口（官网）
  router.get(`${baseUrl}/web/cooperationSite`, controller.cooperationSite.getCooperationSiteForWeb);
  // 获取合作站点列表的接口
  router.get(`${baseUrl}/cooperationSite`, controller.cooperationSite.getCooperationSiteList);
  // 新增合作站点接口
  router.post(`${baseUrl}/cooperationSite`, controller.cooperationSite.addCooperationSite);
  // 编辑企业
  router.put(`${baseUrl}/cooperationSite/:id`, controller.cooperationSite.editCooperationSite);
  // 编辑企业
  router.get(`${baseUrl}/cooperationSite/:id`, controller.cooperationSite.getCooperationSiteById);

  // 获取招聘信息列表的接口（官网）
  router.get(`${baseUrl}/web/inviteJob`, controller.inviteJob.getInviteJobListForWeb);
  // 获取招聘信息列表的接口
  router.get(`${baseUrl}/inviteJob`, controller.inviteJob.getInviteJobList);
  // 新增招聘信息接口
  router.post(`${baseUrl}/inviteJob`, controller.inviteJob.addInviteJob);
  // 编辑招聘信息
  router.put(`${baseUrl}/inviteJob/:id`, controller.inviteJob.editInviteJob);
  // 获取招聘信息详情
  router.get(`${baseUrl}/inviteJob/:id`, controller.inviteJob.getInviteJobById);


  // // 获取发展历程列表的接口（官网）
  // router.get(`${baseUrl}/web/developHistory`, controller.developHistory.getDevelopHistoryListForWeb);
  // 获取发展历程列表的接口
  router.get(`${baseUrl}/developHistory`, controller.developHistory.getDevelopHistoryList);
  // 新增发展历程接口
  router.post(`${baseUrl}/developHistory`, controller.developHistory.addDevelopHistory);
  // 编辑发展历程
  router.put(`${baseUrl}/developHistory/:id`, controller.developHistory.editDevelopHistory);
  // 获取发展历程详情
  router.get(`${baseUrl}/developHistory/:id`, controller.developHistory.getDevelopHistoryById);


  // // 获取荣誉资质列表的接口（官网）
  // router.get(`${baseUrl}/web/certificate`, controller.certificate.getCertificateListForWeb);
  // 获取荣誉资质列表的接口
  router.get(`${baseUrl}/certificate`, controller.certificate.getCertificateList);
  // 新增荣誉资质接口
  router.post(`${baseUrl}/certificate`, controller.certificate.addCertificate);
  // 编辑荣誉资质
  router.put(`${baseUrl}/certificate/:id`, controller.certificate.editCertificate);
  // 获取荣誉资质详情
  router.get(`${baseUrl}/certificate/:id`, controller.certificate.getCertificateById);

  // 获取服务案例列表的接口（官网） ServiceCase
  router.get(`${baseUrl}/web/serviceCase`, controller.serviceCase.getServiceCaseListForWeb);
  // 获取服务案例详情（官网）
  router.get(`${baseUrl}/web/serviceCase/:id`, controller.serviceCase.getServiceCaseByIdForWeb);
  // 获取服务案例列表的接口
  router.get(`${baseUrl}/serviceCase`, controller.serviceCase.getServiceCaseList);
  // 新增服务案例接口
  router.post(`${baseUrl}/serviceCase`, controller.serviceCase.addServiceCase);
  // 编辑服务案例
  router.put(`${baseUrl}/serviceCase/:id`, controller.serviceCase.editServiceCase);
  // 获取服务案例详情
  router.get(`${baseUrl}/serviceCase/:id`, controller.serviceCase.getServiceCaseById);

  // 获取解决方案列表的接口（官网） solution
  router.get(`${baseUrl}/web/solution`, controller.solution.getSolutionListForWeb);
  // 获取解决方案列表的接口
  router.get(`${baseUrl}/solution`, controller.solution.getSolutionList);
  // 新增解决方案接口
  router.post(`${baseUrl}/solution`, controller.solution.addSolution);
  // 编辑解决方案
  router.put(`${baseUrl}/solution/:id`, controller.solution.editSolution);
  // 获取解决方案详情
  router.get(`${baseUrl}/solution/:id`, controller.solution.getSolutionById);

  // 获取融平台体系列表的接口（官网）
  router.get(`${baseUrl}/web/rongPlatform`, controller.rongPlatform.getRongPlatformListForWeb);
  // 获取融平台体系列表的接口
  router.get(`${baseUrl}/rongPlatform`, controller.rongPlatform.getRongPlatformList);
  // 新增融平台体系接口
  router.post(`${baseUrl}/rongPlatform`, controller.rongPlatform.addRongPlatform);
  // 编辑融平台体系
  router.put(`${baseUrl}/rongPlatform/:id`, controller.rongPlatform.editRongPlatform);
  // 获取融平台体系详情
  router.get(`${baseUrl}/rongPlatform/:id`, controller.rongPlatform.getRongPlatformById);

  // 获取房号列表的接口(官网)
  router.get(`${baseUrl}/web/house`, controller.house.getHouseListForWeb);
  router.get(`${baseUrl}/web/house/:houseId`, controller.house.getHouseByIdForWeb);
  router.get(`${baseUrl}/web/houseList/search`, controller.house.getWebHouseListBySearch);

  // 获取费用明细列表的接口(官网)
  router.get(`${baseUrl}/web/feeDetail`, controller.feeDetail.getFeeDetailListForWeb);

  // 获取操作历史列表的接口(官网)
  router.get(`${baseUrl}/web/operateHistory`, controller.operateHistory.getOperateHistoryListForWeb);

  // 获取设备列表的接口(官网)
  router.get(`${baseUrl}/web/device/list`, controller.device.getDeviceListForWeb);

  // 获取设备详情的接口(官网)
  router.get(`${baseUrl}/web/device`, controller.device.getDeviceByDeviceNum);

  // 获取设备告警列表的接口(官网)
  router.get(`${baseUrl}/web/deviceAlarm`, controller.deviceAlarm.getDeviceAlarmListForWeb);
  // 获取告警详情
  router.get(`${baseUrl}/web/deviceAlarm/:id`, controller.deviceAlarm.getAlarmByAlarmId);

  // 获取设备工单列表的接口(官网)
  router.get(`${baseUrl}/web/deviceOrder`, controller.deviceOrder.getDeviceOrderListForWeb);
  // 获取工单详情
  router.get(`${baseUrl}/web/deviceOrder/:id`, controller.deviceOrder.getOrderByOrderId);

  // 获取企业列表的接口(官网)
  router.get(`${baseUrl}/web/enterprise`, controller.enterprise.getEnterPriseListForWeb);
  router.get(`${baseUrl}/web/enterprise/:id`, controller.enterprise.getEnterPriseForWeb);
  router.get(`${baseUrl}/web/getEnterpriseCount`, controller.enterprise.getCountByType);

  // 获取企业诉求列表的接口(官网)
  router.get(`${baseUrl}/web/enterpriseDemand`, controller.enterpriseDemand.getEnterpriseDemandForWeb);
  // 获取企业诉求详情的接口(官网)
  router.get(`${baseUrl}/web/enterpriseDemand/:id`, controller.enterpriseDemand.getEnterpriseDemandById);
  // 获取诉求概览数据的接口(官网)
  router.get(`${baseUrl}/web/enterpriseDemandOverview`, controller.enterpriseDemand.getEnterpriseDemandOverview);
  // 获取小微园详情（官网）
  router.get(`${baseUrl}/web/parkViewData/:id`, controller.parkViewData.getParkViewDataByIdForWeb);
  // 更新小微园详情（官网）
  router.put(`${baseUrl}/web/parkViewData/:id`, controller.parkViewData.editParkViewDataForWeb);

  // 分支管理
  router.get(`${baseUrl}/branch/getBranchList`, controller.branchInfo.list);
  router.get(`${baseUrl}/branch/checkBranchForProject/:id`, controller.branchInfo.checkBranchForProject);
  router.get(`${baseUrl}/branch/checkTagForProject/:id`, controller.branchInfo.checkTagForProject);
  router.post(`${baseUrl}/branch/add`, controller.branchInfo.addBranch);
  router.post(`${baseUrl}/branch/update`, controller.branchInfo.updateBranch);
  router.get(`${baseUrl}/branch/detail/:id`, controller.branchInfo.detail);
  router.post(`${baseUrl}/branch/delete/:id`, controller.branchInfo.deleteBranch);
  router.get(`${baseUrl}/branch/projectSelect2`, controller.branchInfo.projectSelect2);

  io.of('/apiExplorer').route('invoke', io.controller.apiExplorer.invoke);
};
