/*
 * @Description: 服务案例
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-12-03 09:51:52
 */
'use strict';
const BaseController = require('./base');
/**
* @controller ServiceCase 服务案例
*/

class ServiceCaseController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'serviceCase';
  }

  /**
    * @summary 获取服务案例接口(官网使用)
    * @description 获取服务案例
    * @router get /web/serviceCase
    * @request query number type 类型（1智慧园区，2智慧社区，3智慧楼宇，4智慧校园）
    * @response 200 serviceCase ok
  */
  async getServiceCaseListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        status: 1,
        type: query.type,
      };
      const rule = {
        type: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.serviceCase.getServiceCaseListForWeb(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
* @summary 根据id，获取服务案例详情接口(官网使用)
* @description 根据id，获取服务案例详情
* @router get /web/serviceCase/{id}
* @request path string *id id
* @response 200 serviceCase ok
*/
  async getServiceCaseByIdForWeb() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.serviceCase.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }

  /**
      * @summary 获取服务案例列表接口
      * @description 获取服务案例列表
      * @router get /serviceCase
      * @request header string *token token令牌
      * @request query string id id
      * @request query string name 名字
      * @request query number type 类型（1智慧园区，2智慧社区，3智慧楼宇，4智慧校园）
      * @request query number jumpType 跳转类型（1不跳转，2外链，3详情）
      * @request query number status 状态（1正常，0关闭）
      * @request query string startTime 创建时间段-开始时间
      * @request query string endTime 创建时间段-结束时间
      * @response 200 serviceCase ok
    */
  async getServiceCaseList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        name: query.name,
        type: query.type,
        jumpType: query.jumpType,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        name: { type: 'string', trim: true, required: false },
        type: { type: 'string', required: false },
        jumpType: { type: 'string', required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.serviceCase.getServiceCaseList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增服务案例接口
    * @description 新增服务案例
    * @router post /serviceCase
    * @request header string *token token令牌
    * @request body addServiceCaseRequest serviceCase 服务案例实例
    * @response 200 serviceCase ok
*/
  async addServiceCase() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        name: { type: 'string', trim: true, required: true },
        status: { type: 'number', required: false },
        type: { type: 'number', required: true },
        enName: { type: 'string', required: false },
        sort: { type: 'number', required: false },
        content: { type: 'string', required: false },
        cover: { type: 'string', trim: true, required: true },
        jumpType: { type: 'number', required: true },
        outsideUrl: { type: 'string', trim: true, required: false },
        summary: { type: 'string', required: true },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.serviceCase.addServiceCase(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑服务案例接口
     * @description 修改服务案例
     * @router put /serviceCase/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editServiceCaseRequest serviceCase 服务案例实例
     * @response 200 serviceCase ok
    */
  async editServiceCase() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        name: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        type: { type: 'number', required: false },
        enName: { type: 'string', required: false },
        sort: { type: 'number', required: false },
        content: { type: 'string', required: false },
        cover: { type: 'string', trim: true, required: false },
        jumpType: { type: 'number', required: false },
        outsideUrl: { type: 'string', trim: true, required: false },
        summary: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.serviceCase.editServiceCase(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取服务案例详情接口
    * @description 根据id，获取服务案例详情
    * @router get /serviceCase/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 serviceCase ok
  */
  async getServiceCaseById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.serviceCase.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = ServiceCaseController;
