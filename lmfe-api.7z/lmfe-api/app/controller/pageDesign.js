'use strict';
const BaseController = require('./base');

/**
* @controller pageDesign 页面设计
*/
class PageDesignController extends BaseController {
  constructor(ctx) {
    super(ctx);
  }

  /**
    * @summary 查询页面设计列表
    * @description 查询页面设计列表
    * @router get /pageDesign/list
    * @request header string *token token
    * @request query string name 名称
    * @request query string inuser 创建人
    * @request query string intimeBegin 创建时间-开始时间
    * @request query string intimeEnd 创建时间-结束时间
    * @request query string updateUser 最后更新人
    * @request query string updateTimeBegin 最后更新时间-开始时间
    * @request query string updateTimeEnd 最后更新时间-结束时间
    * @response 200 list ok
  */
  async list () {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const models = {
        name: query.name,
        inuser: query.inuser,
        intimeBegin: query.intimeBegin,
        intimeEnd: query.intimeEnd,
        updateUser: query.updateUser,
        updateTimeBegin: query.updateTimeBegin,
        updateTimeEnd: query.updateTimeEnd
      };
      const result = await service.pageDesign.list(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询页面设计详情
    * @description 查询页面设计详情
    * @router get /pageDesign/detail/{id}
    * @request header string *token token
    * @request path string *id 页面设计id
    * @response 200 item ok
  */
  async detail () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.pageDesign.show(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增页面设计
    * @description 新增页面设计
    * @router post /pageDesign/add
    * @request header string *token token
    * @response 200 id ok
  */
  async add () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        name: { type: 'string', trim: true, required: true }
      };
      const models = {
        remark: body.remark,
        inuser: user.id,
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.pageDesign.add(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑页面设计 - 基础
    * @description 编辑页面设计 - 基础
    * @router put /pageDesign/edit
    * @request header string *token token
    * @response 200 id ok
  */
  async edit () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        name: { type: 'string', trim: true, required: true }
      };
      const models = {
        remark: body.remark,
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.pageDesign.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  
  /**
    * @summary 编辑页面设计- 设计
    * @description 编辑页面设计 - 设计
    * @router put /pageDesign/saveDesign
    * @request header string *token token
    * @response 200 id ok
  */
  async saveDesign () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        data: { type: 'string', required: true }
      };
      const models = {
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.pageDesign.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = PageDesignController;
