/*
 * @Description: 微应用管理
 * @Author: 木犀
 * @Date: 2020-08-10 10:44:15
 * @LastEditors: 木犀
 * @LastEditTime: 2020-08-10 10:44:15
 */
'use strict';
const BaseController = require('./base');

/**
* @controller MicroApp 微应用
*/
class MicroAppController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'microApp';
  }

  /**
    * @summary 获取微应用列表接口【免登】
    * @description 获取微应用列表【免登】
    * @router get /web/microApp
    * @request query string id 微应用id
    * @request query string appName 微应用名称
    * @request query string endType 微应用端类型（1：业主端；2：物管端：3：商家端：4：管理后台）
    * @request query string unitType 微应用所属单元（1：楼宇单元；2：社区单元；3：物联网单元）
    * @request query number status 微应用开发进度（1：未开始；2：开发中；3：待提测；4：测试中；5：待上线；6：已上线）
    * @request query string ownerA 微应用负责人A
    * @request query string ownerB 微应用负责人B
    * @request query string intimeBegin 创建时间-开始时间
    * @request query string intimeEnd 创建时间-结束时间
    * @request query string lastEditTimeBegin 最后一次更新时间-开始时间
    * @request query string lastEditTimeEnd 最后一次更新时间-结束时间
    * @response 200 microApp ok
  */
 async getMicroAppListForWeb() {
  const { ctx, service } = this;
  try {
    const query = ctx.query;
    const param = {
      id: query.id,
      appName: query.appName ? query.appName.trim() : undefined,
      endType: query.endType,
      unitType: query.unitType,
      status: query.status,
      ownerA: query.ownerA,
      ownerB: query.ownerB,
      intimeBegin: query.intimeBegin,
      intimeEnd: query.intimeEnd,
      lastEditTimeBegin: query.intimeBegin,
      lastEditTimeEnd: query.intimeEnd,
    };
    const result = await service.microApp.getMicroAppList(param);
    this.success(result);
  } catch (e) {
    ctx.logger.error(e);
    this.error(e);
  }
}

  /**
    * @summary 获取微应用列表接口
    * @description 获取微应用列表
    * @router get /microApp
    * @request header string *token token令牌
    * @request query string id 微应用id
    * @request query string appName 微应用名称
    * @request query string code 微应用code
    * @request query string endType 微应用端类型（1：业主端；2：物管端：3：商家端：4：管理后台）
    * @request query string unitType 微应用所属单元（1：楼宇单元；2：社区单元；3：物联网单元）
    * @request query number status 微应用开发进度（1：未开始；2：开发中；3：待提测；4：测试中；5：待上线；6：已上线）
    * @request query string ownerA 微应用负责人A
    * @request query string ownerB 微应用负责人B
    * @request query string intimeBegin 创建时间-开始时间
    * @request query string intimeEnd 创建时间-结束时间
    * @request query string lastEditTimeBegin 最后一次更新时间-开始时间
    * @request query string lastEditTimeEnd 最后一次更新时间-结束时间
    * @response 200 microApp ok
  */
  async getMicroAppList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        appName: query.appName ? query.appName.trim() : undefined,
        code: query.code ? query.code.trim() : undefined,
        endType: query.endType,
        unitType: query.unitType,
        status: query.status,
        ownerA: query.ownerA,
        ownerB: query.ownerB,
        intimeBegin: query.intimeBegin,
        intimeEnd: query.intimeEnd,
        lastEditTimeBegin: query.intimeBegin,
        lastEditTimeEnd: query.intimeEnd,
      };
      const result = await service.microApp.getMicroAppList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 模糊搜索微应用
    * @description 模糊搜索微应用
    * @router get /microAppSelect2
    * @request header string *token token令牌
    * @request query string id 微应用id
    * @request query string code 微应用code
    * @request query string appName 微应用名称[模糊搜索]
    * @response 200 microApp ok
  */
   async getMicroAppSelect2() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        code: query.code ? query.code.trim() : undefined,
        appName: query.appName ? query.appName.trim() : undefined
      };
      const result = await service.microApp.getMicroAppSelect2(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据微应用id，获取微应用分支列表接口
    * @description 根据微应用id，获取微应用分支列表
    * @router get /microApp/{id}/branchList
    * @request header string *token token令牌
    * @request path string *id 微应用id
    * @response 200 microApp ok
  */
  async getBranchListById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.microApp.getBranchListById({ id });
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }

  /**
    * @summary 新增微应用接口
    * @description 新增微应用
    * @router post /microApp
    * @request header string *token token令牌
    * @request body addMicroAppRequest microApp 微应用实例
    * @response 200 microApp ok
  */
  async addMicroApp() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const user = ctx.session.user;
      const rule = {
        appName: { type: 'string', trim: true, required: true },
        description: { type: 'string', trim: true, required: false },
        endType: { type: 'number', required: true },
        unitType: { type: 'number', required: true },
        status: { type: 'number', required: true },
        ownerA: { type: 'number', required: true },
        ownerB: { type: 'number', required: true },
        repository: { type: 'string', required: true },
        remark: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      model.lastEditTime = new Date();
      model.inuser = user.id
      const result = await service.microApp.addMicroApp(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 根据微应用id，获取微应用详情接口
    * @description 根据微应用id，获取微应用详情
    * @router get /microApp/{id}
    * @request header string *token token令牌
    * @request path string *id 微应用id
    * @response 200 microApp ok
  */
  async getMicroAppById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.microApp.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
  /**
    * @summary 编辑微应用接口
    * @description 修改微应用
    * @router put /microApp/{id}
    * @request header string *token token令牌
    * @request path string *id 应用id
    * @request body editMicroAppRequest microApp 微应用实例
    * @response 200 microApp ok
  */
  async editMicroApp() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        appName: { type: 'string', trim: true, required: false },
        description: { type: 'string', trim: true, required: false },
        endType: { type: 'number', required: false },
        unitType: { type: 'number', required: false },
        status: { type: 'number', required: false },
        ownerA: { type: 'number', required: false },
        ownerB: { type: 'number', required: false },
        repository: { type: 'string', required: false },
        remark: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.lastEditTime = new Date();
      const result = await service.microApp.editMicroApp(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 发布微应用
    * @description 发布微应用
    * @router post /microApp/releaseVersion/{id}
    * @request path string *id 微应用id
    * @request query string version 版本号
    * @request header string *token token
    * @response 200 microApp ok
  */
  async releaseVersion () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const { version } = ctx.request.body;
      const user = ctx.session.user;
      const rules = {
        id: { type: 'string', required: true },
        version: { type: 'string', required: true }
      };
      const models = {
        id,
        version
      };
      ctx.validate(rules, models);
      const recordModels = {
        type: 1,
        unit_id: id,
        inuser: user.id,
        version
      }
      const result = await service.microApp.releaseVersion(models, recordModels);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询发布记录
    * @description 查询发布记录
    * @router post /microApp/releaseRecord/{id}
    * @request path string *id 微应用id
    * @request header string *token token
    * @response 200 microApp ok
  */
  async releaseRecord () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.microApp.releaseRecord({ id });
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 同步OMS
    * @description 同步OMS
    * @router post /microApp/syncOms
    * @request header string *token token
    * @response 200 microApp ok
  */
  async syncOms () {
    const { ctx, service } = this;
    try {
      const result = await service.microApp.syncOms();
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询项目环境列表
    * @description 查询项目环境列表
    * @router get /microApp/queryProjectEnvList
    * @request header string *token token
  */
  async queryProjectEnvList () {
    const { ctx, service } = this;
    try {
      const result = await service.microApp.queryProjectEnvList();
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询配置版本列表
    * @description 查询配置版本列表
    * @router get /microApp/queryConfigVersionList
    * @request query string branch 分支
    * @request header string *token token
  */
  async queryConfigVersionList () {
    const { ctx, service } = this;
    try {
      const { branch } = ctx.query;
      const rules = {
        branch: { type: 'string', required: true }
      };
      ctx.validate(rules, { branch });
      const result = await service.microApp.queryConfigVersionList({ branch });
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑配置版本
    * @description 编辑配置版本
    * @router post /microApp/updateConfigVersion
    * @request body string dir 目录
    * @request body string projectEnv 项目环境
    * @request header string *token token
  */
  async updateConfigVersion () {
    const { ctx, service } = this;
    try {
      const { dir, projectEnv, list } = ctx.request.body;
      const user = ctx.session.user;
      const userEmail = user.email;
      const inuser = user.id;
      const rules = {
        dir: { type: 'string', required: true },
        projectEnv: { type: 'string', required: true },
        list: { type: 'array', required: true }
      };
      ctx.validate(rules, { dir, projectEnv, list });
      const result = await service.microApp.updateConfigVersion({ dir, projectEnv, list, userEmail, inuser });
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = MicroAppController;
