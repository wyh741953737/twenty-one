/*
 * @Description: 发展历程
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-30 09:22:17
 */
'use strict';
const BaseController = require('./base');
/**
* @controller DevelopHistory 发展历程
*/

class DevelopHistoryController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'developHistory';
  }


  /**
      * @summary 获取发展历程列表接口
      * @description 获取发展历程列表
      * @router get /developHistory
      * @request header string *token token令牌
      * @request query string id id
      * @request query string title 标题
      * @request query number status 状态（1正常，0关闭）
      * @request query string startTime 发展时间段-开始时间
      * @request query string endTime 发展时间段-结束时间
      * @response 200 developHistory ok
    */
  async getDevelopHistoryList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        title: query.title,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        title: { type: 'string', trim: true, required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.developHistory.getDevelopHistoryList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增发展历程接口
    * @description 新增发展历程
    * @router post /developHistory
    * @request header string *token token令牌
    * @request body addDevelopHistoryRequest developHistory 发展历程实例
    * @response 200 developHistory ok
*/
  async addDevelopHistory() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        title: { type: 'string', trim: true, required: true },
        status: { type: 'number', required: false },
        developTime: { type: 'string', required: true },
        // sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.developHistory.addDevelopHistory(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑发展历程接口
     * @description 修改发展历程
     * @router put /developHistory/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editDevelopHistoryRequest developHistory 发展历程实例
     * @response 200 developHistory ok
    */
  async editDevelopHistory() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        title: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        developTime: { type: 'string', required: false },
        // sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.developHistory.editDevelopHistory(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取发展历程详情接口
    * @description 根据id，获取发展历程详情
    * @router get /developHistory/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 developHistory ok
  */
  async getDevelopHistoryById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.developHistory.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = DevelopHistoryController;
