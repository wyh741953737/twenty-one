/*
 * @Description: 系统配置
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-10 17:56:28
 */
'use strict';
const BaseController = require('./base');

/**
* @controller Icon
*/
class IconController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'icon';
  }

  /**
    * @summary 获取字体图标列表接口
    * @description 获取字体图标列表
    * @router get /icon
    * @request header string *token token令牌
    * @request query string type 类型（1.解决方案，2：融平台体系）
    * @response 200 icon ok
  */
  async getIconList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        type: query.type,
      };
      const rule = {
        type: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.icon.getIconList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = IconController;
