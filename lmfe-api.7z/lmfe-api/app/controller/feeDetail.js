'use strict';
const BaseController = require('./base');

/**
* @controller FeeDetail 费用明细
*/
class FeeDetailController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'feeDetail';
  }

  /**
    * @summary 获取费用明细列表接口(官网使用)
    * @description 获取费用明细列表
    * @router get /web/feeDetail
    * @response 200 feeDetail ok
  */
  async getFeeDetailListForWeb() {
    const { ctx, service } = this;
    try {
      const res = await service.feeDetail.getWebFeeDetailList();
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}
module.exports = FeeDetailController;
