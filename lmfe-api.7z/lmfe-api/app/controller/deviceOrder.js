'use strict';
const BaseController = require('./base');

/**
* @controller deviceOrder 设备告警
*/
class DeviceOrderController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'deviceOrder';
  }

  /**
    * @summary 获取设备告警列表接口(官网使用)
    * @description 获取设备告警列表
    * @router get /web/deviceOrder
    * @request query string buildName 楼幢名称
    * @request query string floorName 楼层名称
    * @request query string deviceType 设备类型（示例：1,3,5）
    * @request query string deviceNum 设备编号
    * @response 200 deviceOrder ok
  */
  async getDeviceOrderListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        buildName: query.buildName,
        floorName: query.floorName,
        deviceType: query.deviceType,
        deviceNum: query.deviceNum,
      };
      const res = await service.deviceOrder.getDeviceOrderList(param);
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
   * @summary 获取工单详情接口(官网使用)
   * @description 获取工单详情
   * @router get /web/deviceOrder/{id}
   * @request path string *id 工单id
   * @response 200 deviceOrder ok
   */
  async getOrderByOrderId() {
    try {
      const {
        ctx,
        service,
      } = this;
      const { id } = ctx.params;
      const rule = {
        id: {
          type: 'string',
          required: true,
        },
      };
      ctx.validate(rule, {
        id,
      });
      const result = await service.deviceOrder.show(id);
      this.success(result || {});
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = DeviceOrderController;
