'use strict';
const BaseController = require('./base');

/**
 * @controller Device 设备告警
 */
class DeviceController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'device';
  }

  /**
   * @summary 获取设备列表接口(官网使用)
   * @description 获取设备列表
   * @router get /web/device/list
   * @request query string deviceType 设备类型
   * @response 200 device ok
   */
  async getDeviceListForWeb() {
    const {
      ctx,
      service,
    } = this;
    try {
      const query = ctx.query;
      const param = {
        deviceType: query.deviceType,
      };
      const res = await service.device.getWebDeviceList(param);
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
   * @summary 获取设备详情接口(官网使用)
   * @description 获取设备详情
   * @router get /web/device
   * @request query string *deviceNum 设备编号
   * @response 200 device ok
   */
  async getDeviceByDeviceNum() {
    try {
      const {
        ctx,
        service,
      } = this;
      const deviceNum = ctx.query.deviceNum;
      const rule = {
        deviceNum: {
          type: 'string',
          required: true,
        },
      };
      ctx.validate(rule, {
        deviceNum,
      });
      const result = await service.device.getDeviceByDeviceNum({
        deviceNum,
      });
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = DeviceController;
