'use strict';
const BaseController = require('./base');

/**
* @controller House 房号
*/
class HouseController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'house';
  }

  /**
    * @summary 获取房号列表接口(官网使用)
    * @description 获取房号列表
    * @router get /web/house
    * @response 200 house ok
  */
  async getHouseListForWeb() {
    const { ctx, service } = this;
    try {
      const res = await service.house.getWebHouseList();
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
  * @summary 根据新闻id，获取房间详情接口(官网)
  * @description 根据新闻id，房间详情
  * @router get /web/house/{houseId}
  * @request path string *houseId 房号id
  * @response 200 house ok
*/
  async getHouseByIdForWeb() {
    try {
      const { ctx, service } = this;
      const { houseId } = ctx.params;
      const rule = {
        houseId: { type: 'string', required: true },
      };
      ctx.validate(rule, { houseId });
      const result = await service.house.getWebHouseById(houseId);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
  /**
  * @summary 模糊搜索房间列表
  * @description 根据
  * @router get /web/houseList/search
  * @request query string curPage 当前页
  * @request query string pageSize 条数
  * @request query string name 房号/地址
  * @request query string minArea 最小面积
  * @request query string maxArea 最大面积
  * @request query string minRentalPrice 最低月租金最
  * @request query string maxRentalPrice 最高月租金最
  * @request query string vacantStatus 房态筛选状态 （0：空置中，1：3个月内到期，2：6个月内到期）
  * @response 200 house ok
*/
  async getWebHouseListBySearch() {
    const { ctx, service } = this;
    try {
      const { query } = ctx;
      const param = {
        maxArea: query.maxArea,
        minArea: query.minArea,
        maxRentalPrice: query.maxRentalPrice,
        minRentalPrice: query.minRentalPrice,
        vacantStatus: query.vacantStatus,
        name: query.name,
      };
      const rule = {
        maxArea: { type: 'string', required: false },
        minArea: { type: 'string', trim: true, required: false },
        maxRentalPrice: { type: 'string', required: false },
        minRentalPrice: { type: 'string', required: false },
        vacantStatus: { type: 'string', required: false },
        name: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.house.getWebHouseListBySearch(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}
module.exports = HouseController;
