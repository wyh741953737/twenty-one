'use strict';
const BaseController = require('./base');

/**
* @controller OperateHistory 操作历史
*/
class OperateHistoryController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'operateHistory';
  }

  /**
    * @summary 获取操作历史列表接口(官网使用)
    * @description 获取操作历史列表
    * @router get /web/operateHistory
    * @response 200 operateHistory ok
  */
  async getOperateHistoryListForWeb() {
    const { ctx, service } = this;
    try {
      const res = await service.operateHistory.getWebOperateHistoryList();
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}
module.exports = OperateHistoryController;
