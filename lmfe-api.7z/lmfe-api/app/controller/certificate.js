/*
 * @Description: 荣誉资质
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 17:41:19
 */
'use strict';
const BaseController = require('./base');
/**
* @controller Certificate 荣誉资质
*/

class CertificateController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'certificate';
  }


  /**
      * @summary 获取荣誉资质列表接口
      * @description 获取荣誉资质列表
      * @router get /certificate
      * @request header string *token token令牌
      * @request query string id id
      * @request query string name 荣誉资质证书名字
      * @request query number type 证书图片类型（1横版，2竖版）
      * @request query number status 状态（1正常，0关闭）
      * @request query string startTime 创建时间段-开始时间
      * @request query string endTime 创建时间段-结束时间
      * @response 200 certificate ok
    */
  async getCertificateList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        name: query.name,
        type: query.type,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        name: { type: 'string', trim: true, required: false },
        type: { type: 'string', required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.certificate.getCertificateList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增荣誉资质接口
    * @description 新增荣誉资质
    * @router post /certificate
    * @request header string *token token令牌
    * @request body addCertificateRequest certificate 荣誉资质实例
    * @response 200 certificate ok
*/
  async addCertificate() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        name: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        type: { type: 'number', required: true },
        url: { type: 'string', trim: true, required: false },
        sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.certificate.addCertificate(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑荣誉资质接口
     * @description 修改荣誉资质
     * @router put /certificate/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editCertificateRequest certificate 荣誉资质实例
     * @response 200 certificate ok
    */
  async editCertificate() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        name: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        type: { type: 'number', required: false },
        url: { type: 'string', trim: true, required: false },
        sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.certificate.editCertificate(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取荣誉资质详情接口
    * @description 根据id，获取荣誉资质详情
    * @router get /certificate/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 certificate ok
  */
  async getCertificateById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.certificate.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = CertificateController;
