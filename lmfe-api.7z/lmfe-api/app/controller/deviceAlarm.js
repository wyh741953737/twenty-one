'use strict';
const BaseController = require('./base');

/**
* @controller DeviceAlarm 设备告警
*/
class DeviceAlarmController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'deviceAlarm';
  }

  /**
    * @summary 获取设备告警列表接口(官网使用)
    * @description 获取设备告警列表
    * @router get /web/deviceAlarm
    * @request query string buildName 楼幢名称
    * @request query string floorName 楼层名称
    * @request query string deviceType 设备类型
    * @request query string deviceNum 设备编号
    * @response 200 deviceAlarm ok
  */
  async getDeviceAlarmListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        buildName: query.buildName,
        floorName: query.floorName,
        deviceType: query.deviceType,
        deviceNum: query.deviceNum,
      };
      const res = await service.deviceAlarm.getDeviceALarmList(param);
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
   * @summary 获取告警详情接口(官网使用)
   * @description 获取告警详情
   * @router get /web/deviceAlarm/{id}
   * @request path string *id 告警id
   * @response 200 deviceAlarm ok
   */
  async getAlarmByAlarmId() {
    try {
      const {
        ctx,
        service,
      } = this;
      const { id } = ctx.params;
      const rule = {
        id: {
          type: 'string',
          required: true,
        },
      };
      ctx.validate(rule, {
        id,
      });
      const result = await service.deviceAlarm.show(id);
      this.success(result || {});
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = DeviceAlarmController;
