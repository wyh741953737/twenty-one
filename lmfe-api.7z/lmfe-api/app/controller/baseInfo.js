/*
 * @Description: 公司基础信息
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 10:57:11
 */
'use strict';
const BaseController = require('./base');

/**
* @controller BaseInfo 公司基础信息
*/
class BaseInfoController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'baseInfo';
  }

  /**
    * @summary 获取企业介绍接口(官网使用)
    * @description 获取企业介绍
    * @router get /web/companyIntroduce
    * @response 200 CompanyIntroduceResponse ok
  */
  async getCompanyIntroduceForWeb() {
    const { ctx, service } = this;
    try {
      // 公司基础信息
      const baseInfoRes = await service.baseInfo.getBaseInfo();
      baseInfoRes.welfareList = JSON.parse(baseInfoRes.welfareList);
      const param = {
        status: 1,
      };
      // 资质证书
      const certificateRes = await service.certificate.getCertificateListForWeb(param);
      const horizontalImgList = certificateRes.filter(item => item.type === 1);
      const verticalImgList = certificateRes.filter(item => item.type === 2);
      // 发展历程
      const developHistoryRes = await service.developHistory.getDevelopHistoryListForWeb(param);
      const result = {
        baseInfo: baseInfoRes || {},
        horizontalImgList: horizontalImgList || [],
        verticalImgList: verticalImgList || [],
        developHistoryList: developHistoryRes || [],
      };
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
* @summary 获取公司基础信息详情接口(官网使用)
* @description 获取公司基础信息
* @router get /web/baseInfo
* @response 200 baseInfo ok
*/
  async getBaseInfoForWeb() {
    const { ctx, service } = this;
    try {
      const result = await service.baseInfo.getBaseInfo();
      result.welfareList = JSON.parse(result.welfareList);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
  * @summary 获取公司基础信息详情接口
  * @description 获取公司基础信息
  * @router get /baseInfo
  * @request header string *token token令牌
  * @response 200 baseInfo ok
*/
  async getBaseInfo() {
    const { ctx, service } = this;
    try {
      const result = await service.baseInfo.getBaseInfo();
      result.welfareList = JSON.parse(result.welfareList);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑公司基础信息接口
    * @description 编辑公司基础信息
    * @router put /baseInfo/{id}
    * @request header string *token token令牌
    * @request path string id 公司id
    * @request body editBaseInfoRequest baseInfo 基础信息
    * @response 200 baseInfo ok
  */
  async editBaseInfo() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const user = ctx.session.user;
      model.updateUser = user.realName;
      model.updateUserId = user.id;
      const rule = {
        id: { type: 'string', required: true },
        companyName: { type: 'string', required: false },
        companyNameEN: { type: 'string', required: false },
        logo: { type: 'string', trim: true, required: false },
        phone: { type: 'string', trim: true, required: false },
        address: { type: 'string', required: false },
        email: { type: 'string', required: false },
        postcode: { type: 'string', required: false },
        invitePhone: { type: 'string', required: false },
        inviteEmail: { type: 'string', required: false },
        latitude: { type: 'string', required: false },
        longitude: { type: 'string', required: false },
        qrCodeUrl: { type: 'string', trim: true, required: false },
        copyright: { type: 'string', required: false },
        websiteICP: { type: 'string', required: false },
        companyIntro: { type: 'string', required: false },
        companyImg: { type: 'string', trim: true, required: false },
        welfareList: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.updateTime = new Date();
      const result = await service.baseInfo.editBaseInfo(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = BaseInfoController;
