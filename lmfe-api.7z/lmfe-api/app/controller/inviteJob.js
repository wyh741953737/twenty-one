/*
 * @Description: 招聘信息
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2020-04-07 12:05:33
 */
'use strict';
const BaseController = require('./base');
/**
* @controller InviteJob 招聘信息
*/

class InviteJobController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'inviteJob';
  }

  /**
    * @summary 获取招聘信息接口(官网使用)
    * @description 获取招聘信息
    * @router get /web/inviteJob
    * @request query string jobName 岗位名字
    * @response 200 inviteJob ok
  */
  async getInviteJobListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        status: 1,
        jobName: query.jobName,
      };
      const rule = {
        jobName: { type: 'string', trim: true, required: false },
      };
      ctx.validate(rule, param);
      const result = await service.inviteJob.getInviteJobList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
      * @summary 获取招聘信息列表接口
      * @description 获取招聘信息列表
      * @router get /inviteJob
      * @request header string *token token令牌
      * @request query string id id
      * @request query string jobName 岗位名字
      * @request query string type 工作类型（1全职，2兼职）
      * @request query number status 状态（1正常，0关闭）
      * @request query string startTime 发布时间段-开始时间
      * @request query string endTime 发布时间段-结束时间
      * @response 200 inviteJob ok
    */
  async getInviteJobList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        jobName: query.jobName,
        type: query.type,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        jobName: { type: 'string', trim: true, required: false },
        type: { type: 'string', required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.inviteJob.getInviteJobList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增招聘信息接口
    * @description 新增招聘信息
    * @router post /inviteJob
    * @request header string *token token令牌
    * @request body addInviteJobRequest inviteJob 招聘信息实例
    * @response 200 inviteJob ok
*/
  async addInviteJob() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        jobName: { type: 'string', trim: true, required: true },
        status: { type: 'number', required: false },
        type: { type: 'number', required: true },
        address: { type: 'string', required: true },
        url: { type: 'string', trim: true, required: false },
        sort: { type: 'number', required: false },
        description: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.inviteJob.addInviteJob(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑招聘信息接口
     * @description 修改招聘信息
     * @router put /inviteJob/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editInviteJobRequest inviteJob 招聘信息实例
     * @response 200 inviteJob ok
    */
  async editInviteJob() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        jobName: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        type: { type: 'number', required: false },
        address: { type: 'string', required: false },
        url: { type: 'string', trim: true, required: false },
        sort: { type: 'number', required: false },
        description: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.inviteJob.editInviteJob(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取招聘信息详情接口
    * @description 根据id，获取招聘信息详情
    * @router get /inviteJob/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 inviteJob ok
  */
  async getInviteJobById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.inviteJob.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = InviteJobController;
