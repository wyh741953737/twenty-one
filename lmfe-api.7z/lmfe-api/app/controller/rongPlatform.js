/*
 * @Description: 融平台体系
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-14 16:10:31
 */
'use strict';
const BaseController = require('./base');
/**
* @controller RongPlatform 融平台体系
*/

class RongPlatformController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'rongPlatform';
  }

  /**
    * @summary 获取融平台体系接口(官网使用)
    * @description 获取融平台体系
    * @router get /web/rongPlatform
    * @response 200 rongPlatform ok
  */
  async getRongPlatformListForWeb() {
    const { ctx, service } = this;
    try {
      const param = {
        status: 1,
      };
      // 服务平台
      const platformResult = await service.rongPlatform.getRongPlatformListForWeb({ ...param, type: 1, limit: 4 });
      // 服务体系
      const systemResult = await service.rongPlatform.getRongPlatformListForWeb({ ...param, type: 2, limit: 3 });
      const result = {
        platformList: platformResult || [],
        systemList: systemResult || [],
      };
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
      * @summary 获取融平台体系列表接口
      * @description 获取融平台体系列表
      * @router get /rongPlatform
      * @request header string *token token令牌
      * @request query string id id
      * @request query string title '融平台体系标题
      * @request query number status 状态（1正常，0关闭）
      * @request query number type 类型（1.服务平台，2：服务体系）
      * @request query string startTime 创建时间段-开始时间
      * @request query string endTime 创建时间段-结束时间
      * @response 200 rongPlatform ok
    */
  async getRongPlatformList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        title: query.title,
        type: query.type,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        title: { type: 'string', required: false },
        type: { type: 'string', required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.rongPlatform.getRongPlatformList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增融平台体系接口
    * @description 新增融平台体系
    * @router post /rongPlatform
    * @request header string *token token令牌
    * @request body addRongPlatformRequest rongPlatform 融平台体系实例
    * @response 200 rongPlatform ok
*/
  async addRongPlatform() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        title: { type: 'string', required: true },
        type: { type: 'number', required: true },
        iconName: { type: 'string', required: false },
        cover: { type: 'string', trim: true, required: false },
        summary: { type: 'string', required: false },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.rongPlatform.addRongPlatform(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑融平台体系接口
     * @description 修改融平台体系
     * @router put /rongPlatform/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editRongPlatformRequest rongPlatform 融平台体系实例
     * @response 200 rongPlatform ok
    */
  async editRongPlatform() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        title: { type: 'string', required: false },
        type: { type: 'number', required: false },
        iconName: { type: 'string', required: false },
        cover: { type: 'string', trim: true, required: false },
        summary: { type: 'string', required: false },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.rongPlatform.editRongPlatform(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取融平台体系详情接口
    * @description 根据id，获取融平台体系详情
    * @router get /rongPlatform/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 rongPlatform ok
  */
  async getRongPlatformById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.rongPlatform.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = RongPlatformController;
