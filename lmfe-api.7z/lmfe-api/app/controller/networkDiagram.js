'use strict';
const BaseController = require('./base');

/**
* @controller networkDiagram 网络图
*/
class NetworkDiagramController extends BaseController {
  constructor(ctx) {
    super(ctx);
  }

  /**
    * @summary 查询网络图列表
    * @description 查询网络图列表
    * @router get /networkDiagram/list
    * @request header string *token token
    * @request query string name 名称
    * @request query string type 类型
    * @request query string inuser 创建人
    * @request query string intimeBegin 创建时间-开始时间
    * @request query string intimeEnd 创建时间-结束时间
    * @request query string updateUser 最后更新人
    * @request query string updateTimeBegin 最后更新时间-开始时间
    * @request query string updateTimeEnd 最后更新时间-结束时间
    * @response 200 list ok
  */
  async list () {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const models = {
        name: query.name,
        type: query.type,
        inuser: query.inuser,
        intimeBegin: query.intimeBegin,
        intimeEnd: query.intimeEnd,
        updateUser: query.updateUser,
        updateTimeBegin: query.updateTimeBegin,
        updateTimeEnd: query.updateTimeEnd
      };
      const result = await service.networkDiagram.list(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询网络图详情【免登】
    * @description 查询网络图详情【免登】
    * @router get /networkDiagram/detail/{id}
    * @request path string *id 网络图id
    * @response 200 item ok
  */
  async detailForWeb () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.networkDiagram.show(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询网络图详情
    * @description 查询网络图详情
    * @router get /networkDiagram/detail/{id}
    * @request header string *token token
    * @request path string *id 网络图id
    * @response 200 item ok
  */
  async detail () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.networkDiagram.show(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增网络图
    * @description 新增网络图
    * @router post /networkDiagram/add
    * @request header string *token token
    * @response 200 id ok
  */
  async add () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        name: { type: 'string', trim: true, required: true }
      };
      const models = {
        type: 2,
        remark: body.remark,
        inuser: user.id,
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.networkDiagram.add(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑网络图 - 基础
    * @description 编辑网络图 - 基础
    * @router put /networkDiagram/edit
    * @request header string *token token
    * @response 200 id ok
  */
  async edit () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        name: { type: 'string', trim: true, required: true }
      };
      const models = {
        remark: body.remark,
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.networkDiagram.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  
  /**
    * @summary 编辑网络图 - 设计
    * @description 编辑网络图 - 设计
    * @router put /networkDiagram/saveDesign
    * @request header string *token token
    * @response 200 id ok
  */
  async saveDesign () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        data: { type: 'string', required: true }
      };
      const models = {
        update_user: user.id
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.networkDiagram.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = NetworkDiagramController;
