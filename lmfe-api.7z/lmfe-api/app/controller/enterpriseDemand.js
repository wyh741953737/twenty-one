'use strict';
const BaseController = require('./base');

/**
 * @controller EnterpriseDemand 企业诉求
 */
class EnterpriseDemandController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'EnterpriseDemand';
  }

  /**
   * @summary 获取企业需求接口(官网使用)
   * @description 获取企业需求
   * @router get /web/enterpriseDemand
   * @request query string type 需求类型
   * @response 200 enterpriseDemand ok
   */
  async getEnterpriseDemandForWeb() {
    const {
      ctx,
      service,
    } = this;
    try {
      const query = ctx.query;
      const param = {
        type: query.type,
      };
      const res = await service.enterpriseDemand.getEnterpriseDemandList(param);
      this.success(res);
    } catch (e) {
      this.error(e);
    }
  }

  /**
   * @summary 获取企业需求详情接口(官网使用)
   * @description 获取企业需求详情
   * @router get /web/enterpriseDemand/{id}
   * @request path string *id 需求id
   * @response 200 enterpriseDemand ok
   */
  async getEnterpriseDemandById() {
    try {
      const {
        ctx,
        service,
      } = this;
      const { id } = ctx.params;
      const rule = {
        id: {
          type: 'string',
          required: true,
        },
      };
      ctx.validate(rule, {
        id,
      });
      const result = await service.enterpriseDemand.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }

  /**
   * @summary 获取需求概览数据接口(官网使用)
   * @description 获取需求概览数据
   * @router get /web/enterpriseDemandOverview
   * @request query string buildNum 所属楼幢
   * @request query string floorNum 所属楼层
   * @response 200 enterpriseDemandOverview ok
   */
  async getEnterpriseDemandOverview() {
    const {
      ctx,
      service,
    } = this;
    try {
      const query = ctx.query;
      const param = {
        buildNum: query.buildNum,
        floorNum: query.floorNum,
      };
      const res = await service.enterpriseDemand.getEnterpriseDemandOverview(param);
      this.success(res);
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = EnterpriseDemandController;
