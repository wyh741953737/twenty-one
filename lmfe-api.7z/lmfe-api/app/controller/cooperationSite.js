/*
 * @Description: 合作伙伴模块
 * @Author: FCC
 * @Date: 2019-09-04 10:48:19
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-29 10:05:15
 */

'use strict';
const BaseController = require('./base');

/**
* @controller CooperationSite 合作伙伴
*/
class CooperationSiteController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'cooperationSite';
  }
  /**
    * @summary 获取合作伙伴信息接口(官网使用)
    * @description 获取合作伙伴信息
    * @router get /web/cooperationSite
    * @response 200 cooperationSite ok
  */
  async getCooperationSiteForWeb() {
    const { ctx, service } = this;
    try {
      const result = await service.cooperationSite.getCooperationSiteListForWeb();
      const topItem = result.find(item => item.type === 2);
      const categoryList = result.filter(item => item.type === 1);
      const ecoServiceList = result.filter(item => item.type === 3);
      const res = {
        topImg: topItem ? topItem.bigImg : '',
        categoryList: categoryList || [],
        ecoServiceList: ecoServiceList || [],
      };
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 获取合作伙伴列表接口
    * @description 获取合作伙伴列表
    * @router get /cooperationSite
    * @request header string *token token令牌
    * @request query string id 合作伙伴id
    * @request query string title 标题
    * @request query number status 状态（1：正常，0：关闭）
    * @request query number type 类型（1:领域分类，2:icon集合图，3:生态服务）
    * @request query string startTime 创建时间段-开始时间
    * @request query string endTime 创建时间段-结束时间
    * @response 200 cooperationSite ok
  */
  async getCooperationSiteList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        title: query.title,
        status: query.status,
        type: query.type,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        title: { type: 'string', required: false },
        status: { type: 'string', required: false },
        type: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.cooperationSite.getCooperationSiteList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 新增合作伙伴接口
    * @description 新增合作伙伴
    * @router post /cooperationSite
    * @request header string *token token令牌
    * @request body addCooperationSiteRequest cooperationSite 合作伙伴实例
    * @response 200 cooperationSite ok
  */
  async addCooperationSite() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        title: { type: 'string', trim: true, required: true },
        type: { type: 'number', required: true },
        content: { type: 'string', required: false },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: false },
        typeIcon: { type: 'string', required: false },
        bigImg: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.cooperationSite.addCooperationSite(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑合作伙伴接口
    * @description 修改合作伙伴
    * @router put /cooperationSite/{id}
    * @request header string *token token令牌
    * @request path string *id 合作伙伴id
    * @request body editCooperationSiteRequest cooperationSite 合作伙伴实例
    * @response 200 cooperationSite ok
  */
  async editCooperationSite() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        title: { type: 'string', trim: true, required: false },
        type: { type: 'number', required: false },
        content: { type: 'string', required: false },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: false },
        typeIcon: { type: 'string', required: false },
        bigImg: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.cooperationSite.editCooperationSite(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 根据合作伙伴id，获取合作伙伴详情接口
    * @description 根据合作伙伴id，获取合作伙伴详情
    * @router get /cooperationSite/{id}
    * @request header string *token token令牌
    * @request path string *id 合作伙伴id
    * @response 200 cooperationSite ok
  */
  async getCooperationSiteById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.cooperationSite.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = CooperationSiteController;
