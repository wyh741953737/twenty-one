'use strict';
const BaseController = require('./base');

/**
* @controller enterprise 企业
*/
class EnterpriseController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'enterprise';
  }

  /**
    * @summary 获取企业列表接口(官网使用)
    * @description 获取企业列表
    * @router get /web/enterprise
    * @request query string buildNum 楼幢编号
    * @request query string floorNum 楼层编号
    * @request query string vitalityType 企业活力（1:A,2:B,3:C,4:D）
    * @request query string safeProductionType 安全生产（1:A,2:B,3:C,4:D）
    * @request query string technologicalInnovationType 科技创新（1:A,2:B,3:C,4:D）
    * @request query string creditRatingType 信用评级（1:A,2:B,3:C,4:D）
    * @request query string enterpriseCooperationType 园企配合（1:A,2:B,3:C,4:D）
    * @response 200 enterprise ok
  */
  async getEnterPriseListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        buildNum: query.buildNum,
        floorNum: query.floorNum,
        vitalityType: query.vitalityType,
        safeProductionType: query.safeProductionType,
        technologicalInnovationType: query.technologicalInnovationType,
        creditRatingType: query.creditRatingType,
        enterpriseCooperationType: query.enterpriseCooperationType,
      };
      const rule = {
        buildNum: { type: 'string', required: false },
        floorNum: { type: 'string', required: false },
        vitalityType: { type: 'string', required: false },
        safeProductionType: { type: 'string', required: false },
        technologicalInnovationType: { type: 'string', required: false },
        creditRatingType: { type: 'string', required: false },
        enterpriseCooperationType: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const res = await service.enterprise.getWebEnterpriseList(param);
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
  * @summary 根据企业id，获取企业详情接口(官网)
  * @description 根据企业id，获取企业详情
  * @router get /web/enterprise/{id}
  * @request path string *id 企业id
  * @response 200 enterpriseResponse ok
*/
  async getEnterPriseForWeb() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.enterprise.getWebEnterpriseById(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }


  /**
  * @summary 获取不同类型企业数(官网)
  * @description 获取不同类型企业数
  * @router get /web/getEnterpriseCount
  * @request query string floorNum 企业楼层
  * @response 200 enterprise ok
*/
  async getCountByType() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        floorNum: query.floorNum,
      };
      const rule = {
        floorNum: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.enterprise.getCountByType(param);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }

  /**
   * @summary 获取企业概览数据接口(主要用于产业服务-右侧面板)
   * @description 获取企业概览数据
   * @router get /web/enterpriseOverview
   * @request query string buildNum 所属楼幢
   * @request query string floorNum 所属楼层
   * @response 200 enterpriseOverview ok
   */
  async getEnterpriseDemandOverview() {
    const {
      ctx,
      service,
    } = this;
    try {
      const query = ctx.query;
      const param = {
        buildNum: query.buildNum,
        floorNum: query.floorNum,
      };
      const res = await service.enterpriseDemand.getEnterpriseDemandOverview(param);
      this.success(res);
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = EnterpriseController;
