/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: 小广
 * @LastEditTime: 2020-04-07 11:35:23
 */
'use strict';
const BaseController = require('./base');
const path = require('path');
const { URL } = require('url');

/**
* @controller Upload 上传接口
*/
class UploadController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = '';
  }
  // eslint-disable-next-line jsdoc/require-param
  /**
    * @summary 上传接口
    * @description 上传接口
    * @router post /upload
    * @request query string *module module
    * @request formData file *file file
    * @response 200 uploadResponse ok
  */
  async upload(type) {
    const { ctx } = this;
    const module = ctx.query.module;
    const rule = {
      module: { type: 'string', trim: true },
    };
    ctx.validate(rule, {
      module,
    });
    const { url } = await this.ctx.helper.upload(module || 'common');

    if (url) {
      const host = ctx.request.host;
      const origin = host.indexOf('http') !== -1 ? host : ctx.request.origin;
      // 兼容富文本上传
      if (type === 'ueditor') {
        return new URL(path.join(origin, url));
      }
      this.success([ new URL(path.join(origin, url)) ]);
    } else {
      this.error('上传出错啦！');
    }
  }

  /**
    * @summary 富文本图片上传接口
    * @description 富文本图片上传接口(同时支持get&post请求)
    * @router post /uploadUEditor
    * @request query string *module 文件夹分类
    * @request query string *action 接口请求类型
    * @request formData file *file file
    * @response 200 uploadUEditorResponse ok
  */
  async uploadUEditor() {
    const { ctx } = this;
    const action = ctx.query.action;
    if (action === 'config') {
      ctx.body = {
        msg: '获取配置接口可访问',
        state: 'SUCCESS',
        err: '',
      };
    } else if (action === 'uploadimage' || action === 'uploadvideo') {
      const url = await this.upload('ueditor');
      if (url) {
        ctx.body = JSON.stringify({
          msg: url,
          state: 'SUCCESS',
        });
      } else {
        ctx.body = JSON.stringify({
          msg: '上传出错了',
          state: 'ERROR',
          err: '',
        });
      }
    }
  }
}

module.exports = UploadController;
