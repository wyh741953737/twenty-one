/*
 * @Description: 解决方案
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-10-10 16:43:48
 */
'use strict';
const BaseController = require('./base');
/**
* @controller Solution 解决方案
*/

class SolutionController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'solution';
  }

  /**
    * @summary 获取解决方案接口(官网使用)
    * @description 获取解决方案
    * @router get /web/solution
    * @response 200 solution ok
  */
  async getSolutionListForWeb() {
    const { ctx, service } = this;
    try {
      const param = {
        status: 1,
      };
      const result = await service.solution.getSolutionListForWeb(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
      * @summary 获取解决方案列表接口
      * @description 获取解决方案列表
      * @router get /solution
      * @request header string *token token令牌
      * @request query string id id
      * @request query string typeName 类型名字
      * @request query string title '解决方案标题
      * @request query number status 状态（1正常，0关闭）
      * @request query string startTime 创建时间段-开始时间
      * @request query string endTime 创建时间段-结束时间
      * @response 200 solution ok
    */
  async getSolutionList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        title: query.title,
        typeName: query.typeName,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        title: { type: 'string', required: false },
        typeName: { type: 'string', trim: true, required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.solution.getSolutionList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增解决方案接口
    * @description 新增解决方案
    * @router post /solution
    * @request header string *token token令牌
    * @request body addSolutionRequest solution 解决方案实例
    * @response 200 solution ok
*/
  async addSolution() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        title: { type: 'string', required: true },
        typeName: { type: 'string', trim: true, required: true },
        typeEnName: { type: 'string', required: true },
        iconName: { type: 'string', required: true },
        cover: { type: 'string', trim: true, required: true },
        smallCover: { type: 'string', trim: true, required: true },
        content: { type: 'string', required: true },
        bigImg: { type: 'string', trim: true, required: true },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: true },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.solution.addSolution(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑解决方案接口
     * @description 修改解决方案
     * @router put /solution/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editSolutionRequest solution 解决方案实例
     * @response 200 solution ok
    */
  async editSolution() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        title: { type: 'string', required: false },
        typeName: { type: 'string', trim: true, required: false },
        typeEnName: { type: 'string', required: false },
        iconName: { type: 'string', required: false },
        cover: { type: 'string', trim: true, required: false },
        smallCover: { type: 'string', trim: true, required: false },
        content: { type: 'string', required: false },
        bigImg: { type: 'string', trim: true, required: false },
        status: { type: 'number', required: false },
        sort: { type: 'number', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.solution.editSolution(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据id，获取解决方案详情接口
    * @description 根据id，获取解决方案详情
    * @router get /solution/{id}
    * @request header string *token token令牌
    * @request path string *id id
    * @response 200 solution ok
  */
  async getSolutionById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.solution.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = SolutionController;
