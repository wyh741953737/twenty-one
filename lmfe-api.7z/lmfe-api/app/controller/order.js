/*
 * @Description: 工单模块
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2020-04-08 14:20:59
 */
'use strict';
const BaseController = require('./base');
const dayjs = require('dayjs');

/**
* @controller Order 工单动态
*/
class OrderController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'order';
  }

  /**
    * @summary 获取工单列表接口
    * @description 获取工单列表
    * @router get /order
    * @request header string *token token令牌
    * @request query string id 工单id
    * @request query string title 工单标题
    * @request query string type 新闻类型新闻类型（1行业新闻，2公司新闻，3社会责任）
    * @request query number status 工单状态（0：待审核，1：审核通过, 2：已拒绝）
    * @request query string inTimeBegin 工单创建时间-开始时间
    * @request query string inTimeEnd 工单创建时间-结束时间
    * @request query string updateTimeBegin 工单编辑时间-开始时间
    * @request query string updateTimeEnd 工单编辑时间-结束时间
    * @response 200 order ok
  */
  async getOrderList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        title: query.title,
        status: query.status,
        microAppId: query.microAppId,
        inTimeBegin: query.inTimeBegin,
        inTimeEnd: query.inTimeEnd,
        auditTimeBegin: query.auditTimeBegin,
        auditTimeEnd: query.auditTimeEnd
      };
      const result = await service.order.getOrderList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增工单接口
    * @description 新增工单
    * @router post /order
    * @request header string *token token令牌
    * @request body addOrderRequest order 工单实例
    * @response 200 order ok
  */
  async addOrder() {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const model = ctx.request.body;
      model.createUserName = user.realName;
      model.createUserEmail = user.email;
      const rule = {
        title: { type: 'string', trim: true, required: true },
        microAppId: { type: 'number', required: true },
        branch: { type: 'string', required: true },
        executeShell: { type: 'string', required: true },
        content: { type: 'string', required: false }
      };
      model.status = 0;
      const result = await service.order.addOrder(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 根据工单id，获取工单详情接口
    * @description 根据工单id，获取工单详情
    * @router get /order/{id}
    * @request header string *token token令牌
    * @request path string *id 工单id
    * @response 200 order ok
  */
  async getOrderById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.order.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
  /**
    * @summary 编辑工单接口
    * @description 修改工单
    * @router put /order/{id}
    * @request header string *token token令牌
    * @request path string *id 工单id
    * @request body editOrderRequest order 工单实例
    * @response 200 order ok
  */
  async editOrder() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;

      const rule = {
        id: { type: 'string', required: true },
        title: { type: 'string', trim: true, required: false },
        microAppId: { type: 'number', required: false },
        branch: { type: 'string', required: false },
        executeShell: { type: 'string', required: false },
        content: { type: 'string', required: false }
      };
      ctx.validate(rule, model);
      model.updateTime = new Date();
      const result = await service.order.editOrder(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 复制工单接口
    * @description 复制工单
    * @router post /order/{id}/copy
    * @request header string *token token令牌
    * @request path string *id 工单id
    * @response 200 order ok
  */
 async copyOrder() {
  const { ctx, service } = this;
  try {
    const { id } = ctx.params;

    const rule = {
      id: { type: 'string', required: true }
    };
    ctx.validate(rule, { id });
    const result = await service.order.copyOrder({ id });
    this.success(result);
  } catch (e) {
    ctx.logger.error(e);
    this.error(e);
  }
}
  /**
    * @summary 审核工单接口
    * @description 审核工单
    * @router put /order/{id}/changeStatus
    * @request header string *token token令牌
    * @request path string *id 工单id
    * @request query string *status 工单状态
    * @response 200 order ok
  */
 async updateOrderStatus () {
  const { ctx, service } = this;
  try {
    const { id } = ctx.params;
    const {status, refuseReason } = ctx.request.query;
    const model = {}
    model.id = id;
    model.status = Number(status);
    model.refuseReason = refuseReason;
    let refuseReasonRequired = false;
    if (model.status === 2) {
      refuseReasonRequired = true;
    }
    const rule = {
      id: { type: 'string', required: true },
      status: { type: 'number', required: true },
      refuseReason: { type: 'string', required: refuseReasonRequired }
    };
    const user = ctx.session.user;
    model.auditUserName = user.realName
    model.auditUserEmail = user.email
    model.auditTime = new Date();
    ctx.validate(rule, model);
    const result = await service.order.updateOrderStatus(model);
    this.success(result);
  } catch (e) {
    ctx.logger.error(e);
    this.error(e);
  }
}
}

module.exports = OrderController;
