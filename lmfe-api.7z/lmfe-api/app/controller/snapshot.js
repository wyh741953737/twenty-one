/*
 * @Description: 快照
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: FCC
 * @LastEditTime: 2020-06-11 10:24:46
 */
'use strict';
const BaseController = require('./base');

const puppeteer = require('puppeteer');
const path = require('path');
const { URL } = require('url');

/**
* @controller Snapshot 快照
*/
class SnapshotController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = '';
  }
  /**
    * @summary 获取快照接口
    * @description 获取快照接口
    * @router post /snapshot
    * @request query string *url 目标地址
    * @request query string width 宽
    * @request query string height 高
    * @request query string type 快照页面类型：（1：物联网）
    * @response 200 snapshot ok
  */
  async createSnapshotByUrl() {
    const { ctx } = this;
    const { url, width, height, type } = ctx.query;
    const rule = {
      url: { type: 'string', trim: true },
    };
    ctx.validate(rule, {
      url,
    });
    const browser = await puppeteer.launch({
      args: [ '--no-sandbox' ],
      timeout: 0,
    });
    const page = await browser.newPage();
    page.setViewport({
      width: width ? Number(width) : 3000,
      height: height ? Number(height) : 1050,
    });
    // page.setClipRect({
    //   top: 0,
    //   left: 0,
    //   width: 3000,
    //   height: 1050,
    // });
    await page.goto(url);
    let ms = 3000;
    if (type === '1') {
      ms = 60000;
    }
    await page.waitFor(ms);
    // page.property('settings', {
    //   javascriptEnabled: true,
    //   loadImages: true,
    //   userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Safari/537.36',
    // });
    // const content = await page.property('content');
    const name = new Date().getTime();
    const fileName = `app/public/snapshot/${name}.png`;
    await page.screenshot({ path: fileName });
    await browser.close();
    const origin = `${ctx.request.protocol}://${ctx.request.header.host}`;
    this.success({
      imgUrl: new URL(path.join(origin, `public/snapshot/${name}.png`)),
    });
  }

  async main() {
    const { ctx } = this;
    const { path } = ctx.params;
    const browser = await puppeteer.launch({
      headless: true,
      args: [
        '--disable-gpu',
        '--disable-dev-shm-usage',
        '--disable-setuid-sandbox',
        '--no-first-run',
        '--no-sandbox',
        '--no-zygote',
        '--single-process',
      ],
      timeout: 0,
    });
    const page = await browser.newPage();
    const url = `https://devhome.uama.cc/${path}`;
    // page.setClipRect({
    //   top: 0,
    //   left: 0,
    //   width: 3000,
    //   height: 1050,
    // });
    await page.goto(url);
    const content = await page.content();
    this.ctx.body = content;
  }
}

module.exports = SnapshotController;
