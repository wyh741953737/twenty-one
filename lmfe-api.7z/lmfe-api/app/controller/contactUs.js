/*
 * @Description: 联系我们
 * @Author: 小广
 * @Date: 2019-09-25 14:57:49
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-27 10:56:57
 */
'use strict';
const BaseController = require('./base');
/**
* @controller ContactUs 联系我们
*/

class ContactUsController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'contactUs';
  }

  /**
    * @summary 新增联系我们接口(官网使用)
    * @description 新增联系我们
    * @router post /web/contactUs
    * @request body addContactUsRequest contactUs 联系我们实例
    * @response 200 contactUs ok
  */
  async addContactUsForWeb() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        name: { type: 'string', trim: true, required: true },
        companyName: { type: 'string', required: false },
        mobile: { type: 'string', trim: true, required: true },
        email: { type: 'string', trim: true, required: false },
        cityName: { type: 'string', trim: true, required: false },
        remark: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.contactUs.addContactUs(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 获取联系我们列表接口
    * @description 获取联系我们列表
    * @router get /contactUs
    * @request header string *token token令牌
    * @request query string id id
    * @request query string name 申请人名字
    * @request query string companyName 申请人公司
    * @request query number status 状态（1：已接待，0：未接待）
    * @request query string startTime 申请时间段-开始时间
    * @request query string endTime 申请时间段-结束时间
    * @response 200 contactUs ok
  */
  async getContactUsList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        name: query.name,
        companyName: query.companyName,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        name: { type: 'string', trim: true, required: false },
        companyName: { type: 'string', required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.contactUs.getContactUsList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
     * @summary 编辑联系我们接口
     * @description 修改联系我们
     * @router put /contactUs/{id}
     * @request header string *token token令牌
     * @request path string *id 应用id
     * @request body editContactUsRequest contactUs 联系我们实例
     * @response 200 contactUs ok
   */
  async editContactUs() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        status: { type: 'number', required: false },
        name: { type: 'string', trim: true, required: false },
        companyName: { type: 'string', required: false },
        mobile: { type: 'string', trim: true, required: false },
        email: { type: 'string', trim: true, required: false },
        cityName: { type: 'string', trim: true, required: false },
        remark: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      const result = await service.contactUs.editContactUs(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
  * @summary 根据id，获取联系我们详情接口
  * @description 根据id，获取联系我们详情
  * @router get /contactUs/{id}
  * @request header string *token token令牌
  * @request path string *id id
  * @response 200 contactUs ok
*/
  async getContactUsById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.contactUs.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}

module.exports = ContactUsController;
