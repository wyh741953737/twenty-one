/*
 * @Description: 菜单资源
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-25 16:22:24
 */
'use strict';
const BaseController = require('./base');
// const { v4 } = require('uuid');
class ResourceController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'resource';
  }
}

module.exports = ResourceController;
