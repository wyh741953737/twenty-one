/*
 * @Description: 焦点图管理
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2020-02-18 09:38:40
 */
'use strict';
const BaseController = require('./base');

/**
* @controller Focus 焦点图
*/
class FocusController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'focus';
  }

  /**
    * @summary 获取焦点图列表接口(官网使用)
    * @description 获取焦点图列表
    * @router get /web/focus
    * @request query string position 焦点图发布位置（1首页，2融平台） 默认1
    * @request query string mobile 平台类型（0：PC端， 1：移动端 ）默认0
    * @response 200 focus ok
  */
  async getFocusListForWeb() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        position: query.position || '1',
        mobile: query.mobile || '0',
        status: 1,
      };
      const rule = {
        position: { type: 'string', required: true },
      };
      ctx.validate(rule, param);
      const res = await service.focus.getWebFocusList(param);
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 获取焦点图列表接口
    * @description 获取焦点图列表
    * @router get /focus
    * @request header string *token token令牌
    * @request query string id 焦点图id
    * @request query string name 焦点图名称
    * @request query string position 焦点图发布位置（1首页，2融平台）
    * @request query number status 焦点图状态（1：正常，2：关闭）
    * @request query string type 焦点图类型（1：视频，2：图片）
    * @request query string startTime 上线时间段-开始时间
    * @request query string endTime 上线时间段-结束时间
    * @response 200 focus ok
  */
  async getFocusList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        name: query.name,
        position: query.position,
        status: query.status,
        type: query.type,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        name: { type: 'string', trim: true, required: false },
        position: { type: 'string', required: false },
        status: { type: 'string', required: false },
        type: { type: 'string', required: false },
        startTime: { type: 'string', required: false },
        endTime: { type: 'string', required: false },
      };
      ctx.validate(rule, param);
      const result = await service.focus.getFocusList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增焦点图接口
    * @description 新增焦点图
    * @router post /focus
    * @request header string *token token令牌
    * @request body addFocusRequest focus 焦点图实例
    * @response 200 focus ok
  */
  async addFocus() {
    const { ctx, service } = this;
    try {
      const model = ctx.request.body;
      const rule = {
        name: { type: 'string', trim: true, required: true },
        subName: { type: 'string', trim: true, required: false },
        position: { type: 'number', required: true },
        showTitle: { type: 'number', required: false },
        status: { type: 'number', required: true },
        type: { type: 'number', required: true },
        cover: { type: 'string', required: false },
        sort: { type: 'number', required: true },
        onlineTime: { type: 'string', required: false },
        outsideUrl: { type: 'string', required: false },
        videoUrl: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.focus.addFocus(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 根据焦点图id，获取焦点图详情接口
    * @description 根据焦点图id，获取焦点图详情
    * @router get /focus/{id}
    * @request header string *token token令牌
    * @request path string *id 焦点图id
    * @response 200 focus ok
  */
  async getFocusById() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.focus.show(id);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
  /**
    * @summary 编辑焦点图接口
    * @description 修改焦点图
    * @router put /focus/{id}
    * @request header string *token token令牌
    * @request path string *id 应用id
    * @request body editFocusRequest focus 焦点图实例
    * @response 200 focus ok
  */
  async editFocus() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const model = ctx.request.body;
      model.id = id;
      const rule = {
        id: { type: 'string', required: true },
        name: { type: 'string', trim: true, required: false },
        position: { type: 'number', required: false },
        showTitle: { type: 'number', required: false },
        status: { type: 'number', required: false },
        type: { type: 'number', required: false },
        cover: { type: 'string', required: false },
        sort: { type: 'number', required: false },
        onlineTime: { type: 'string', required: false },
        outsideUrl: { type: 'string', required: false },
        videoUrl: { type: 'string', required: false },
      };
      ctx.validate(rule, model);
      model.intime = new Date();
      const result = await service.focus.editFocus(model);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = FocusController;
