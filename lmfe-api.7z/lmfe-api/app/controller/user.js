/*
 * @Description: 用户信息
 * @Author: 木犀
 * @Date: 2019-07-11 16:11:43
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-25 16:24:14
 */
// eslint-disable-next-line strict
const BaseController = require('./base');
const { v4 } = require('uuid');
// 密码加密的模块
const NodeAuth = require('node-auth0');
// 引入MD5模块
const md5 = require('md5-node');
// 生成svg验证码的模块
const svgCaptcha = require('svg-captcha');
// 引入jsonwebtoken对登录模块校验的
const { sign } = require('jsonwebtoken');

/**
* @controller User 用户信息
*/
class UserController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'user';
    this.nodeAuth = new NodeAuth.default(8, 10, true);
  }

  /**
    * @summary 用户登录接口
    * @description 支持根据用户名，手机号，邮箱三种登录方式
    * @router post /user/login
    * @request body loginRequest user 登录参数
    * @response 200 loginResponse ok
  */
  async login() {
    const { ctx, service } = this;
    try {
      const body = ctx.request.body;
      // 用户可能用name、email、手机号码登录
      const rule = {
        userName: { type: 'string', trim: true },
        password: { type: 'string', trim: true },
      // captcha: { type: 'string', trim: true },
      };
      ctx.validate(rule);
      // 对验证码校验
      // const { code, message } = await this.checkCaptcha();
      // if (code === 1) {
      //   throw message;
      // }
      /** 处理用户输入用户名、邮箱、手机号码 账号 start */
      const { userName } = body;
      if (ctx.helper.isEmail.test(userName)) {
        body.email = userName;
      } else if (ctx.helper.isMobile.test(userName)) {
        body.mobile = userName;
      } else {
        body.name = userName;
      }
      delete body.userName;
      /** 处理用户输入用户名、邮箱、手机号码 账号 end */

      let result = await service.user.login(body);

      /** 对登录用户签名生成token并存储到session上 start */
      const token = sign(
        JSON.parse(JSON.stringify(result)),
        this.config.jwtSecret,
        {
          expiresIn: 7 * 24 * 60 * 60 * 1000, // 设置过期时间为7天
        }
      );
      ctx.session.token = token;
      result = {
        id: result.id,
        token,
      };
      /** 对登录用户签名生成token并存储到session上 end */
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增用户
    * @description 新增一个用户
    * @router post /user/add
    * @request header string *token token
    * @request body createUserRequest user 用户实例
    * @response 200 createUserResponse ok
  */
  async create() {
    const { ctx, service } = this;
    let requestData = ctx.request.body;
    try {
      // 数据校验
      const rule = {
        userName: { type: 'string', trim: true, max: 100, min: 1 },
        password: { type: 'string', trim: true },
        realName: { type: 'string', trim: true, max: 100, min: 1 },
        nickName: { type: 'string', required: false },
        email: { type: 'string', required: false },
        mobile: { type: 'string', required: false },
        gender: { type: 'number', required: false },
        userType: { type: 'number', required: true },
      };
      ctx.validate(rule);
      // 使用密码加密模块加密
      const { password } = requestData;
      requestData = {
        ...requestData,
        password: this.nodeAuth.makePassword(md5(password)), // 密码加密
        uuid: v4(), // 使用uuid
      };
      const exitUser = await service[this.entity].getUserByUniqueKey(requestData);
      if (exitUser) {
        if (exitUser.userName === requestData.userName) {
          this.error('用户名已存在');
        } else if (exitUser.mobile === requestData.mobile) {
          this.error('手机号已存在');
        }
        // } else if (exitUser.email === requestData.email) {
        //   this.error('邮箱已存在');
        // }
      } else {
        requestData.create_at = new Date();
        const result = await service[this.entity].createUser(requestData);
        delete result.password
        // 创建账号成功，则发送邮件到刚注册的邮箱
        // ctx.helper.sendEmail(requestData.name, requestData.email);
        this.success(result);
      }
    } catch (e) {
      this.error(e);
    }
  }


  /**
    * @summary 获取用户个人资料接口
    * @description 包含用户信息，角色信息，资源信息
    * @router get /getPersonalInfo
    * @request header string *token token令牌
    * @response 200 personalInfoResponse ok
  */
  async getCurrentUserInfo() {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const userId = user.id;
      // 获取用户信息
      const userInfo = await service[this.entity].show(userId);
      delete userInfo.password;
      // 获取角色Id
      const roleId = await service.roleUser.getRoleIdByUserId(userId);
      // 获取角色信息
      const roleInfo = await service.role.show(roleId);
      // 获取资源信息
      const resourceInfo = await service.roleResource.recursiveGetResourceByRoleId(roleId);
      const res = {
        userInfo,
        roleInfo,
        ...{
          resourceInfo,
        },
      };
      this.success(res);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 获取用户列表接口
    * @description 获取用户列表
    * @router get /user
    * @request header string *token token令牌
    * @request query string id 用户id
    * @request query string userName 用户名
    * @request query string realName 真实姓名
    * @request query string status 用户状态
    * @request query string startTime 开始时间
    * @request query string endTime 结束时间
    * @response 200 user ok
  */
  async getUserList() {
    const { ctx } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        userName: query.userName,
        realName: query.realName ? query.realName.trim() : undefined,
        status: query.status,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', trim: false, required: false },
        userName: { type: 'string', trim: false, required: false },
        realName: { type: 'string', trim: true, required: false },
        status: { type: 'string', required: false },
        startTime: { type: 'string', trim: true, required: false },
        endTime: { type: 'string', trim: true, required: false },
      };
      ctx.validate(rule, param);
      const result = await this.service.user.getUserList(param);
      if (result && result.resultList && result.resultList.length) {
        result.resultList.map(item => {
          delete item.password
        })
      }
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 获取用户详情接口
    * @description 获取用户详情
    * @router get /user/{id}
    * @request header string *token token令牌
    * @request path string *id userId
    * @response 200 user ok
  */
  async findOne() {
    const { ctx, service } = this;
    const param = ctx.params;
    try {
      const rule = {
        id: { type: 'string', trim: true, required: true },
      };
      const { id } = param;
      ctx.validate(rule, { id });
      const user = await service[this.entity].show(id);
      delete user.password
      const roleId = await service.roleUser.getRoleIdByUserId(id);
      const role = await service.role.show(roleId);
      if (user) {
        this.success({
          ...user,
          roleId,
          roleName: role.name,
        });
      } else {
        this.error('no data');
      }
    } catch (e) {
      this.error(e);
    }
  }

  /**
    * @summary 编辑用户接口
    * @description 编辑用户接口
    * @router put /user/{id}
    * @request header string *token token令牌
    * @request path string *id userId
    * @request body updateUserRequest *user user
    * @response 200 user ok
  */
  async update() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const requestData = ctx.request.body;
      delete requestData.password
      requestData.id = id;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule);
      requestData.update_at = new Date();
      const result = await service[this.entity].updateUser(requestData);
      delete result.password
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 更新密码接口
    * @description 修改用户密码
    * @router put /user/{id}/updatePassword
    * @request header string *token token令牌
    * @request path string *id userId
    * @request body updatePasswordRequest
    * @response 200 updatePasswordResponse ok
  */
  async updatePassword() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const requestData = ctx.request.body;
      requestData.id = id;
      // 获取用户老密码
      const user = await service[this.entity].show(id);
      if (!user) {
        this.error('用户不存在！');
        return;
      }
      const oldPassword = md5(requestData.oldPassword);
      if (this.nodeAuth.checkPassword(oldPassword, user.password)) {
        requestData.password = this.nodeAuth.makePassword(md5(requestData.newPassword));
        delete requestData.oldPassword;
        delete requestData.newPassword;
        requestData.update_at = new Date();
        await service[this.entity].update(requestData);
        this.success();
      } else {
        this.error('原密码错误');
      }

    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 重置密码接口
    * @description 重置用户密码
    * @router put /user/{id}/resetPassword
    * @request header string *token token令牌
    * @request path string *id userId
    * @response 200 updatePasswordResponse ok
  */
  async resetPassword() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      // 获取用户老密码
      const user = await service[this.entity].show(id);
      if (!user) {
        this.error('用户不存在！');
        return;
      }
      const password = this.nodeAuth.makePassword(md5('123456'));
      await service[this.entity].update({
        id,
        password,
        update_at: new Date(),
      });
      this.success();

    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 删除用户
    * @description 删除用户
    * @router delete /user/{id}
    * @request header string *token token令牌
    * @request path string *id userId
    * @response 200 deleteUserResponse ok
  */
  async deleteUser() {
    const { ctx, service } = this;
    try {
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const user = await service.user.show(id);
      if (!user) {
        this.error('用户不存在！');
        return;
      }
      await service.user.deleteUser(id);
      this.success('删除用户成功！');
    } catch (e) {
      throw e;
    }
  }

  // 生成验证码的
  async captcha() {
    const { ctx } = this;
    try {
      const { data, text } = svgCaptcha.create({
        ignoreChars: '0o1i',
        noise: 10,
        color: true,
        background: '#e5e5e5',
      });
      console.log('-----------当前验证码 start--------------');
      console.log(text);
      console.log('-----------当前验证码 end--------------');
      // 将用户的captcha存到session中
      ctx.session.captcha = text.toLowerCase();
      ctx.set('Content-Type', 'image/svg+xml');
      ctx.body = data;
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  // 校验验证码
  async checkCaptcha() {
    const { ctx } = this;
    const errorHandler = {
      code: 1,
      message: '验证码错误',
    };
    try {
      const { captcha } = ctx.request.body;
      if (captcha.toLowerCase() === ctx.session.captcha) {
        return {
          code: 0,
          message: '验证码正确',
        };
      }
      return errorHandler;
    } catch (e) {
      ctx.logger.error(e);
      return errorHandler;
    }
  }
}

module.exports = UserController;
