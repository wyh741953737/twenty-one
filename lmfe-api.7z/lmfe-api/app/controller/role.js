/*
 * @Description: 主要功能
 * @Author: 木犀
 * @Date: 2019-08-13 13:47:15
 * @LastEditors: 小广
 * @LastEditTime: 2019-09-25 16:22:54
 */
'use strict';
const BaseController = require('./base');

class RoleController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'role';
  }

  /**
    * @summary 获取角色列表接口
    * @description 获取角色列表
    * @router get /role
    * @request header string *token token令牌
    * @request query string id 角色id
    * @request query string roleName 角色名称
    * @request query string startTime 开始时间
    * @request query string endTime 结束时间
    * @response 200 roleListResponse ok
  */
  async getRoleList() {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const param = {
        id: query.id,
        name: query.roleName,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      const rule = {
        id: { type: 'string', required: false },
        name: { type: 'string', trim: true, required: false },
        startTime: { type: 'string', trim: true, required: false },
        endTime: { type: 'string', trim: true, required: false },
      };
      ctx.validate(rule, param);
      const result = await service.role.getRoleList(param);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = RoleController;
