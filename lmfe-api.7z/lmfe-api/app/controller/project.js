'use strict';
const BaseController = require('./base');

/**
* @controller project 项目
*/
class ProjectController extends BaseController {
  constructor(ctx) {
    super(ctx);
  }

  /**
    * @summary 查询项目列表
    * @description 查询项目列表
    * @router get /project/list
    * @request header string *token token
    * @request query string name 项目名称
    * @request query string code 项目code
    * @request query string ownerA 项目负责人A
    * @request query string ownerB 项目负责人B
    * @request query string intimeBegin 创建时间-开始时间
    * @request query string intimeEnd 创建时间-结束时间
    * @request query string updateTimeBegin 最后更新时间-开始时间
    * @request query string updateTimeEnd 最后更新时间-结束时间
    * @response 200 list ok
  */
  async list () {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const models = {
        name: query.name,
        code: query.code,
        ownerA: query.ownerA,
        ownerB: query.ownerB,
        intimeBegin: query.intimeBegin,
        intimeEnd: query.intimeEnd,
        updateTimeBegin: query.updateTimeBegin,
        updateTimeEnd: query.updateTimeEnd,
      };
      const result = await service.project.list(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询项目详情
    * @description 查询项目详情
    * @router get /project/detail/{id}
    * @request header string *token token
    * @request path string *id 项目id
    * @response 200 item ok
  */
  async detail () {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.project.detail(id);
      this.success(result[0]);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 新增项目
    * @description 新增项目
    * @router post /project/add
    * @request header string *token token
    * @response 200 id ok
  */
  async add () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        name: { type: 'string', trim: true, required: true },
        code: { type: 'string', trim: true, required: true },
        end_type: { type: 'number', required: true },
        unit_type: { type: 'number', required: true },
        repository: { type: 'string', trim: true, required: true },
        branch: { type: 'string', trim: true, required: true },
        dir: { type: 'string', trim: true, required: true },
        prefix: { type: 'string', trim: true, required: true },
        ownerA: { type: 'number', required: true },
        ownerB: { type: 'number', required: true }
      };
      const models = {
        name: body.name,
        code: body.code,
        end_type: body.endType,
        unit_type: body.unitType,
        repository: body.repository,
        branch: body.branch,
        dir: body.dir,
        prefix: body.prefix,
        ownerA: body.ownerA,
        ownerB: body.ownerB,
        inuser: user.id,
        update_user: user.id
      };
      ctx.validate(rules, models);
      const { id } = await service.project.add(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 编辑项目
    * @description 编辑项目
    * @router put /project/edit
    * @request header string *token token
    * @response 200 id ok
  */
  async edit () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        name: { type: 'string', trim: true, required: true },
        code: { type: 'string', trim: true, required: true },
        end_type: { type: 'number', required: true },
        unit_type: { type: 'number', required: true },
        repository: { type: 'string', trim: true, required: true },
        branch: { type: 'string', trim: true, required: true },
        dir: { type: 'string', trim: true, required: true },
        prefix: { type: 'string', trim: true, required: true },
        ownerA: { type: 'number', required: true },
        ownerB: { type: 'number', required: true }
      };
      const models = {
        id: body.id,
        name: body.name,
        code: body.code,
        end_type: body.endType,
        unit_type: body.unitType,
        repository: body.repository,
        branch: body.branch,
        dir: body.dir,
        prefix: body.prefix,
        ownerA: body.ownerA,
        ownerB: body.ownerB,
        update_user: user.id
      };
      ctx.validate(rules, models);
      const { id } = await service.project.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 构建项目
    * @description 构建项目
    * @router post /project/build
    * @request query string *id 项目id
    * @request header string *token token
    * @response 200 id ok
  */
  async build () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.request.body;
      const user = ctx.session.user;
      const rules = {
        id: { type: 'number', required: true }
      };
      const models = {
        id
      };
      ctx.validate(rules, models);
      const result = await service.project.build(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 发布项目
    * @description 发布项目
    * @router post /project/releaseVersion
    * @request query string *id 项目id
    * @request query string version 版本号
    * @request header string *token token
    * @response 200 id ok
  */
  async releaseVersion () {
    const { ctx, service } = this;
    try {
      const { id, version } = ctx.request.body;
      const user = ctx.session.user;
      const rules = {
        id: { type: 'number', required: true },
        version: { type: 'string', required: true }
      };
      const models = {
        id,
        version
      };
      ctx.validate(rules, models);
      const recordModels = {
        type: 2,
        unit_id: id,
        inuser: user.id,
        version
      }
      const result = await service.project.releaseVersion(models, recordModels);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 查询项目发布记录
    * @description 查询项目发布记录
    * @router get /project/releaseRecord
    * @request query string *id 项目id
    * @request header string *token token
    * @response 200 id ok
  */
  async releaseRecord () {
    const { ctx, service } = this;
    try {
      const { id } = ctx.query;
      const rules = {
        id: { type: 'string', required: true }
      };
      ctx.validate(rules, { id });
      const result = await service.project.releaseRecord(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}

module.exports = ProjectController;
