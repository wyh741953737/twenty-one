'use strict';
const BaseController = require('./base');
/**
* @controller BranchInfo 分支管理
*/

class BranchInfoController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'branch_info';
  }

  /**
    * @summary 项目分支列表
    * @description 项目分支列表
    * @router get /branch/checkBranchForProject/{id}
    * @request header string *token token
    * @request path string *id 项目id
    * @request query string name 分支名
    * @response 200 
  */
  async checkBranchForProject() {
    const { ctx, service } = this;
    try {
      const params = ctx.params;
      const query = ctx.query;
      const { id } = params
      const { name } = query
      const result = await service.branchInfo.selectBranch(id, name);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 项目tag列表
    * @description 项目tag列表
    * @router get /branch/checkTagForProject/{id}
    * @request header string *token token
    * @request path string *id 项目id
    * @request query string name tag名
    * @response 200 
  */
  async checkTagForProject() {
    const { ctx, service } = this;
    try {
      const params = ctx.params;
      const query = ctx.query;
      const { id } = params
      const { name } = query
      const result = await service.branchInfo.selectTag(id, name);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  /**
    * @summary 新增分支
    * @description 新增分支
    * @router post /branch/add
    * @request header string *token token令牌
    * @request body addBranchRequest branchInfo 微应用实例
    * @response 200
  */
  async addBranch () {
    const { ctx, service } = this;
    try {
      const user = ctx.session.user;
      const body = ctx.request.body;
      const rules = {
        name: { type: 'string', trim: true, required: true },
        projectId: { type: 'number', trim: true, required: true },
        source: { type: 'number', required: true },
        remark: { type: 'string', required: true },
      };
      const models = {
        name: body.name,
        projectId: body.projectId,
        source: body.source,
        sourceBranch: body.sourceBranch,
        sourceTag: body.sourceTag,
        sourceCommit: body.sourceCommit,
        remark: body.remark,
        inUser: user.id,
        inUserName: user.realName,
      };
      ctx.validate(rules, models);
      const { id } = await service.branchInfo.add(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
    
  }

  /**
    * @summary 编辑分支
    * @description 编辑分支
    * @router post /branch/update
    * @request header string *token token令牌
    * @response 200
  */
  async updateBranch () {
    const { ctx, service } = this;
    try {
      const body = ctx.request.body;
      const rules = {
        id: { type: 'number', required: true },
        remark: { type: 'string', trim: true, required: true }
      };
      const models = {
        id: body.id,
        remark: body.remark
      };
      Object.keys(rules).forEach(key => {
        models[key] = body[key]
      });
      ctx.validate(rules, models);
      const { id } = await service.branchInfo.edit(models);
      this.success(id);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 分支列表
    * @description 分支列表
    * @router get /branch/getBranchList
    * @request header string *token token
    * @request query string projectId 项目id
    * @request query string name 分支名
    * @request query string source 分支来源
    * @request query string inuser 创建人
    * @request query string startTime 创建开始时间
    * @request query string endTime 创建结束时间
    * @response 200 
  */
 async list () {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const models = {
        name: query.name,
        projectId: query.projectId,
        source: query.source,
        inuser: query.inuser,
        remark: query.remark,
        startTime: query.startTime,
        endTime: query.endTime,
      };
      if (query.source == 1) {
        models.sourceBranch = query.sourceName
      } else if (query.source == 2) {
        models.sourceTag = query.sourceName
      } else if (query.source == 3) {
        models.sourceCommit = query.sourceName
      }
      const result = await service.branchInfo.list(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 分支详情
    * @description 分支详情
    * @router get /branch/detail/{id}
    * @request header string *token token
    * @request path string *id 分支id
    * @response 200 
  */
  async detail () {
    const { ctx, service } = this;
    try {
      const params = ctx.params;
      const { id } = params
      const result = await service.branchInfo.detail(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
  
  /**
    * @summary 删除分支
    * @description 分支详情
    * @router post /branch/delete/{id}
    * @request header string *token token
    * @request path string *id 分支id
    * @response 200 
  */
  async deleteBranch () {
    const { ctx, service } = this;
    try {
      const params = ctx.params;
      const { id } = params
      const result = await service.branchInfo.deleteBranch(id);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }

  /**
    * @summary 项目列表select2
    * @description 分支详情
    * @router get /branch/projectSelect2
    * @request header string *token token
    * @request query string name 分支名
    * @request query string id 分支名
    * @response 200 
  */

  async projectSelect2 () {
    const { ctx, service } = this;
    try {
      const query = ctx.query;
      const models = {
        name: query.name,
        id: query.id,
      };
      const result = await service.branchInfo.projectSelect2(models);
      this.success(result);
    } catch (e) {
      ctx.logger.error(e);
      this.error(e);
    }
  }
}
module.exports = BranchInfoController;