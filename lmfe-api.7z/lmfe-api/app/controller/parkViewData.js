
'use strict';
const BaseController = require('./base');

/**
* @controller parkViewData 小微园
*/
class ParkViewDataController extends BaseController {
  constructor(ctx) {
    super(ctx);
    this.entity = 'park_view_data';
  }


  /**
  * @summary 根据小微园id，获取小微园接口(官网)
  * @description 根据小微园id，获取小微园详情
  * @router get /web/parkViewData/{id}
  * @request path string *id 小微园id
  * @response 200 parkViewData ok
*/
  async getParkViewDataByIdForWeb() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const rule = {
        id: { type: 'string', required: true },
      };
      ctx.validate(rule, { id });
      const result = await service.parkViewData.getParkViewDataListForWeb(id);
      const resData = {};
      for (let i = 0; i < result.length; i++) {
        resData[result[i].attributeName] = result[i].attributeValue;
      }
      this.success(resData);
    } catch (e) {
      this.error(e);
    }
  }

  /**
  * @summary 根据小微园id，改变小微园数据接口(官网)
  * @description 根据小微园id，获取小微园详情
  * @router put /web/parkViewData/{id}
  * @request path string *id 小微园id
  * * @request body editParkViewDataRequest parkViewData 小微园
  * @response 200 parkViewData ok
*/
  async editParkViewDataForWeb() {
    try {
      const { ctx, service } = this;
      const { id } = ctx.params;
      const body = ctx.request.body;
      const result = await service.parkViewData.editParkViewDataForWeb(id, body);
      this.success(result);
    } catch (e) {
      this.error(e);
    }
  }
}
module.exports = ParkViewDataController;
